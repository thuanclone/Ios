//! Plugin manga mẫu theo docs/PLUGIN_ABI.md. Trả dữ liệu giả để thử luồng
//! tìm kiếm, danh sách chương và trình đọc. Plugin không gọi mạng; ảnh bìa và
//! ảnh trang là URL của dịch vụ ảnh mẫu picsum.photos do app tự tải.
use serde::Serialize;
use serde_json::Value;

#[derive(Serialize)]
struct MediaItem {
    id: String,
    title: String,
    #[serde(rename = "coverURL")]
    cover_url: Option<String>,
    subtitle: Option<String>,
}

#[derive(Serialize)]
struct Chapter {
    id: String,
    title: String,
    number: Option<f64>,
}

#[derive(Serialize)]
struct MediaDetail {
    id: String,
    title: String,
    description: Option<String>,
    #[serde(rename = "coverURL")]
    cover_url: Option<String>,
    genres: Vec<String>,
    chapters: Vec<Chapter>,
}

#[derive(Serialize)]
struct PageList {
    pages: Vec<String>,
}

// ---- Bộ nhớ: vỏ gọi alloc/dealloc để trao đổi JSON ----
#[no_mangle]
pub extern "C" fn alloc(len: i32) -> i32 {
    let b = vec![0u8; len as usize].into_boxed_slice();
    Box::into_raw(b) as *mut u8 as usize as i32
}

#[no_mangle]
pub extern "C" fn dealloc(ptr: i32, len: i32) {
    unsafe {
        drop(Box::from_raw(std::slice::from_raw_parts_mut(
            ptr as usize as *mut u8,
            len as usize,
        )));
    }
}

fn input(ptr: i32, len: i32) -> Value {
    let s = unsafe { std::slice::from_raw_parts(ptr as usize as *const u8, len as usize) };
    serde_json::from_slice(s).unwrap_or(Value::Null)
}

/// Trả về (ptr << 32) | len; len = 0 nghĩa là lỗi.
fn out<T: Serialize>(v: &T) -> i64 {
    let bytes = serde_json::to_vec(v).unwrap_or_default().into_boxed_slice();
    let len = bytes.len();
    if len == 0 {
        return 0;
    }
    let ptr = Box::into_raw(bytes) as *mut u8 as usize;
    ((ptr as i64) << 32) | len as i64
}

fn cover(seed: &str) -> String {
    format!("https://picsum.photos/seed/{seed}/300/420")
}

// ---- Các hàm ABI ----
#[no_mangle]
pub extern "C" fn search(ptr: i32, len: i32) -> i64 {
    let q = input(ptr, len)["query"].as_str().unwrap_or("").to_string();
    let items: Vec<MediaItem> = (1..=8)
        .map(|i| MediaItem {
            id: format!("m{i}"),
            title: if q.is_empty() { format!("Truyện thử {i}") } else { format!("{q} (thử {i})") },
            cover_url: Some(cover(&format!("manga-m{i}"))),
            subtitle: Some("6 chương".into()),
        })
        .collect();
    out(&items)
}

#[no_mangle]
pub extern "C" fn detail(ptr: i32, len: i32) -> i64 {
    let id = input(ptr, len)["id"].as_str().unwrap_or("m1").to_string();
    out(&MediaDetail {
        title: format!("Truyện thử {id}"),
        cover_url: Some(cover(&format!("manga-{id}"))),
        description: Some("Dữ liệu giả từ plugin manga mẫu. Ảnh trang là ảnh ngẫu nhiên để thử trình đọc.".into()),
        genres: vec!["Demo".into(), "Thử nghiệm".into()],
        chapters: (1..=6)
            .map(|n| Chapter { id: format!("{id}-c{n}"), title: format!("Chương {n}"), number: Some(n as f64) })
            .collect(),
        id,
    })
}

#[no_mangle]
pub extern "C" fn pages(ptr: i32, len: i32) -> i64 {
    let id = input(ptr, len)["id"].as_str().unwrap_or("m1-c1").to_string();
    out(&PageList {
        pages: (1..=12)
            .map(|p| format!("https://picsum.photos/seed/{id}-p{p}/800/1200"))
            .collect(),
    })
}
