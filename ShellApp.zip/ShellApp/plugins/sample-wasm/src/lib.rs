//! Plugin mẫu theo docs/PLUGIN_ABI.md. Trả dữ liệu giả để kiểm tra luồng nạp WASM,
//! tìm kiếm, danh sách tập và trình phát. Không gọi mạng.
use serde::Serialize;
use serde_json::Value;

#[derive(Serialize)]
struct MediaItem {
    id: String,
    title: String,
    #[serde(rename = "coverURL")]
    cover_url: Option<String>,
    subtitle: Option<String>,
}

#[derive(Serialize)]
struct Chapter {
    id: String,
    title: String,
    number: Option<f64>,
}

#[derive(Serialize)]
struct MediaDetail {
    id: String,
    title: String,
    description: Option<String>,
    #[serde(rename = "coverURL")]
    cover_url: Option<String>,
    genres: Vec<String>,
    chapters: Vec<Chapter>,
}

#[derive(Serialize)]
struct StreamInfo {
    url: String,
    headers: Option<std::collections::HashMap<String, String>>,
}

// ---- Bộ nhớ: vỏ gọi alloc/dealloc để trao đổi JSON ----
#[no_mangle]
pub extern "C" fn alloc(len: i32) -> i32 {
    let b = vec![0u8; len as usize].into_boxed_slice();
    Box::into_raw(b) as *mut u8 as usize as i32
}

#[no_mangle]
pub extern "C" fn dealloc(ptr: i32, len: i32) {
    unsafe {
        drop(Box::from_raw(std::slice::from_raw_parts_mut(
            ptr as usize as *mut u8,
            len as usize,
        )));
    }
}

fn input(ptr: i32, len: i32) -> Value {
    let s = unsafe { std::slice::from_raw_parts(ptr as usize as *const u8, len as usize) };
    serde_json::from_slice(s).unwrap_or(Value::Null)
}

/// Trả về (ptr << 32) | len; len = 0 nghĩa là lỗi.
fn out<T: Serialize>(v: &T) -> i64 {
    let bytes = serde_json::to_vec(v).unwrap_or_default().into_boxed_slice();
    let len = bytes.len();
    if len == 0 {
        return 0;
    }
    let ptr = Box::into_raw(bytes) as *mut u8 as usize;
    ((ptr as i64) << 32) | len as i64
}

// ---- Các hàm ABI ----
#[no_mangle]
pub extern "C" fn search(ptr: i32, len: i32) -> i64 {
    let q = input(ptr, len)["query"].as_str().unwrap_or("").to_string();
    let items: Vec<MediaItem> = (1..=6)
        .map(|i| MediaItem {
            id: format!("a{i}"),
            title: if q.is_empty() { format!("Anime thử {i}") } else { format!("{q} (thử {i})") },
            cover_url: None,
            subtitle: Some("3 tập".into()),
        })
        .collect();
    out(&items)
}

#[no_mangle]
pub extern "C" fn detail(ptr: i32, len: i32) -> i64 {
    let id = input(ptr, len)["id"].as_str().unwrap_or("a1").to_string();
    out(&MediaDetail {
        title: format!("Anime thử {id}"),
        id,
        description: Some("Dữ liệu giả từ plugin WASM mẫu.".into()),
        cover_url: None,
        genres: vec!["Demo".into()],
        chapters: (1..=3)
            .map(|n| Chapter { id: format!("ep{n}"), title: format!("Tập {n}"), number: Some(n as f64) })
            .collect(),
    })
}

#[no_mangle]
pub extern "C" fn stream(_ptr: i32, _len: i32) -> i64 {
    // Luồng HLS mẫu công khai của Apple, dùng để thử trình phát.
    out(&StreamInfo {
        url: "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_ts/master.m3u8".into(),
        headers: None,
    })
}
