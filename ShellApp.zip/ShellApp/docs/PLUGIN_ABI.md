# Plugin ABI v1

Một plugin là thư mục gồm `manifest.json` và một file `.wasm`. Vỏ không chứa nguồn nào cài sẵn.

## manifest.json
```json
{ "id": "example", "name": "Example", "version": "1.0",
  "kind": "manga", "language": "vi",
  "allowedHosts": ["example.org"], "wasm": "plugin.wasm" }
```

## Quy ước bộ nhớ
Chuỗi JSON UTF-8 được truyền qua bộ nhớ WASM. Giá trị trả về `i64` gói `(ptr << 32) | len`; `len == 0` là lỗi.

## Plugin phải export
| Hàm | Vào (JSON) | Ra (JSON) |
|---|---|---|
| `memory` | | bộ nhớ linear |
| `alloc(len: i32) -> i32` | | con trỏ vùng nhớ mới |
| `dealloc(ptr: i32, len: i32)` | | |
| `search(ptr, len) -> i64` | `{query, page}` | `[MediaItem]` |
| `detail(ptr, len) -> i64` | `{id}` | `MediaDetail` |
| `pages(ptr, len) -> i64` | `{id}` (chương) | `{pages: [url]}` |
| `stream(ptr, len) -> i64` | `{id}` (tập) | `{url, headers?}` |

Hàm nào không phù hợp với `kind` của plugin thì có thể không export.

## Vỏ cung cấp cho plugin (import từ module `env`)
| Hàm | Ghi chú |
|---|---|
| `http_get(urlPtr: i32, urlLen: i32) -> i64` | Trả body theo quy ước ptr/len. Trả 0 nếu host không nằm trong `allowedHosts`. |

Schema JSON của `MediaItem`, `MediaDetail`, `Chapter` khớp `Sources/PluginKit/Models.swift`.

## Viết plugin
Bất kỳ ngôn ngữ nào biên dịch ra `wasm32-unknown-unknown` (Rust, AssemblyScript, Zig). Không dùng WASI.

## Định dạng file để cài: `.plugin.json`
Một file JSON duy nhất, dễ chọn trên iOS:
```json
{ "manifest": { ...như manifest.json... }, "wasm": "<nội dung plugin.wasm mã hoá base64>" }
```
