// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "PluginKit",
    platforms: [.iOS(.v16), .macOS(.v13)],
    products: [.library(name: "PluginKit", targets: ["PluginKit"])],
    dependencies: [
        // Runtime WASM thuần Swift, không cần JIT nên chạy được trên iOS.
        // Bản 0.3+ yêu cầu Swift 6.3, tạm giữ bản cũ hơn cho tới khi máy build có Xcode mới.
        .package(url: "https://github.com/swiftwasm/WasmKit.git", "0.1.0"..<"0.3.0"),
        // Ghim swift-system: bản 1.6+ có kiểu Stat làm WasmKit cũ không build được.
        .package(url: "https://github.com/apple/swift-system.git", "1.5.0"..<"1.6.0"),
    ],
    targets: [
        .target(name: "PluginKit", dependencies: [
            .product(name: "WasmKit", package: "WasmKit"),
            .product(name: "SystemPackage", package: "swift-system"),
        ])
    ]
)
