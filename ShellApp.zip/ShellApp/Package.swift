// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "PluginKit",
    platforms: [.iOS(.v16), .macOS(.v13)],
    products: [.library(name: "PluginKit", targets: ["PluginKit"])],
    dependencies: [
        // Runtime WASM thuần Swift, không cần JIT nên chạy được trên iOS.
        .package(url: "https://github.com/swiftwasm/WasmKit.git", from: "0.3.0")
    ],
    targets: [
        .target(name: "PluginKit", dependencies: [.product(name: "WasmKit", package: "WasmKit")])
    ]
)
