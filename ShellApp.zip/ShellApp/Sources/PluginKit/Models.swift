import Foundation

public enum MediaKind: String, Codable { case anime, manga }

/// manifest.json nằm cạnh file .wasm của mỗi plugin.
public struct PluginManifest: Codable, Identifiable, Hashable {
    public let id: String
    public let name: String
    public let version: String
    public let kind: MediaKind
    public let language: String
    /// Plugin chỉ được gọi mạng tới các host trong danh sách này.
    public let allowedHosts: [String]
    public let wasm: String
}

public struct MediaItem: Codable, Identifiable, Hashable {
    public let id: String
    public let title: String
    public let coverURL: String?
    public let subtitle: String?
    public init(id: String, title: String, coverURL: String?, subtitle: String?) {
        self.id = id; self.title = title; self.coverURL = coverURL; self.subtitle = subtitle
    }
}

public struct Chapter: Codable, Identifiable, Hashable {
    public let id: String
    public let title: String
    public let number: Double?
}

public struct MediaDetail: Codable, Hashable {
    public let id: String
    public let title: String
    public let description: String?
    public let coverURL: String?
    public let genres: [String]
    /// Manga: danh sách chương. Anime: danh sách tập.
    public let chapters: [Chapter]
}

public struct PageList: Codable { public let pages: [String] }          // URL ảnh
public struct StreamInfo: Codable { public let url: String; public let headers: [String: String]? }

public enum PluginError: Error { case missingExport(String), badResult, hostDenied(String), trap(String) }

/// Mọi nguồn (WASM hay mẫu) đều theo giao diện này, UI chỉ biết giao diện này.
public protocol ContentSource: Sendable {
    var manifest: PluginManifest { get }
    func search(query: String, page: Int) async throws -> [MediaItem]
    func detail(id: String) async throws -> MediaDetail
    func pages(chapterID: String) async throws -> PageList
    func stream(episodeID: String) async throws -> StreamInfo
}
