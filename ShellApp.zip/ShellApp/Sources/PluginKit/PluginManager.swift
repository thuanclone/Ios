import Foundation

/// Quản lý plugin đã cài: mỗi plugin là một thư mục Plugins/<id>/ chứa manifest.json và file .wasm.
public final class PluginManager: ObservableObject {
    @Published public private(set) var sources: [ContentSource] = [SampleSource()]
    private let dir: URL

    public init() {
        dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Plugins", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        reload()
    }

    public func reload() {
        var list: [ContentSource] = [SampleSource()]
        let folders = (try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil)) ?? []
        for f in folders {
            guard let m = try? JSONDecoder().decode(PluginManifest.self, from: Data(contentsOf: f.appendingPathComponent("manifest.json"))),
                  let w = try? Data(contentsOf: f.appendingPathComponent(m.wasm)),
                  let s = try? WasmSource(manifest: m, wasm: w) else { continue }
            list.append(s)
        }
        sources = list
    }

    /// Cài plugin từ thư mục người dùng chọn (Files app) hoặc đã tải về.
    public func install(from folder: URL) throws {
        let m = try JSONDecoder().decode(PluginManifest.self, from: Data(contentsOf: folder.appendingPathComponent("manifest.json")))
        let dest = dir.appendingPathComponent(m.id)
        try? FileManager.default.removeItem(at: dest)
        try FileManager.default.copyItem(at: folder, to: dest)
        reload()
    }

    /// Cài từ một file .plugin.json: {"manifest": {...}, "wasm": "<base64>"}.
    /// Thử nạp WASM trước; lỗi thì ném ra và không lưu gì.
    public func installBundle(data: Data) throws {
        struct PluginBundle: Decodable { let manifest: PluginManifest; let wasm: String }
        let b = try JSONDecoder().decode(PluginBundle.self, from: data)
        guard let wasm = Data(base64Encoded: b.wasm) else { throw PluginError.badResult }
        _ = try WasmSource(manifest: b.manifest, wasm: wasm)
        let dest = dir.appendingPathComponent(b.manifest.id)
        try? FileManager.default.removeItem(at: dest)
        try FileManager.default.createDirectory(at: dest, withIntermediateDirectories: true)
        try JSONEncoder().encode(b.manifest).write(to: dest.appendingPathComponent("manifest.json"))
        try wasm.write(to: dest.appendingPathComponent(b.manifest.wasm))
        reload()
    }

    public func uninstall(id: String) {
        try? FileManager.default.removeItem(at: dir.appendingPathComponent(id))
        reload()
    }
}
