import Foundation

/// Nguồn Nyaa.media native (Swift) — không qua WASM, tránh trap memory.
public final class NyaaSource: ContentSource, @unchecked Sendable {
    public static let id = "nyaa-media-native"

    public let manifest = PluginManifest(
        id: NyaaSource.id,
        name: "Nyaa.media (Torrent)",
        version: "1.0",
        kind: .anime,
        language: "en",
        allowedHosts: ["nyaa.media", "nyaa.si"],
        wasm: ""
    )

    private let session: URLSession = {
        let cfg = URLSessionConfiguration.ephemeral
        cfg.timeoutIntervalForRequest = 25
        cfg.timeoutIntervalForResource = 35
        cfg.httpAdditionalHeaders = [
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Referer": "https://nyaa.media/",
        ]
        return URLSession(configuration: cfg)
    }()

    public init() {}

    public func search(query: String, page: Int) async throws -> [MediaItem] {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        let p = max(page, 1)

        // 1) RSS
        var comps = URLComponents(string: "https://nyaa.media/")!
        var items: [URLQueryItem] = [
            URLQueryItem(name: "page", value: "rss"),
            URLQueryItem(name: "p", value: "\(p)"),
        ]
        if !q.isEmpty {
            items.append(URLQueryItem(name: "q", value: q))
            items.append(URLQueryItem(name: "c", value: "0_0"))
            items.append(URLQueryItem(name: "f", value: "0"))
        }
        comps.queryItems = items
        if let url = comps.url {
            let body = try await fetchString(url)
            let parsed = parseRSS(body)
            if !parsed.isEmpty { return parsed }
        }

        // 2) HTML fallback
        var h = URLComponents(string: "https://nyaa.media/")!
        var hi: [URLQueryItem] = [URLQueryItem(name: "p", value: "\(p)")]
        if !q.isEmpty {
            hi = [
                URLQueryItem(name: "f", value: "0"),
                URLQueryItem(name: "c", value: "0_0"),
                URLQueryItem(name: "q", value: q),
                URLQueryItem(name: "p", value: "\(p)"),
            ]
        }
        h.queryItems = hi
        if let url = h.url {
            let body = try await fetchString(url)
            let parsed = parseHTML(body)
            if !parsed.isEmpty { return parsed }
        }

        throw PluginError.badResult
    }

    public func detail(id: String) async throws -> MediaDetail {
        let tid = id.filter { $0.isNumber }
        guard !tid.isEmpty else { throw PluginError.badResult }
        let url = URL(string: "https://nyaa.media/view/\(tid)")!
        let body = try await fetchString(url)

        let title: String = {
            if let t = between(body, "<title>", " | Nyaa") ?? between(body, "<title>", "</title>") {
                return decodeEntities(t)
            }
            return "Torrent #\(tid)"
        }()

        let magnet = extractMagnet(body) ?? ""
        let torrentFile = "https://nyaa.si/download/\(tid).torrent"
        let desc = "Torrent từ nyaa.media\nID: \(tid)\nFile: \(torrentFile)\nMagnet:\n\(magnet)"

        return MediaDetail(
            id: tid,
            title: title,
            description: desc,
            coverURL: nil,
            genres: ["Torrent", "Nyaa"],
            chapters: [Chapter(id: tid, title: "Phát / tải torrent", number: 1)]
        )
    }

    public func pages(chapterID: String) async throws -> PageList {
        PageList(pages: [])
    }

    public func stream(episodeID: String) async throws -> StreamInfo {
        let tid = episodeID.filter { $0.isNumber }
        guard !tid.isEmpty else { throw PluginError.badResult }
        let url = URL(string: "https://nyaa.media/view/\(tid)")!
        let body = try await fetchString(url)
        guard let magnet = extractMagnet(body), !magnet.isEmpty else {
            throw PluginError.badResult
        }
        return StreamInfo(
            url: magnet,
            headers: [
                "X-Torrent-File": "https://nyaa.si/download/\(tid).torrent",
                "X-Torrent-Id": tid,
            ]
        )
    }

    // MARK: - Network

    private func fetchString(_ url: URL) async throws -> String {
        let (data, resp) = try await session.data(from: url)
        if let http = resp as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            throw PluginError.badResult
        }
        return String(data: data, encoding: .utf8)
            ?? String(decoding: data, as: UTF8.self)
    }

    // MARK: - Parse

    private func parseRSS(_ body: String) -> [MediaItem] {
        var out: [MediaItem] = []
        let parts = body.components(separatedBy: "<item>")
        for chunk in parts.dropFirst() {
            let title = xml(chunk, "title") ?? ""
            let guid = xml(chunk, "guid") ?? ""
            let id = guid.split(separator: "/").last.map(String.init)?.filter { $0.isNumber } ?? ""
            guard !id.isEmpty else { continue }
            let size = xmlNyaa(chunk, "size") ?? xml(chunk, "description") ?? "?"
            let seeders = xmlNyaa(chunk, "seeders") ?? "?"
            let leechers = xmlNyaa(chunk, "leechers") ?? "?"
            let cat = xmlNyaa(chunk, "categoryName") ?? "Torrent"
            out.append(MediaItem(
                id: id,
                title: decodeEntities(title),
                coverURL: nil,
                subtitle: "\(cat) · \(size) · ↑\(seeders) ↓\(leechers)"
            ))
            if out.count >= 50 { break }
        }
        return out
    }

    private func parseHTML(_ body: String) -> [MediaItem] {
        var out: [MediaItem] = []
        var rest = body[...]
        while let r = rest.range(of: "/view/") {
            rest = rest[r.upperBound...]
            let id = String(rest.prefix(while: { $0.isNumber }))
            guard !id.isEmpty else { continue }
            let title: String = {
                if let a = rest.range(of: ">"),
                   let b = rest.range(of: "</a>"),
                   a.upperBound < b.lowerBound {
                    let t = String(rest[a.upperBound..<b.lowerBound])
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                    if t.count > 3, !t.contains("<"), !t.contains(">") {
                        return decodeEntities(t)
                    }
                }
                return "Torrent #\(id)"
            }()
            if out.contains(where: { $0.id == id }) { continue }
            out.append(MediaItem(id: id, title: title, coverURL: nil, subtitle: "Nyaa torrent"))
            if out.count >= 40 { break }
        }
        return out
    }

    private func extractMagnet(_ body: String) -> String? {
        guard let r = body.range(of: "magnet:?xt=") else { return nil }
        let from = body[r.lowerBound...]
        let end = from.firstIndex(of: "\"") ?? from.firstIndex(of: "'")
        guard let end else { return nil }
        return decodeEntities(String(from[..<end]))
    }

    private func xml(_ s: String, _ tag: String) -> String? {
        between(s, "<\(tag)>", "</\(tag)>")
    }
    private func xmlNyaa(_ s: String, _ tag: String) -> String? {
        between(s, "<nyaa:\(tag)>", "</nyaa:\(tag)>")
    }
    private func between(_ s: String, _ a: String, _ b: String) -> String? {
        guard let r1 = s.range(of: a) else { return nil }
        let rest = s[r1.upperBound...]
        guard let r2 = rest.range(of: b) else { return nil }
        return String(rest[..<r2.lowerBound]).trimmingCharacters(in: .whitespacesAndNewlines)
    }
    private func decodeEntities(_ s: String) -> String {
        s.replacingOccurrences(of: "&amp;", with: "&")
            .replacingOccurrences(of: "&lt;", with: "<")
            .replacingOccurrences(of: "&gt;", with: ">")
            .replacingOccurrences(of: "&quot;", with: "\"")
            .replacingOccurrences(of: "&#39;", with: "'")
            .replacingOccurrences(of: "&apos;", with: "'")
    }
}
