import Foundation

/// Nguồn dựng sẵn cho link video trực tiếp (mp4, m3u8, link tải của Google Photos…).
/// Mỗi "mục" chính là URL; chỉ có một tập duy nhất.
public struct DirectLinkSource: ContentSource {
    public static let id = "direct"
    public let manifest = PluginManifest(id: DirectLinkSource.id, name: "Link trực tiếp", version: "1",
                                         kind: .anime, language: "-", allowedHosts: [], wasm: "")
    public init() {}

    /// Trả về URL nếu chuỗi là link http(s) hợp lệ.
    public static func parse(_ text: String) -> String? {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let u = URL(string: t), let scheme = u.scheme?.lowercased(),
              scheme == "http" || scheme == "https", u.host != nil else { return nil }
        return t
    }

    public static func title(for url: String) -> String {
        guard let u = URL(string: url), let host = u.host else { return "Video từ link" }
        if host.hasSuffix("googleusercontent.com") { return "Video Google Photos" }
        let name = u.deletingPathExtension().lastPathComponent
        return name.isEmpty || name == "/" ? host : name
    }

    public func search(query: String, page: Int) async throws -> [MediaItem] { [] }
    public func detail(id: String) async throws -> MediaDetail {
        MediaDetail(id: id, title: Self.title(for: id), description: id, coverURL: nil, genres: [],
                    chapters: [Chapter(id: id, title: "Phát", number: 1)])
    }
    public func pages(chapterID: String) async throws -> PageList { PageList(pages: []) }
    public func stream(episodeID: String) async throws -> StreamInfo { StreamInfo(url: episodeID) }
}
