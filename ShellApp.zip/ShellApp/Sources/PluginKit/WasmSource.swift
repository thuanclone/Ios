import Foundation
import WasmKit

/// Nạp plugin .wasm theo ABI docs/PLUGIN_ABI.md.
/// WasmKit Value: i32 = UInt32, i64 = UInt64.
public final class WasmSource: ContentSource, @unchecked Sendable {
    public let manifest: PluginManifest
    private let store: Store
    private let instance: Instance
    private let lock = NSLock()

    private static let maxHttpBody = 400_000

    public init(manifest: PluginManifest, wasm: Data) throws {
        self.manifest = manifest
        let module = try parseWasm(bytes: Array(wasm))
        let store = Store(engine: Engine())
        self.store = store

        let hosts = manifest.allowedHosts
        var imports = Imports()

        imports.define(module: "env", name: "http_get",
            Function(store: store, parameters: [.i32, .i32], results: [.i64]) { caller, args in
                let urlPtr = Int(args[0].i32)
                let urlLen = Int(args[1].i32)
                guard urlLen > 0,
                      let mem0 = caller.instance?.exports[memory: "memory"],
                      let allocFn = caller.instance?.exports[function: "alloc"]
                else { return [Value.i64(0)] }

                let urlBytes = Self.readBytes(mem0, ptr: urlPtr, len: urlLen)
                guard !urlBytes.isEmpty,
                      let url = URL(string: String(decoding: urlBytes, as: UTF8.self)),
                      let host = url.host,
                      hosts.contains(where: { host == $0 || host.hasSuffix("." + $0) })
                else { return [Value.i64(0)] }

                var body = Self.syncGet(url)
                if body.count > Self.maxHttpBody {
                    body = body.prefix(Self.maxHttpBody)
                }
                let bytes = [UInt8](body)
                guard !bytes.isEmpty else { return [Value.i64(0)] }

                let ptrU32: UInt32
                do {
                    let results = try allocFn([Value.i32(UInt32(bytes.count))])
                    ptrU32 = results[0].i32
                } catch {
                    return [Value.i64(0)]
                }
                guard ptrU32 > 0,
                      let mem1 = caller.instance?.exports[memory: "memory"],
                      Self.writeBytes(mem1, ptr: Int(ptrU32), bytes: bytes)
                else { return [Value.i64(0)] }

                let packed = (UInt64(ptrU32) << 32) | UInt64(UInt32(bytes.count))
                return [Value.i64(packed)]
            })

        self.instance = try module.instantiate(store: store, imports: imports)
    }

    public func search(query: String, page: Int) async throws -> [MediaItem] {
        try call("search", ["query": query, "page": page])
    }
    public func detail(id: String) async throws -> MediaDetail {
        try call("detail", ["id": id])
    }
    public func pages(chapterID: String) async throws -> PageList {
        try call("pages", ["id": chapterID])
    }
    public func stream(episodeID: String) async throws -> StreamInfo {
        try call("stream", ["id": episodeID])
    }

    private func call<T: Decodable>(_ fn: String, _ input: [String: Any]) throws -> T {
        lock.lock(); defer { lock.unlock() }
        guard let allocFn = instance.exports[function: "alloc"] else {
            throw PluginError.missingExport("alloc")
        }
        guard let deallocFn = instance.exports[function: "dealloc"] else {
            throw PluginError.missingExport("dealloc")
        }
        guard let f = instance.exports[function: fn] else {
            throw PluginError.missingExport(fn)
        }

        let json = [UInt8](try JSONSerialization.data(withJSONObject: input))
        guard !json.isEmpty else { throw PluginError.badResult }

        let inPtr: UInt32 = try allocFn([Value.i32(UInt32(json.count))])[0].i32
        guard inPtr > 0,
              let memIn = instance.exports[memory: "memory"],
              Self.writeBytes(memIn, ptr: Int(inPtr), bytes: json)
        else { throw PluginError.badResult }

        let packed: UInt64
        do {
            packed = try f([Value.i32(inPtr), Value.i32(UInt32(json.count))])[0].i64
        } catch {
            _ = try? deallocFn([Value.i32(inPtr), Value.i32(UInt32(json.count))])
            throw PluginError.trap("\(error)")
        }

        guard let memOut = instance.exports[memory: "memory"] else {
            _ = try? deallocFn([Value.i32(inPtr), Value.i32(UInt32(json.count))])
            throw PluginError.missingExport("memory")
        }

        let outPtr = UInt32(packed >> 32)
        let outLen = UInt32(truncatingIfNeeded: packed & 0xFFFF_FFFF)
        guard outLen > 0, outPtr > 0 else {
            _ = try? deallocFn([Value.i32(inPtr), Value.i32(UInt32(json.count))])
            throw PluginError.badResult
        }

        let out = Self.readBytes(memOut, ptr: Int(outPtr), len: Int(outLen))
        _ = try? deallocFn([Value.i32(inPtr), Value.i32(UInt32(json.count))])
        _ = try? deallocFn([Value.i32(outPtr), Value.i32(outLen)])
        guard out.count == Int(outLen) else { throw PluginError.badResult }
        return try JSONDecoder().decode(T.self, from: Data(out))
    }

    private static func readBytes(_ mem: Memory, ptr: Int, len: Int) -> [UInt8] {
        let data = mem.data
        guard ptr >= 0, len > 0, ptr <= data.count, len <= data.count - ptr else {
            return []
        }
        return Array(data[ptr ..< (ptr + len)])
    }

    @discardableResult
    private static func writeBytes(_ mem: Memory, ptr: Int, bytes: [UInt8]) -> Bool {
        guard !bytes.isEmpty else { return true }
        let data = mem.data
        guard ptr >= 0, ptr <= data.count, bytes.count <= data.count - ptr else {
            return false
        }
        mem.withUnsafeMutableBufferPointer(offset: UInt(ptr), count: bytes.count) { buf in
            bytes.withUnsafeBytes { src in buf.copyMemory(from: src) }
        }
        return true
    }

    private static func syncGet(_ url: URL) -> Data {
        let sem = DispatchSemaphore(value: 0)
        var result = Data()
        var req = URLRequest(url: url, timeoutInterval: 25)
        req.setValue(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
            forHTTPHeaderField: "User-Agent"
        )
        req.setValue(
            "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            forHTTPHeaderField: "Accept"
        )
        req.setValue("https://nyaa.media/", forHTTPHeaderField: "Referer")
        URLSession.shared.dataTask(with: req) { d, _, _ in
            result = d ?? Data()
            sem.signal()
        }.resume()
        _ = sem.wait(timeout: .now() + 30)
        return result
    }
}
