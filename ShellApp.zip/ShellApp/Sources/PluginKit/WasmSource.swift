import Foundation
import WasmKit

/// Nạp một plugin .wasm và gọi các hàm export theo ABI trong docs/PLUGIN_ABI.md.
/// LƯU Ý: API của WasmKit đổi theo phiên bản. Nếu build lỗi, chỉ cần chỉnh
/// readBytes/writeBytes và chỗ khai báo Function bên dưới.
public final class WasmSource: ContentSource, @unchecked Sendable {
    public let manifest: PluginManifest
    private let store: Store
    private let instance: Instance
    private let lock = NSLock()   // instance WASM không thread-safe

    /// Giới hạn body HTTP đưa vào WASM (tránh OOB khi memory chưa grow đủ).
    private static let maxHttpBody = 400_000

    public init(manifest: PluginManifest, wasm: Data) throws {
        self.manifest = manifest
        let module = try parseWasm(bytes: Array(wasm))
        let store = Store(engine: Engine())
        self.store = store

        let hosts = manifest.allowedHosts
        var imports = Imports()

        // env.http_get(urlPtr, urlLen) -> i64 (ptr<<32 | len) trỏ tới body trả về
        imports.define(module: "env", name: "http_get",
            Function(store: store, parameters: [.i32, .i32], results: [.i64]) { caller, args in
                let urlPtr = Int(args[0].i32)
                let urlLen = Int(args[1].i32)
                guard urlLen > 0,
                      let mem0 = caller.instance?.exports[memory: "memory"],
                      let alloc = caller.instance?.exports[function: "alloc"]
                else { return [.i64(0)] }

                let urlBytes = Self.readBytes(mem0, ptr: urlPtr, len: urlLen)
                guard !urlBytes.isEmpty,
                      let url = URL(string: String(decoding: urlBytes, as: UTF8.self)),
                      let host = url.host,
                      hosts.contains(where: { host == $0 || host.hasSuffix("." + $0) })
                else { return [.i64(0)] }

                var body = Self.syncGet(url)
                if body.count > Self.maxHttpBody {
                    body = body.prefix(Self.maxHttpBody)
                }
                let bytes = [UInt8](body)
                guard !bytes.isEmpty else { return [.i64(0)] }

                // alloc trong guest có thể memory.grow — PHẢI lấy lại export memory sau alloc
                let ptrVal: Int32
                do {
                    ptrVal = try alloc([.i32(UInt32(bytes.count))])[0].i32
                } catch {
                    return [.i64(0)]
                }
                guard ptrVal > 0,
                      let mem1 = caller.instance?.exports[memory: "memory"]
                else { return [.i64(0)] }

                guard Self.writeBytes(mem1, ptr: Int(ptrVal), bytes: bytes) else {
                    return [.i64(0)]
                }
                return [.i64((UInt64(UInt32(bitPattern: ptrVal)) << 32) | UInt64(bytes.count))]
            })

        self.instance = try module.instantiate(store: store, imports: imports)
    }

    // MARK: ContentSource
    public func search(query: String, page: Int) async throws -> [MediaItem] {
        try call("search", ["query": query, "page": page])
    }
    public func detail(id: String) async throws -> MediaDetail { try call("detail", ["id": id]) }
    public func pages(chapterID: String) async throws -> PageList { try call("pages", ["id": chapterID]) }
    public func stream(episodeID: String) async throws -> StreamInfo { try call("stream", ["id": episodeID]) }

    // MARK: Gọi hàm plugin: JSON vào, JSON ra
    private func call<T: Decodable>(_ fn: String, _ input: [String: Any]) throws -> T {
        lock.lock(); defer { lock.unlock() }
        guard let alloc = instance.exports[function: "alloc"] else { throw PluginError.missingExport("alloc") }
        guard let dealloc = instance.exports[function: "dealloc"] else { throw PluginError.missingExport("dealloc") }
        guard let f = instance.exports[function: fn] else { throw PluginError.missingExport(fn) }

        let json = [UInt8](try JSONSerialization.data(withJSONObject: input))
        guard !json.isEmpty else { throw PluginError.badResult }

        let inPtr = try alloc([.i32(UInt32(json.count))])[0].i32
        guard inPtr > 0,
              let memIn = instance.exports[memory: "memory"],
              Self.writeBytes(memIn, ptr: Int(inPtr), bytes: json)
        else { throw PluginError.badResult }

        let packed: Int64
        do {
            packed = try f([.i32(inPtr), .i32(UInt32(json.count))])[0].i64
        } catch {
            _ = try? dealloc([.i32(inPtr), .i32(UInt32(json.count))])
            throw PluginError.trap("\(error)")
        }

        // Memory có thể đã grow trong lúc plugin chạy (http_get) — lấy lại
        guard let memOut = instance.exports[memory: "memory"] else {
            _ = try? dealloc([.i32(inPtr), .i32(UInt32(json.count))])
            throw PluginError.missingExport("memory")
        }

        let outPtr = Int(UInt32(bitPattern: Int32(truncatingIfNeeded: packed >> 32)))
        let outLen = Int(UInt32(truncatingIfNeeded: packed & 0xFFFF_FFFF))
        guard outLen > 0, outPtr > 0 else {
            _ = try? dealloc([.i32(inPtr), .i32(UInt32(json.count))])
            throw PluginError.badResult
        }
        let out = Self.readBytes(memOut, ptr: outPtr, len: outLen)
        _ = try? dealloc([.i32(inPtr), .i32(UInt32(json.count))])
        if outPtr > 0, outLen > 0 {
            _ = try? dealloc([.i32(Int32(outPtr)), .i32(UInt32(outLen))])
        }
        guard out.count == outLen else { throw PluginError.badResult }
        return try JSONDecoder().decode(T.self, from: Data(out))
    }

    // MARK: Bộ nhớ an toàn (không trap khi out-of-bounds)
    private static func readBytes(_ mem: Memory, ptr: Int, len: Int) -> [UInt8] {
        let data = mem.data
        guard ptr >= 0, len > 0, ptr <= data.count, len <= data.count - ptr else { return [] }
        return Array(data[ptr ..< (ptr + len)])
    }

    @discardableResult
    private static func writeBytes(_ mem: Memory, ptr: Int, bytes: [UInt8]) -> Bool {
        guard !bytes.isEmpty else { return true }
        let data = mem.data
        guard ptr >= 0, ptr <= data.count, bytes.count <= data.count - ptr else { return false }
        mem.withUnsafeMutableBufferPointer(offset: UInt(ptr), count: bytes.count) { buf in
            bytes.withUnsafeBytes { src in buf.copyMemory(from: src) }
        }
        return true
    }

    private static func syncGet(_ url: URL) -> Data {
        let sem = DispatchSemaphore(value: 0)
        var result = Data()
        var req = URLRequest(url: url, timeoutInterval: 25)
        req.setValue(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
            forHTTPHeaderField: "User-Agent"
        )
        req.setValue(
            "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            forHTTPHeaderField: "Accept"
        )
        req.setValue("https://nyaa.media/", forHTTPHeaderField: "Referer")
        URLSession.shared.dataTask(with: req) { d, _, _ in
            result = d ?? Data()
            sem.signal()
        }.resume()
        _ = sem.wait(timeout: .now() + 30)
        return result
    }
}
