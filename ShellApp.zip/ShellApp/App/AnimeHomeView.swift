import SwiftUI
import PluginKit

struct AnimeHomeView: View {
    @EnvironmentObject var progress: ProgressStore
    @EnvironmentObject var plugins: PluginManager
    @State private var items: [AnimeCard] = []
    @State private var error: String?
    @State private var query = ""
    @State private var showResults = false
    @State private var showSettings = false
    @State private var direct: DirectRoute?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    if let hero = items.first(where: { $0.banner != nil }) ?? items.first { HeroView(card: hero) }
                    if let error { Text(error).foregroundColor(.secondary).padding(.horizontal) }

                    if !items.isEmpty {
                        Text("Anime mùa này").font(.title2.bold()).padding(.horizontal)
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(alignment: .top, spacing: 12) {
                                ForEach(items) { c in
                                    NavigationLink(value: c) { PosterCard(card: c) }.buttonStyle(.plain)
                                }
                            }.padding(.horizontal)
                        }
                    }

                    let resume = progress.entries.filter { $0.kind == .anime && $0.lastChapterID != nil }
                    if !resume.isEmpty {
                        Text("Xem tiếp").font(.title2.bold()).padding(.horizontal)
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 12) { ForEach(resume) { EntryLink(entry: $0) } }.padding(.horizontal)
                        }
                    }
                }
                .padding(.bottom, 24)
            }
            .navigationTitle("Anime")
            .navigationBarTitleDisplayMode(.inline)
            .navigationDestination(for: AnimeCard.self) { AnimeDetailView(card: $0) }
            .navigationDestination(isPresented: $showResults) { SourceSearchView(kind: .anime, initialQuery: query) }
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: "Tên anime hoặc link video")
            .onSubmit(of: .search) {
                if let url = DirectLinkSource.parse(query) { direct = DirectRoute(url: url) } else { showResults = true }
            }
            .toolbar {
                Button { showSettings = true } label: { Image(systemName: "gearshape") }
            }
            .sheet(isPresented: $showSettings) { SettingsView() }
            .fullScreenCover(item: $direct) { r in
                PlayerView(source: DirectLinkSource(),
                           item: MediaItem(id: r.url, title: DirectLinkSource.title(for: r.url), coverURL: nil, subtitle: nil),
                           chapter: Chapter(id: r.url, title: "Phát", number: 1),
                           info: StreamInfo(url: r.url),
                           startAt: progress.entry(source: DirectLinkSource.id, item: r.url)?.seconds ?? 0)
            }
            .task { await load() }
        }
    }

    private func load() async {
        guard items.isEmpty else { return }
        do { items = try await AniList.seasonal() } catch { self.error = "Không tải được danh sách anime mùa này." }
    }
}

private struct DirectRoute: Identifiable { let id = UUID(); let url: String }

struct HeroView: View {
    let card: AnimeCard
    var body: some View {
        // Khung này quyết định kích thước; ảnh chỉ nằm ở nền nên không làm rộng layout.
        Color.clear
            .frame(maxWidth: .infinity)
            .frame(height: 460)
            .background(
                AsyncImage(url: card.coverXL ?? card.cover) { $0.resizable().scaledToFill() }
                    placeholder: { Color.gray.opacity(0.2) },
                alignment: .top
            )
            .overlay(LinearGradient(colors: [.clear, .black.opacity(0.55), .black],
                                    startPoint: .center, endPoint: .bottom))
            .overlay(alignment: .bottom) {
                VStack(spacing: 8) {
                    Text("ANIME MÙA NÀY").font(.caption.bold()).tracking(2).foregroundColor(.indigo)
                    Text(card.title)
                        .font(.title.bold())
                        .multilineTextAlignment(.center)
                        .lineLimit(3)
                        .minimumScaleFactor(0.7)
                        .fixedSize(horizontal: false, vertical: true)
                    HStack(spacing: 6) {
                        if let s = card.score {
                            Image(systemName: "star.fill").foregroundColor(.yellow)
                            Text(String(format: "%.1f", s))
                        }
                        Text(card.genres.prefix(3).joined(separator: " · ")).foregroundColor(.secondary)
                    }.font(.subheadline)
                    NavigationLink(value: card) {
                        Label("Xem ngay", systemImage: "play.fill").font(.headline).foregroundColor(.black)
                            .padding(.horizontal, 32).padding(.vertical, 12).background(Capsule().fill(.white))
                    }
                }
                .padding(.horizontal, 20).padding(.bottom, 16)
            }
            .clipped()
    }
}

struct PosterCard: View {
    let card: AnimeCard
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            AsyncImage(url: card.cover) { $0.resizable().scaledToFill() } placeholder: { Color.gray.opacity(0.2) }
                .frame(width: 125, height: 178).clipShape(RoundedRectangle(cornerRadius: 14))
                .overlay(alignment: .topTrailing) {
                    if let s = card.score {
                        Text(String(format: "%.1f", s)).font(.caption.bold()).foregroundColor(.yellow)
                            .padding(.horizontal, 6).padding(.vertical, 3).background(.black.opacity(0.6)).clipShape(Capsule()).padding(6)
                    }
                }
            Text(card.title).font(.subheadline).lineLimit(2).frame(width: 125, alignment: .leading)
            if let e = card.episodes { Text("\(e) tập").font(.caption).foregroundColor(.secondary) }
        }
    }
}

struct AnimeDetailView: View {
    let card: AnimeCard
    @EnvironmentObject var plugins: PluginManager
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack(alignment: .top, spacing: 16) {
                    AsyncImage(url: card.cover) { $0.resizable().scaledToFill() } placeholder: { Color.gray.opacity(0.2) }
                        .frame(width: 120, height: 170).clipShape(RoundedRectangle(cornerRadius: 12))
                    VStack(alignment: .leading, spacing: 6) {
                        Text(card.title).font(.title2.bold())
                        Text(card.genres.joined(separator: " · ")).foregroundColor(.secondary)
                        if let e = card.episodes { Text("\(e) tập").foregroundColor(.secondary) }
                    }
                }
                NavigationLink {
                    SourceSearchView(kind: .anime, initialQuery: card.title)
                } label: {
                    Label("Tìm tập để xem", systemImage: "magnifyingglass")
                        .frame(maxWidth: .infinity).padding().background(RoundedRectangle(cornerRadius: 12).fill(Color.indigo))
                }.foregroundColor(.white)
                if plugins.sources(of: .anime).isEmpty {
                    Text("Chưa cài plugin nguồn anime nào. Thêm plugin trong Cài đặt (biểu tượng bánh răng).")
                        .font(.footnote).foregroundColor(.secondary)
                }
            }.padding()
        }
        .navigationBarTitleDisplayMode(.inline)
    }
}
