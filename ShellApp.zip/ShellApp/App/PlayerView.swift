import SwiftUI
import AVKit
import Combine
import PluginKit

struct ExternalSub: Identifiable {
    let id = UUID()
    let label: String
    let cues: [Cue]
}

/// Trình phát dựa trên AVPlayer: phụ đề nhúng, phụ đề ngoài (online/offline), âm thanh, tốc độ.
/// Phụ đề (cả nhúng lẫn ngoài) đều do app tự vẽ nên chỉnh được vị trí, cỡ chữ và độ lệch.
final class PlayerModel: NSObject, ObservableObject, AVPlayerItemLegibleOutputPushDelegate {
    let player: AVPlayer
    private let info: StreamInfo

    @Published var currentTime = 0.0
    @Published var duration = 0.0
    @Published var isPlaying = false
    @Published var isBuffering = false
    @Published var rate: Float = 1

    @Published var subtitleText = ""        // phụ đề ngoài
    @Published var embeddedText = ""        // phụ đề nhúng trong video
    @Published var externals: [ExternalSub] = []
    @Published var selectedExternal: UUID?
    @Published var subtitleOffset = 0.0
    @Published var fontSize: CGFloat = 20
    @Published var subtitleBottom: CGFloat = 36

    @Published var embeddedSubs: [AVMediaSelectionOption] = []
    @Published var selectedEmbedded: AVMediaSelectionOption?
    @Published var audioOptions: [AVMediaSelectionOption] = []
    @Published var selectedAudio: AVMediaSelectionOption?
    @Published var message: String?

    var isScrubbing = false
    private var legible: AVMediaSelectionGroup?
    private var audible: AVMediaSelectionGroup?
    private var observer: Any?
    private var cancellables = Set<AnyCancellable>()

    init(info: StreamInfo) {
        self.info = info
        let url = URL(string: info.url) ?? URL(string: "about:blank")!
        var opts: [String: Any] = [:]
        if let h = info.headers { opts["AVURLAssetHTTPHeaderFieldsKey"] = h }
        // Link tải của Google không có đuôi file; gợi ý đây là mp4 để AVPlayer chịu phát.
        if url.pathExtension.isEmpty, url.host?.hasSuffix("googleusercontent.com") == true {
            opts["AVURLAssetOutOfBandMIMETypeKey"] = "video/mp4"
        }
        let item = AVPlayerItem(asset: AVURLAsset(url: url, options: opts.isEmpty ? nil : opts))
        player = AVPlayer(playerItem: item)
        super.init()

        // Lấy chữ phụ đề nhúng để tự vẽ (tắt phần vẽ mặc định)
        let out = AVPlayerItemLegibleOutput()
        out.suppressesPlayerRendering = true
        out.setDelegate(self, queue: .main)
        item.add(out)

        item.publisher(for: \.status)
            .receive(on: DispatchQueue.main)
            .sink { [weak self, weak item] st in
                if st == .failed {
                    self?.message = "Không phát được video: \(item?.error?.localizedDescription ?? "lỗi không rõ"). Link có thể đã hết hạn hoặc cần đăng nhập."
                }
            }
            .store(in: &cancellables)

        player.publisher(for: \.timeControlStatus)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] s in
                self?.isPlaying = (s == .playing)
                self?.isBuffering = (s == .waitingToPlayAtSpecifiedRate)
            }
            .store(in: &cancellables)
    }

    func legibleOutput(_ output: AVPlayerItemLegibleOutput,
                       didOutputAttributedStrings strings: [NSAttributedString],
                       nativeSampleBuffers nativeSamples: [Any],
                       forItemTime itemTime: CMTime) {
        embeddedText = strings.map { $0.string }.joined(separator: "\n")
    }

    /// Phụ đề đang hiển thị
    var displayText: String { selectedExternal != nil ? subtitleText : embeddedText }

    // MARK: Phát
    func start(at seconds: Double) {
        guard observer == nil else { return }
        if seconds > 5 { player.seek(to: CMTime(seconds: seconds, preferredTimescale: 600)) }
        observer = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.2, preferredTimescale: 600), queue: .main) { [weak self] t in
            self?.tick(t.seconds)
        }
        player.play()
    }

    func stop() {
        if let o = observer { player.removeTimeObserver(o); observer = nil }
        player.pause()
    }

    var currentSeconds: Double { player.currentTime().seconds }

    func togglePlay() {
        if player.timeControlStatus == .paused { player.play(); player.rate = rate } else { player.pause() }
    }

    func seek(to seconds: Double) {
        let t = max(0, min(seconds, duration > 0 ? duration : seconds))
        currentTime = t
        player.seek(to: CMTime(seconds: t, preferredTimescale: 600))
    }

    func skip(_ delta: Double) { seek(to: currentTime + delta) }

    func setRate(_ r: Float) {
        rate = r
        player.defaultRate = r
        if player.timeControlStatus == .playing { player.rate = r }
    }

    private func tick(_ t: Double) {
        if !isScrubbing { currentTime = t }
        if let d = player.currentItem?.duration.seconds, d.isFinite, d > 0, d != duration { duration = d }
        guard let id = selectedExternal, let sub = externals.first(where: { $0.id == id }) else {
            if !subtitleText.isEmpty { subtitleText = "" }
            return
        }
        let x = t - subtitleOffset
        let text = sub.cues.filter { $0.start <= x && x < $0.end }.map(\.text).joined(separator: "\n")
        if text != subtitleText { subtitleText = text }
    }

    // MARK: Âm thanh và phụ đề nhúng
    func loadOptions() async {
        guard let item = player.currentItem else { return }
        let leg = try? await item.asset.loadMediaSelectionGroup(for: .legible)
        let aud = try? await item.asset.loadMediaSelectionGroup(for: .audible)
        await MainActor.run {
            legible = leg; audible = aud
            embeddedSubs = leg?.options ?? []
            audioOptions = aud?.options ?? []
            selectedEmbedded = leg.flatMap { item.currentMediaSelection.selectedMediaOption(in: $0) }
            selectedAudio = aud.flatMap { item.currentMediaSelection.selectedMediaOption(in: $0) }
        }
    }

    func selectAudio(_ o: AVMediaSelectionOption) {
        guard let g = audible else { return }
        player.currentItem?.select(o, in: g); selectedAudio = o
    }

    func selectEmbedded(_ o: AVMediaSelectionOption?) {
        if let g = legible { player.currentItem?.select(o, in: g) }
        selectedEmbedded = o
        selectedExternal = nil; subtitleText = ""
        if o == nil { embeddedText = "" }
    }

    // MARK: Phụ đề ngoài
    func selectExternal(_ id: UUID?) {
        selectedExternal = id
        embeddedText = ""
        if id != nil, let g = legible { player.currentItem?.select(nil, in: g); selectedEmbedded = nil }
        if id == nil { subtitleText = "" }
    }

    func addExternalData(label: String, data: Data, select: Bool = true) {
        let cues = SubtitleParser.parse(SubtitleParser.decode(data))
        guard !cues.isEmpty else { message = "Không đọc được phụ đề \"\(label)\"."; return }
        let sub = ExternalSub(label: label, cues: cues)
        externals.append(sub)
        if select { selectExternal(sub.id) }
    }

    func addExternal(url: URL, label: String, headers: [String: String]? = nil, select: Bool = true) async {
        var req = URLRequest(url: url)
        headers?.forEach { req.setValue($1, forHTTPHeaderField: $0) }
        do {
            let (data, _) = try await URLSession.shared.data(for: req)
            await MainActor.run { addExternalData(label: label, data: data, select: select) }
        } catch {
            await MainActor.run { message = "Không tải được phụ đề: \(error.localizedDescription)" }
        }
    }

    func loadPluginSubs() async {
        for s in info.subtitles ?? [] {
            guard let url = URL(string: s.url) else { continue }
            await addExternal(url: url, label: s.label, headers: info.headers,
                              select: (s.language ?? "").hasPrefix("vi") && selectedExternal == nil)
        }
    }
}

// MARK: - Mặt phẳng video và nút AirPlay

final class PlayerLayerView: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
}

struct VideoSurface: UIViewRepresentable {
    let player: AVPlayer
    func makeUIView(context: Context) -> PlayerLayerView {
        let v = PlayerLayerView()
        v.backgroundColor = .black
        v.playerLayer.player = player
        v.playerLayer.videoGravity = .resizeAspect
        return v
    }
    func updateUIView(_ uiView: PlayerLayerView, context: Context) {}
}

struct AirPlayButton: UIViewRepresentable {
    func makeUIView(context: Context) -> AVRoutePickerView {
        let v = AVRoutePickerView()
        v.tintColor = .white
        v.activeTintColor = .systemBlue
        v.prioritizesVideoDevices = true
        return v
    }
    func updateUIView(_ uiView: AVRoutePickerView, context: Context) {}
}

// MARK: - Màn hình trình phát

struct PlayerView: View {
    let source: ContentSource
    let item: MediaItem
    let chapter: Chapter
    let startAt: Double
    @EnvironmentObject var progress: ProgressStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var model: PlayerModel

    @State private var controlsVisible = true
    @State private var showPanel = false
    @State private var scrubTime: Double?
    @State private var hideWork: DispatchWorkItem?
    @State private var showURLPrompt = false
    @State private var urlText = ""

    init(source: ContentSource, item: MediaItem, chapter: Chapter, info: StreamInfo, startAt: Double) {
        self.source = source; self.item = item; self.chapter = chapter; self.startAt = startAt
        _model = StateObject(wrappedValue: PlayerModel(info: info))
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
                .alert("Phụ đề từ URL", isPresented: $showURLPrompt) {
                    TextField("https://…/phude.srt", text: $urlText)
                    Button("Tải") {
                        let text = urlText.trimmingCharacters(in: .whitespaces); urlText = ""
                        guard let url = URL(string: text) else { model.message = "URL không hợp lệ."; return }
                        Task { await model.addExternal(url: url, label: url.lastPathComponent) }
                    }
                    Button("Huỷ", role: .cancel) { urlText = "" }
                }

            VideoSurface(player: model.player).ignoresSafeArea()

            // Lớp bắt chạm: chạm để hiện/ẩn điều khiển, vuốt xuống để đóng
            Color.clear.contentShape(Rectangle()).ignoresSafeArea()
                .onTapGesture { tapBackground() }
                .gesture(DragGesture(minimumDistance: 30).onEnded { v in
                    if v.translation.height > 140 && abs(v.translation.width) < 100 { dismiss() }
                })

            subtitleView

            if model.isBuffering { ProgressView().tint(.white).scaleEffect(1.5) }

            if controlsVisible { controls.transition(.opacity) }
            if showPanel { panel.transition(.opacity) }
        }
        .statusBarHidden(true)
        .task {
            model.start(at: startAt)
            await model.loadOptions()
            await model.loadPluginSubs()
        }
        .onChange(of: model.isPlaying) { _ in poke() }
        .onDisappear {
            hideWork?.cancel()
            let t = model.currentSeconds
            model.stop()
            progress.update(source: source, item: item) {
                $0.lastChapterID = chapter.id; $0.lastChapterTitle = chapter.title; $0.seconds = t.isFinite ? t : 0
            }
        }
        .alert("Thông báo", isPresented: Binding(get: { model.message != nil }, set: { if !$0 { model.message = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(model.message ?? "") }
    }

    // MARK: Ẩn/hiện điều khiển
    private func poke() {
        withAnimation(.easeInOut(duration: 0.2)) { controlsVisible = true }
        hideWork?.cancel()
        guard model.isPlaying, !showPanel, scrubTime == nil else { return }
        let w = DispatchWorkItem { withAnimation(.easeInOut(duration: 0.25)) { controlsVisible = false } }
        hideWork = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 4, execute: w)
    }

    private func tapBackground() {
        if showPanel { withAnimation { showPanel = false }; poke(); return }
        if controlsVisible {
            hideWork?.cancel()
            withAnimation(.easeInOut(duration: 0.2)) { controlsVisible = false }
        } else { poke() }
    }

    // MARK: Phụ đề
    private var subtitleView: some View {
        VStack {
            Spacer()
            if !model.displayText.isEmpty {
                Text(model.displayText)
                    .font(.system(size: model.fontSize, weight: .semibold))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .shadow(color: .black, radius: 2).shadow(color: .black, radius: 2)
                    .padding(.horizontal, 24)
                    .padding(.bottom, model.subtitleBottom + (controlsVisible ? 90 : 0))
            }
        }
        .animation(.easeInOut(duration: 0.2), value: controlsVisible)
        .allowsHitTesting(false)
    }

    // MARK: Điều khiển
    private func clock(_ s: Double) -> String {
        guard s.isFinite, s >= 0 else { return "0:00" }
        let t = Int(s), h = t / 3600, m = (t % 3600) / 60, sec = t % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, sec) : String(format: "%d:%02d", m, sec)
    }

    private var controls: some View {
        ZStack {
            LinearGradient(colors: [.black.opacity(0.45), .clear, .black.opacity(0.65)], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea().allowsHitTesting(false)

            HStack(spacing: 56) {
                Button { model.skip(-10); poke() } label: { Image(systemName: "gobackward.10").font(.system(size: 34)) }
                Button { model.togglePlay() } label: {
                    Image(systemName: model.isPlaying ? "pause.fill" : "play.fill").font(.system(size: 50)).frame(width: 60)
                }
                Button { model.skip(10); poke() } label: { Image(systemName: "goforward.10").font(.system(size: 34)) }
            }
            .foregroundColor(.white)

            VStack {
                Spacer()
                VStack(spacing: 8) {
                    HStack(spacing: 10) {
                        Text(clock(scrubTime ?? model.currentTime)).font(.caption.monospacedDigit()).foregroundColor(.white)
                        Slider(
                            value: Binding(get: { scrubTime ?? model.currentTime }, set: { scrubTime = $0 }),
                            in: 0...max(model.duration, 1),
                            onEditingChanged: { editing in
                                if editing { model.isScrubbing = true; hideWork?.cancel() }
                                else {
                                    model.seek(to: scrubTime ?? model.currentTime)
                                    scrubTime = nil; model.isScrubbing = false; poke()
                                }
                            }
                        ).tint(.white)
                        Text("-" + clock(max(model.duration - (scrubTime ?? model.currentTime), 0)))
                            .font(.caption.monospacedDigit()).foregroundColor(.white)
                    }
                    HStack(spacing: 18) {
                        Spacer()
                        AirPlayButton().frame(width: 32, height: 32)
                        Button {
                            withAnimation { showPanel.toggle() }
                            if showPanel { hideWork?.cancel() } else { poke() }
                        } label: {
                            Image(systemName: "captions.bubble").font(.system(size: 22)).foregroundColor(.white)
                                .frame(width: 32, height: 32)
                        }
                    }
                }
                .padding(.horizontal, 20).padding(.bottom, 10)
            }
        }
    }

    // MARK: Bảng tuỳ chọn (thay cho nút ba chấm)
    private var noSubtitle: Bool { model.selectedExternal == nil && model.selectedEmbedded == nil }

    private func header(_ t: String) -> some View {
        Text(t.uppercased()).font(.caption.bold()).foregroundColor(.white.opacity(0.6)).padding(.top, 6)
    }
    private func row(_ title: String, on: Bool = false, tint: Color = .white, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack { Text(title).lineLimit(1); Spacer(); if on { Image(systemName: "checkmark") } }
                .padding(.vertical, 5).contentShape(Rectangle())
        }.foregroundColor(tint)
    }
    private func chip(_ title: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title).font(.footnote.bold()).lineLimit(1)
                .padding(.horizontal, 10).padding(.vertical, 7)
                .background(Color.white.opacity(0.18)).clipShape(Capsule())
        }.foregroundColor(.white)
    }

    private var panel: some View {
        ZStack(alignment: .bottomTrailing) {
            Color.black.opacity(0.001).ignoresSafeArea().onTapGesture { tapBackground() }
            ScrollView {
                VStack(alignment: .leading, spacing: 4) {
                    header("Phụ đề")
                    row("Tắt", on: noSubtitle) { model.selectEmbedded(nil) }
                    ForEach(Array(model.embeddedSubs.enumerated()), id: \.offset) { _, o in
                        row(o.displayName, on: model.selectedEmbedded == o) { model.selectEmbedded(o) }
                    }
                    ForEach(model.externals) { s in
                        row(s.label, on: model.selectedExternal == s.id) { model.selectExternal(s.id) }
                    }
                    row("Thêm từ file…") {
                        showPanel = false
                        DocPicker.present { url in
                            if let d = try? Data(contentsOf: url) {
                                model.addExternalData(label: url.deletingPathExtension().lastPathComponent, data: d)
                            } else { model.message = "Không đọc được file." }
                        }
                    }
                    row("Thêm từ URL…") { showPanel = false; showURLPrompt = true }

                    header("Vị trí và kiểu chữ")
                    HStack {
                        chip("Lên ↑") { model.subtitleBottom = min(model.subtitleBottom + 20, 400) }
                        chip("Xuống ↓") { model.subtitleBottom = max(model.subtitleBottom - 20, 0) }
                        chip("A+") { model.fontSize = min(model.fontSize + 2, 40) }
                        chip("A−") { model.fontSize = max(model.fontSize - 2, 12) }
                    }
                    HStack {
                        chip("Sớm 0,5s") { model.subtitleOffset -= 0.5 }
                        chip("Muộn 0,5s") { model.subtitleOffset += 0.5 }
                        chip("Đặt lại (\(String(format: "%+.1f", model.subtitleOffset)))") { model.subtitleOffset = 0 }
                    }

                    header("Âm thanh")
                    if model.audioOptions.isEmpty {
                        Text("Chỉ có một luồng âm thanh").font(.footnote).foregroundColor(.white.opacity(0.6))
                    }
                    ForEach(Array(model.audioOptions.enumerated()), id: \.offset) { _, o in
                        row(o.displayName, on: model.selectedAudio == o) { model.selectAudio(o) }
                    }

                    header("Tốc độ")
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 58))], alignment: .leading) {
                        ForEach([Float(0.5), 0.75, 1, 1.25, 1.5, 2], id: \.self) { r in
                            chip("\(String(format: "%g", r))×" + (model.rate == r ? " ✓" : "")) { model.setRate(r) }
                        }
                    }

                    Divider().background(Color.white.opacity(0.3)).padding(.vertical, 6)
                    row("Đóng trình phát", tint: .red) { dismiss() }
                }
                .padding(14)
            }
            .frame(width: 310)
            .frame(maxHeight: 340)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .padding(.trailing, 16).padding(.bottom, 96)
        }
    }
}
