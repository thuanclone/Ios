import SwiftUI
import AVKit
import PluginKit

struct ExternalSub: Identifiable {
    let id = UUID()
    let label: String
    let cues: [Cue]
}

/// Trình phát dựa trên AVPlayer: phụ đề nhúng, phụ đề ngoài (online/offline), âm thanh, tốc độ.
final class PlayerModel: ObservableObject {
    let player: AVPlayer
    private let info: StreamInfo

    @Published var subtitleText = ""
    @Published var externals: [ExternalSub] = []
    @Published var selectedExternal: UUID?
    @Published var subtitleOffset = 0.0
    @Published var fontSize: CGFloat = 20
    @Published var rate: Float = 1
    @Published var embeddedSubs: [AVMediaSelectionOption] = []
    @Published var selectedEmbedded: AVMediaSelectionOption?
    @Published var audioOptions: [AVMediaSelectionOption] = []
    @Published var selectedAudio: AVMediaSelectionOption?
    @Published var message: String?

    private var legible: AVMediaSelectionGroup?
    private var audible: AVMediaSelectionGroup?
    private var observer: Any?

    init(info: StreamInfo) {
        self.info = info
        let url = URL(string: info.url) ?? URL(string: "about:blank")!
        let opts: [String: Any]? = info.headers.map { ["AVURLAssetHTTPHeaderFieldsKey": $0] }
        player = AVPlayer(playerItem: AVPlayerItem(asset: AVURLAsset(url: url, options: opts)))
    }

    var currentSeconds: Double { player.currentTime().seconds }

    func start(at seconds: Double) {
        guard observer == nil else { return }
        if seconds > 5 { player.seek(to: CMTime(seconds: seconds, preferredTimescale: 600)) }
        observer = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.2, preferredTimescale: 600), queue: .main) { [weak self] t in
            self?.tick(t.seconds)
        }
        player.play()
    }

    func stop() {
        if let o = observer { player.removeTimeObserver(o); observer = nil }
        player.pause()
    }

    private func tick(_ t: Double) {
        guard let id = selectedExternal, let sub = externals.first(where: { $0.id == id }) else {
            if !subtitleText.isEmpty { subtitleText = "" }
            return
        }
        let x = t - subtitleOffset
        let text = sub.cues.filter { $0.start <= x && x < $0.end }.map(\.text).joined(separator: "\n")
        if text != subtitleText { subtitleText = text }
    }

    // MARK: Âm thanh và phụ đề nhúng (HLS/MP4 có sẵn nhiều luồng)
    func loadOptions() async {
        guard let item = player.currentItem else { return }
        let leg = try? await item.asset.loadMediaSelectionGroup(for: .legible)
        let aud = try? await item.asset.loadMediaSelectionGroup(for: .audible)
        await MainActor.run {
            legible = leg; audible = aud
            embeddedSubs = leg?.options ?? []
            audioOptions = aud?.options ?? []
            selectedEmbedded = leg.flatMap { item.currentMediaSelection.selectedMediaOption(in: $0) }
            selectedAudio = aud.flatMap { item.currentMediaSelection.selectedMediaOption(in: $0) }
        }
    }

    func selectAudio(_ o: AVMediaSelectionOption) {
        guard let g = audible else { return }
        player.currentItem?.select(o, in: g); selectedAudio = o
    }

    func selectEmbedded(_ o: AVMediaSelectionOption?) {
        if let g = legible { player.currentItem?.select(o, in: g) }
        selectedEmbedded = o
        selectedExternal = nil; subtitleText = ""
    }

    // MARK: Phụ đề ngoài
    func selectExternal(_ id: UUID?) {
        selectedExternal = id
        if id != nil, let g = legible { player.currentItem?.select(nil, in: g); selectedEmbedded = nil }
        if id == nil { subtitleText = "" }
    }

    func addExternalData(label: String, data: Data, select: Bool = true) {
        let cues = SubtitleParser.parse(SubtitleParser.decode(data))
        guard !cues.isEmpty else { message = "Không đọc được phụ đề \"\(label)\"."; return }
        let sub = ExternalSub(label: label, cues: cues)
        externals.append(sub)
        if select { selectExternal(sub.id) }
    }

    func addExternal(url: URL, label: String, headers: [String: String]? = nil, select: Bool = true) async {
        var req = URLRequest(url: url)
        headers?.forEach { req.setValue($1, forHTTPHeaderField: $0) }
        do {
            let (data, _) = try await URLSession.shared.data(for: req)
            await MainActor.run { addExternalData(label: label, data: data, select: select) }
        } catch {
            await MainActor.run { message = "Không tải được phụ đề: \(error.localizedDescription)" }
        }
    }

    func loadPluginSubs() async {
        for s in info.subtitles ?? [] {
            guard let url = URL(string: s.url) else { continue }
            await addExternal(url: url, label: s.label, headers: info.headers,
                              select: (s.language ?? "").hasPrefix("vi") && selectedExternal == nil)
        }
    }

    func setRate(_ r: Float) {
        rate = r
        player.defaultRate = r
        if player.timeControlStatus == .playing { player.rate = r }
    }
}

/// Điều khiển gốc của iOS (tua, AirPlay, hình trong hình…).
struct NativePlayer: UIViewControllerRepresentable {
    let player: AVPlayer
    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let vc = AVPlayerViewController()
        vc.player = player
        vc.allowsPictureInPicturePlayback = true
        vc.showsPlaybackControls = true
        return vc
    }
    func updateUIViewController(_ vc: AVPlayerViewController, context: Context) {}
}

struct PlayerView: View {
    let source: ContentSource
    let item: MediaItem
    let chapter: Chapter
    let startAt: Double
    @EnvironmentObject var progress: ProgressStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var model: PlayerModel
    @State private var showURLPrompt = false
    @State private var urlText = ""

    init(source: ContentSource, item: MediaItem, chapter: Chapter, info: StreamInfo, startAt: Double) {
        self.source = source; self.item = item; self.chapter = chapter; self.startAt = startAt
        _model = StateObject(wrappedValue: PlayerModel(info: info))
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            NativePlayer(player: model.player).ignoresSafeArea()

            VStack {
                Spacer()
                if !model.subtitleText.isEmpty {
                    Text(model.subtitleText)
                        .font(.system(size: model.fontSize, weight: .semibold))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                        .shadow(color: .black, radius: 2).shadow(color: .black, radius: 2)
                        .padding(.horizontal, 24).padding(.bottom, 90)
                }
            }
            .allowsHitTesting(false)

            VStack {
                HStack { menu; Spacer() }
                Spacer()
            }
            .padding()
            .alert("Phụ đề từ URL", isPresented: $showURLPrompt) {
                TextField("https://…/phude.srt", text: $urlText)
                Button("Tải") {
                    let text = urlText.trimmingCharacters(in: .whitespaces); urlText = ""
                    guard let url = URL(string: text) else { model.message = "URL không hợp lệ."; return }
                    Task { await model.addExternal(url: url, label: url.lastPathComponent) }
                }
                Button("Huỷ", role: .cancel) { urlText = "" }
            }
        }
        .statusBarHidden(true)
        .task {
            model.start(at: startAt)
            await model.loadOptions()
            await model.loadPluginSubs()
        }
        .onDisappear {
            let t = model.currentSeconds
            model.stop()
            progress.update(source: source, item: item) {
                $0.lastChapterID = chapter.id; $0.lastChapterTitle = chapter.title; $0.seconds = t.isFinite ? t : 0
            }
        }
        .alert("Thông báo", isPresented: Binding(get: { model.message != nil }, set: { if !$0 { model.message = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(model.message ?? "") }
    }

    @ViewBuilder private func check(_ title: String, _ on: Bool) -> some View {
        if on { Label(title, systemImage: "checkmark") } else { Text(title) }
    }

    private var noSubtitle: Bool { model.selectedExternal == nil && model.selectedEmbedded == nil }

    private var menu: some View {
        Menu {
            Menu("Phụ đề") {
                Button { model.selectEmbedded(nil) } label: { check("Tắt", noSubtitle) }
                ForEach(Array(model.embeddedSubs.enumerated()), id: \.offset) { _, o in
                    Button { model.selectEmbedded(o) } label: { check(o.displayName, model.selectedEmbedded == o) }
                }
                ForEach(model.externals) { s in
                    Button { model.selectExternal(s.id) } label: { check(s.label, model.selectedExternal == s.id) }
                }
                Divider()
                Button("Thêm từ file…") {
                    DocPicker.present { url in
                        if let d = try? Data(contentsOf: url) {
                            model.addExternalData(label: url.deletingPathExtension().lastPathComponent, data: d)
                        } else { model.message = "Không đọc được file." }
                    }
                }
                Button("Thêm từ URL…") { showURLPrompt = true }
                Divider()
                Button("Sớm hơn 0,5 giây") { model.subtitleOffset -= 0.5 }
                Button("Muộn hơn 0,5 giây") { model.subtitleOffset += 0.5 }
                Button("Đặt lại độ lệch (\(String(format: "%+.1f", model.subtitleOffset))s)") { model.subtitleOffset = 0 }
                Button("Chữ to hơn") { model.fontSize = min(model.fontSize + 2, 40) }
                Button("Chữ nhỏ hơn") { model.fontSize = max(model.fontSize - 2, 12) }
            }
            Menu("Âm thanh") {
                if model.audioOptions.isEmpty {
                    Button("Chỉ có một luồng âm thanh") {}.disabled(true)
                }
                ForEach(Array(model.audioOptions.enumerated()), id: \.offset) { _, o in
                    Button { model.selectAudio(o) } label: { check(o.displayName, model.selectedAudio == o) }
                }
            }
            Menu("Tốc độ") {
                ForEach([Float(0.5), 0.75, 1, 1.25, 1.5, 2], id: \.self) { r in
                    Button { model.setRate(r) } label: { check("\(String(format: "%g", r))×", model.rate == r) }
                }
            }
            Divider()
            Button("Đóng trình phát", role: .destructive) { dismiss() }
        } label: {
            Image(systemName: "captions.bubble")
                .font(.title3).foregroundColor(.white)
                .padding(10).background(.ultraThinMaterial).clipShape(Circle())
        }
    }
}
