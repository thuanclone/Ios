import SwiftUI
import AVKit
import Combine
import PluginKit

enum EngineKind: String, CaseIterable {
    case apple, vlc
    var title: String { self == .apple ? "Apple (AVPlayer)" : "VLC (mọi định dạng)" }
    var subtitle: String { self == .apple ? "Nhẹ, tiết kiệm pin: mp4, mov, HLS" : "MKV, AVI, WebM và nhiều codec khác" }
}

/// Một luồng âm thanh hoặc phụ đề nhúng, của engine nào cũng dùng chung kiểu này.
struct TrackChoice: Identifiable {
    let id: String
    let name: String
    let apple: AVMediaSelectionOption?
    let vlcIndex: Int32?
}

struct ExternalSub: Identifiable {
    let id = UUID()
    let label: String
    let cues: [Cue]
}

/// Mô hình trình phát: giữ trạng thái chung và điều khiển engine đang chọn (Apple hoặc VLC).
/// Phụ đề ngoài luôn do app vẽ; phụ đề nhúng do app vẽ (Apple) hoặc do VLC vẽ (VLC).
final class PlayerModel: NSObject, ObservableObject, AVPlayerItemLegibleOutputPushDelegate {
    let player = AVPlayer()
    let vlcView: UIView = {
        let v = UIView(); v.backgroundColor = .black; v.clipsToBounds = true; return v
    }()
    private let info: StreamInfo
    private let url: URL
    private let assetOptions: [String: Any]?
    private var triedVLC = false

    @Published var engine: EngineKind = .apple
    @Published var currentTime = 0.0
    @Published var duration = 0.0
    @Published var isPlaying = false
    @Published var isBuffering = false
    @Published var rate: Float = 1

    @Published var subtitleText = ""
    @Published var embeddedText = ""
    @Published var externals: [ExternalSub] = []
    @Published var selectedExternal: UUID?
    @Published var subtitleOffset = 0.0
    @Published var fontSize: CGFloat = 20
    @Published var subtitleBottom: CGFloat = 36

    @Published var embeddedChoices: [TrackChoice] = []
    @Published var audioChoices: [TrackChoice] = []
    @Published var selectedEmbeddedID: String?
    @Published var selectedAudioID: String?
    @Published var message: String?
    @Published var toast: String?

    var isScrubbing = false
    private var vlc: VLCBackend?
    private var vlcTicks = 0
    private var activationID = 0
    private var vlcStateLog: [String] = []
    private var legible: AVMediaSelectionGroup?
    private var audible: AVMediaSelectionGroup?
    private var timer: Timer?
    private var cancellables = Set<AnyCancellable>()
    private var itemCancellables = Set<AnyCancellable>()

    init(info: StreamInfo) {
        self.info = info
        let u = URL(string: info.url) ?? URL(string: "about:blank")!
        url = u
        var opts: [String: Any] = [:]
        if let h = info.headers { opts["AVURLAssetHTTPHeaderFieldsKey"] = h }
        // Link tải của Google không có đuôi file; gợi ý đây là mp4 để AVPlayer chịu phát.
        if u.pathExtension.isEmpty, u.host?.hasSuffix("googleusercontent.com") == true {
            opts["AVURLAssetOutOfBandMIMETypeKey"] = "video/mp4"
        }
        assetOptions = opts.isEmpty ? nil : opts
        super.init()
        engine = Self.preferredEngine(for: u)

        player.publisher(for: \.timeControlStatus)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] s in
                guard let self = self, self.engine == .apple else { return }
                self.isPlaying = (s == .playing)
                self.isBuffering = (s == .waitingToPlayAtSpecifiedRate)
            }
            .store(in: &cancellables)
    }

    /// Định dạng iOS không phát được thì đi thẳng VLC.
    static func preferredEngine(for url: URL) -> EngineKind {
        let ext = url.pathExtension.lowercased()
        let needsVLC = ["mkv", "avi", "wmv", "flv", "webm", "rmvb", "ts", "m2ts", "mpg", "mpeg", "ogv", "divx"].contains(ext)
        return (needsVLC && VLCBackend.isAvailable) ? .vlc : .apple
    }

    // MARK: Vòng đời
    func start(at seconds: Double) {
        guard timer == nil else { return }
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .moviePlayback)
        try? session.setActive(true)
        activate(engine, resumeAt: seconds)
        timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] _ in self?.tick() }
    }

    func stop() {
        timer?.invalidate(); timer = nil
        deactivate()
    }

    private func deactivate() {
        activationID += 1
        itemCancellables.removeAll()
        player.pause()
        player.replaceCurrentItem(with: nil)
        vlc?.stop(); vlc = nil
        vlcTicks = 0
    }

    private func activate(_ e: EngineKind, resumeAt t: Double) {
        deactivate()
        engine = e
        currentTime = t
        embeddedChoices = []; audioChoices = []
        selectedEmbeddedID = nil; selectedAudioID = nil
        embeddedText = ""
        isBuffering = true
        switch e {
        case .apple: setupApple(resumeAt: t)
        case .vlc: setupVLC(resumeAt: t)
        }
    }

    func switchEngine(_ e: EngineKind) {
        guard e != engine else { return }
        if e == .vlc && !VLCBackend.isAvailable { message = "Bản build này chưa có VLC."; return }
        activate(e, resumeAt: currentTime)
    }

    var currentSeconds: Double {
        switch engine {
        case .apple: return player.currentTime().seconds
        case .vlc: return vlc?.currentSeconds ?? currentTime
        }
    }

    // MARK: Engine Apple
    private func setupApple(resumeAt t: Double) {
        let item = AVPlayerItem(asset: AVURLAsset(url: url, options: assetOptions))
        let out = AVPlayerItemLegibleOutput()
        out.suppressesPlayerRendering = true
        out.setDelegate(self, queue: .main)
        item.add(out)

        let url = self.url
        item.publisher(for: \.status)
            .receive(on: DispatchQueue.main)
            .sink { [weak self, weak item] st in
                guard let self = self, st == .failed else { return }
                self.appleFailed(item?.error)
            }
            .store(in: &itemCancellables)

        NotificationCenter.default.publisher(for: .AVPlayerItemNewErrorLogEntry, object: item)
            .receive(on: DispatchQueue.main)
            .sink { [weak self, weak item] _ in
                guard let self = self, self.message == nil, let ev = item?.errorLog()?.events.last else { return }
                self.message = "Lỗi khi tải luồng (mã \(ev.errorStatusCode)): \(ev.errorComment ?? ev.errorDomain)\n\(ev.uri ?? "")"
            }
            .store(in: &itemCancellables)

        NotificationCenter.default.publisher(for: .AVPlayerItemFailedToPlayToEndTime, object: item)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] n in
                guard let self = self, self.message == nil else { return }
                self.message = Self.explain(n.userInfo?[AVPlayerItemFailedToPlayToEndTimeErrorKey] as? Error, url: url)
            }
            .store(in: &itemCancellables)

        player.replaceCurrentItem(with: item)
        player.defaultRate = rate
        if t > 5 { player.seek(to: CMTime(seconds: t, preferredTimescale: 600)) }
        player.play()
        Task { await loadAppleOptions(item) }
    }

    private func appleFailed(_ error: Error?) {
        if VLCBackend.isAvailable, !triedVLC {
            triedVLC = true
            showToast("Trình phát Apple không mở được video này, đã chuyển sang VLC.")
            DispatchQueue.main.async { self.activate(.vlc, resumeAt: self.currentTime) }
        } else {
            message = Self.explain(error, url: url)
        }
    }

    private func loadAppleOptions(_ item: AVPlayerItem) async {
        let leg = try? await item.asset.loadMediaSelectionGroup(for: .legible)
        let aud = try? await item.asset.loadMediaSelectionGroup(for: .audible)
        await MainActor.run {
            guard engine == .apple, player.currentItem === item else { return }
            legible = leg; audible = aud
            func choices(_ g: AVMediaSelectionGroup?) -> [TrackChoice] {
                (g?.options ?? []).enumerated().map {
                    TrackChoice(id: "a\($0.offset)", name: $0.element.displayName, apple: $0.element, vlcIndex: nil)
                }
            }
            embeddedChoices = choices(leg)
            audioChoices = choices(aud)
            if let g = leg, let sel = item.currentMediaSelection.selectedMediaOption(in: g),
               let i = g.options.firstIndex(of: sel) { selectedEmbeddedID = "a\(i)" }
            if let g = aud, let sel = item.currentMediaSelection.selectedMediaOption(in: g),
               let i = g.options.firstIndex(of: sel) { selectedAudioID = "a\(i)" }
        }
    }

    func legibleOutput(_ output: AVPlayerItemLegibleOutput,
                       didOutputAttributedStrings strings: [NSAttributedString],
                       nativeSampleBuffers nativeSamples: [Any],
                       forItemTime itemTime: CMTime) {
        embeddedText = strings.map { $0.string }.joined(separator: "\n")
    }

    // MARK: Engine VLC
    private func setupVLC(resumeAt t: Double) {
        guard VLCBackend.isAvailable else { message = "Bản build này chưa có VLC."; return }
        vlcStateLog = []
        let id = activationID
        // VLC cần khung hiển thị đã nằm trong cửa sổ; lúc vừa đổi engine SwiftUI chưa kịp vẽ nên phải chờ.
        whenAttached(40) { [weak self] in
            guard let self = self, self.activationID == id, self.engine == .vlc else { return }
            let b = VLCBackend(view: self.vlcView, url: self.url, headers: self.info.headers, start: t, rate: self.rate)
            b.onState = { [weak self] s in self?.vlcState(s) }
            self.vlc = b
        }
    }

    private func whenAttached(_ tries: Int, _ work: @escaping () -> Void) {
        if vlcView.window != nil || tries <= 0 { work(); return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { [weak self] in self?.whenAttached(tries - 1, work) }
    }

    private func vlcState(_ s: VLCPlayState) {
        guard engine == .vlc else { return }
        vlcStateLog.append("\(s)")
        switch s {
        case .playing: isPlaying = true; isBuffering = false
        case .paused: isPlaying = false; isBuffering = false
        case .opening: isBuffering = true
        case .buffering: isBuffering = !(vlc?.isPlaying ?? false)
        case .stopped, .ended: isPlaying = false; isBuffering = false
        case .error:
            isBuffering = false
            message = "VLC không mở được video này.\n\(vlc?.debugInfo ?? "")\n\nNhật ký VLC:\n\(vlc?.logSummary ?? "")"
        }
    }

    private func refreshVLCTracks() {
        guard let v = vlc else { return }
        let aud = v.audioTracks.filter { $0.index >= 0 }
        let sub = v.subtitleTracks.filter { $0.index >= 0 }
        guard !aud.isEmpty || !sub.isEmpty else { return }
        audioChoices = aud.map { TrackChoice(id: "v\($0.index)", name: $0.name, apple: nil, vlcIndex: $0.index) }
        embeddedChoices = sub.map { TrackChoice(id: "v\($0.index)", name: $0.name, apple: nil, vlcIndex: $0.index) }
        selectedAudioID = "v\(v.currentAudio)"
        let cs = v.currentSubtitle
        selectedEmbeddedID = (cs >= 0 && selectedExternal == nil) ? "v\(cs)" : nil
        vlcTicks = 60
    }

    // MARK: Điều khiển chung
    func togglePlay() {
        switch engine {
        case .apple:
            if player.timeControlStatus == .paused { player.play() } else { player.pause() }
        case .vlc:
            guard let v = vlc else { return }
            if v.isPlaying { v.pause(); isPlaying = false } else { v.play(); isPlaying = true }
        }
    }

    func seek(to seconds: Double) {
        let t = max(0, duration > 0 ? min(seconds, duration) : seconds)
        currentTime = t
        switch engine {
        case .apple: player.seek(to: CMTime(seconds: t, preferredTimescale: 600))
        case .vlc: vlc?.seek(to: t)
        }
    }

    func skip(_ delta: Double) { seek(to: currentTime + delta) }

    func setRate(_ r: Float) {
        rate = r
        player.defaultRate = r
        if engine == .apple, player.timeControlStatus == .playing { player.rate = r }
        if engine == .vlc { vlc?.rate = r }
    }

    private func tick() {
        var t = currentTime
        switch engine {
        case .apple:
            let s = player.currentTime().seconds
            if s.isFinite { t = s }
            if let d = player.currentItem?.duration.seconds, d.isFinite, d > 0, d != duration { duration = d }
        case .vlc:
            guard let v = vlc else { return }
            t = v.currentSeconds
            let d = v.durationSeconds
            if d > 0, d != duration { duration = d }
            let playing = v.isPlaying
            if playing != isPlaying { isPlaying = playing; if playing { isBuffering = false } }
            if vlcTicks < 60 {
                vlcTicks += 1
                if vlcTicks % 5 == 0, t > 0.3 { refreshVLCTracks() }
            }
        }
        if !isScrubbing { currentTime = t }

        guard let id = selectedExternal, let sub = externals.first(where: { $0.id == id }) else {
            if !subtitleText.isEmpty { subtitleText = "" }
            return
        }
        let x = t - subtitleOffset
        let text = sub.cues.filter { $0.start <= x && x < $0.end }.map(\.text).joined(separator: "\n")
        if text != subtitleText { subtitleText = text }
    }

    var displayText: String { selectedExternal != nil ? subtitleText : embeddedText }

    // MARK: Âm thanh và phụ đề nhúng
    func selectAudio(_ c: TrackChoice) {
        selectedAudioID = c.id
        if let o = c.apple, let g = audible { player.currentItem?.select(o, in: g) }
        if let i = c.vlcIndex { vlc?.currentAudio = i }
    }

    func selectEmbedded(_ c: TrackChoice?) {
        selectedExternal = nil; subtitleText = ""; embeddedText = ""
        selectedEmbeddedID = c?.id
        switch engine {
        case .apple: if let g = legible { player.currentItem?.select(c?.apple, in: g) }
        case .vlc: vlc?.currentSubtitle = c?.vlcIndex ?? -1
        }
    }

    // MARK: Phụ đề ngoài
    func selectExternal(_ id: UUID?) {
        selectedExternal = id
        embeddedText = ""
        if id != nil {
            selectedEmbeddedID = nil
            switch engine {
            case .apple: if let g = legible { player.currentItem?.select(nil, in: g) }
            case .vlc: vlc?.currentSubtitle = -1
            }
        } else { subtitleText = "" }
    }

    func addExternalData(label: String, data: Data, select: Bool = true) {
        let cues = SubtitleParser.parse(SubtitleParser.decode(data))
        guard !cues.isEmpty else { message = "Không đọc được phụ đề \"\(label)\"."; return }
        let sub = ExternalSub(label: label, cues: cues)
        externals.append(sub)
        if select { selectExternal(sub.id) }
    }

    func addExternal(url: URL, label: String, headers: [String: String]? = nil, select: Bool = true) async {
        var req = URLRequest(url: url)
        headers?.forEach { req.setValue($1, forHTTPHeaderField: $0) }
        do {
            let (data, _) = try await URLSession.shared.data(for: req)
            await MainActor.run { addExternalData(label: label, data: data, select: select) }
        } catch {
            await MainActor.run { message = "Không tải được phụ đề: \(error.localizedDescription)" }
        }
    }

    func loadPluginSubs() async {
        for s in info.subtitles ?? [] {
            guard let url = URL(string: s.url) else { continue }
            await addExternal(url: url, label: s.label, headers: info.headers,
                              select: (s.language ?? "").hasPrefix("vi") && selectedExternal == nil)
        }
    }

    // MARK: Thông báo và chẩn đoán
    func showToast(_ text: String) {
        toast = text
        DispatchQueue.main.asyncAfter(deadline: .now() + 4) { [weak self] in
            if self?.toast == text { self?.toast = nil }
        }
    }

    static func explain(_ error: Error?, url: URL) -> String {
        var s = "Không phát được video."
        if let ns = error as NSError? {
            s += "\n\(ns.localizedDescription) (\(ns.domain) \(ns.code))"
            if let u = ns.userInfo[NSUnderlyingErrorKey] as? NSError { s += "\nNguyên nhân gốc: \(u.domain) \(u.code)" }
        }
        let ext = url.pathExtension.lowercased()
        if ["mkv", "avi", "wmv", "flv", "webm", "rmvb", "ts"].contains(ext) {
            s += "\n\nĐịnh dạng .\(ext) không được trình phát của iOS hỗ trợ. Đây không phải lỗi link hay hết hạn."
        } else if url.host?.hasSuffix("googleusercontent.com") == true {
            s += "\n\nLink Google thường hết hạn sau một thời gian hoặc cần đăng nhập."
        }
        return s
    }

    /// Gọi sau 15 giây: nếu vẫn chưa chạy thì thử engine khác hoặc báo nguyên nhân.
    func reportIfStalled() {
        guard message == nil, currentTime < 0.5, !isPlaying else { return }
        switch engine {
        case .apple:
            guard player.timeControlStatus == .waitingToPlayAtSpecifiedRate || player.currentItem?.status == .unknown else { return }
            if VLCBackend.isAvailable, !triedVLC {
                triedVLC = true
                showToast("Trình phát Apple chưa chạy được, thử bằng VLC…")
                activate(.vlc, resumeAt: currentTime)
                return
            }
            let st: String
            switch player.currentItem?.status {
            case .some(.readyToPlay): st = "sẵn sàng nhưng không chạy"
            case .some(.failed): st = "lỗi"
            default: st = "vẫn đang tải"
            }
            var s = "Sau 15 giây vẫn chưa phát được. Trạng thái: \(st)."
            if let ev = player.currentItem?.errorLog()?.events.last {
                s += "\nMáy chủ trả mã \(ev.errorStatusCode): \(ev.errorComment ?? ev.errorDomain)"
            }
            s += "\n\nThường gặp: máy chủ chặn trình phát iOS (cần Referer hoặc User-Agent), playlist hoặc segment hết hạn, hoặc luồng dùng codec iOS không hỗ trợ."
            message = s
        case .vlc:
            if isBuffering {
                let info = vlc?.debugInfo ?? "VLC chưa được khởi tạo (khung hiển thị chưa sẵn sàng)"
                let log = vlcStateLog.suffix(8).joined(separator: " → ")
                let vlog = vlc?.logSummary ?? ""
                message = "VLC sau 15 giây vẫn chưa phát.\n\(info)\nTrạng thái: \(log.isEmpty ? "chưa nhận được" : log)\n\nNhật ký VLC:\n\(vlog.isEmpty ? "(trống)" : vlog)"
            }
        }
    }
}

// MARK: - Mặt phẳng video và nút AirPlay

final class PlayerLayerView: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
}

struct VideoSurface: UIViewRepresentable {
    let player: AVPlayer
    func makeUIView(context: Context) -> PlayerLayerView {
        let v = PlayerLayerView()
        v.backgroundColor = .black
        v.playerLayer.player = player
        v.playerLayer.videoGravity = .resizeAspect
        return v
    }
    func updateUIView(_ uiView: PlayerLayerView, context: Context) {}
}

struct VLCSurface: UIViewRepresentable {
    let view: UIView
    func makeUIView(context: Context) -> UIView { view }
    func updateUIView(_ uiView: UIView, context: Context) {}
}

struct AirPlayButton: UIViewRepresentable {
    func makeUIView(context: Context) -> AVRoutePickerView {
        let v = AVRoutePickerView()
        v.tintColor = .white
        v.activeTintColor = .systemBlue
        v.prioritizesVideoDevices = true
        return v
    }
    func updateUIView(_ uiView: AVRoutePickerView, context: Context) {}
}

// MARK: - Màn hình trình phát

struct PlayerView: View {
    let source: ContentSource
    let item: MediaItem
    let chapter: Chapter
    let startAt: Double
    @EnvironmentObject var progress: ProgressStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var model: PlayerModel

    @State private var controlsVisible = true
    @State private var showPanel = false
    @State private var showEngines = false
    @State private var scrubTime: Double?
    @State private var hideWork: DispatchWorkItem?
    @State private var showURLPrompt = false
    @State private var urlText = ""

    init(source: ContentSource, item: MediaItem, chapter: Chapter, info: StreamInfo, startAt: Double) {
        self.source = source; self.item = item; self.chapter = chapter; self.startAt = startAt
        _model = StateObject(wrappedValue: PlayerModel(info: info))
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
                .alert("Phụ đề từ URL", isPresented: $showURLPrompt) {
                    TextField("https://…/phude.srt", text: $urlText)
                    Button("Tải") {
                        let text = urlText.trimmingCharacters(in: .whitespaces); urlText = ""
                        guard let url = URL(string: text) else { model.message = "URL không hợp lệ."; return }
                        Task { await model.addExternal(url: url, label: url.lastPathComponent) }
                    }
                    Button("Huỷ", role: .cancel) { urlText = "" }
                }

            Group {
                if model.engine == .apple { VideoSurface(player: model.player) }
                else { VLCSurface(view: model.vlcView) }
            }
            .ignoresSafeArea()

            // Lớp bắt chạm: chạm để hiện/ẩn điều khiển, vuốt xuống để đóng
            Color.clear.contentShape(Rectangle()).ignoresSafeArea()
                .onTapGesture { tapBackground() }
                .gesture(DragGesture(minimumDistance: 30).onEnded { v in
                    if v.translation.height > 140 && abs(v.translation.width) < 100 { dismiss() }
                })

            subtitleView

            if model.isBuffering { ProgressView().tint(.white).scaleEffect(1.5) }

            if controlsVisible { controls.transition(.opacity) }
            if showPanel { panel.transition(.opacity) }
            if showEngines { enginePanel.transition(.opacity) }

            if let t = model.toast {
                VStack {
                    Text(t).font(.footnote).foregroundColor(.white)
                        .padding(.horizontal, 14).padding(.vertical, 8)
                        .background(.ultraThinMaterial).clipShape(Capsule()).padding(.top, 14)
                    Spacer()
                }
                .allowsHitTesting(false).transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.2), value: model.toast)
        .statusBarHidden(true)
        .task {
            model.start(at: startAt)
            await model.loadPluginSubs()
        }
        .task {
            do { try await Task.sleep(nanoseconds: 15_000_000_000) } catch { return }
            model.reportIfStalled()
        }
        .onChange(of: model.isPlaying) { _ in poke() }
        .onDisappear {
            hideWork?.cancel()
            let t = model.currentSeconds
            model.stop()
            progress.update(source: source, item: item) {
                $0.lastChapterID = chapter.id; $0.lastChapterTitle = chapter.title; $0.seconds = t.isFinite ? t : 0
            }
        }
        .alert("Thông báo", isPresented: Binding(get: { model.message != nil }, set: { if !$0 { model.message = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(model.message ?? "") }
    }

    // MARK: Ẩn/hiện điều khiển
    private var anyPopup: Bool { showPanel || showEngines }

    private func poke() {
        withAnimation(.easeInOut(duration: 0.2)) { controlsVisible = true }
        hideWork?.cancel()
        guard model.isPlaying, !anyPopup, scrubTime == nil else { return }
        let w = DispatchWorkItem { withAnimation(.easeInOut(duration: 0.25)) { controlsVisible = false } }
        hideWork = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 4, execute: w)
    }

    private func tapBackground() {
        if anyPopup { withAnimation { showPanel = false; showEngines = false }; poke(); return }
        if controlsVisible {
            hideWork?.cancel()
            withAnimation(.easeInOut(duration: 0.2)) { controlsVisible = false }
        } else { poke() }
    }

    // MARK: Phụ đề
    private var subtitleView: some View {
        VStack {
            Spacer()
            if !model.displayText.isEmpty {
                Text(model.displayText)
                    .font(.system(size: model.fontSize, weight: .semibold))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .shadow(color: .black, radius: 2).shadow(color: .black, radius: 2)
                    .padding(.horizontal, 24)
                    .padding(.bottom, model.subtitleBottom + (controlsVisible ? 90 : 0))
            }
        }
        .animation(.easeInOut(duration: 0.2), value: controlsVisible)
        .allowsHitTesting(false)
    }

    // MARK: Điều khiển
    private func clock(_ s: Double) -> String {
        guard s.isFinite, s >= 0 else { return "0:00" }
        let t = Int(s), h = t / 3600, m = (t % 3600) / 60, sec = t % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, sec) : String(format: "%d:%02d", m, sec)
    }

    private var controls: some View {
        ZStack {
            LinearGradient(colors: [.black.opacity(0.45), .clear, .black.opacity(0.65)], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea().allowsHitTesting(false)

            HStack(spacing: 56) {
                Button { model.skip(-10); poke() } label: { Image(systemName: "gobackward.10").font(.system(size: 34)) }
                Button { model.togglePlay() } label: {
                    Image(systemName: model.isPlaying ? "pause.fill" : "play.fill").font(.system(size: 50)).frame(width: 60)
                }
                Button { model.skip(10); poke() } label: { Image(systemName: "goforward.10").font(.system(size: 34)) }
            }
            .foregroundColor(.white)

            VStack {
                Spacer()
                VStack(spacing: 8) {
                    HStack(spacing: 10) {
                        Text(clock(scrubTime ?? model.currentTime)).font(.caption.monospacedDigit()).foregroundColor(.white)
                        Slider(
                            value: Binding(get: { scrubTime ?? model.currentTime }, set: { scrubTime = $0 }),
                            in: 0...max(model.duration, 1),
                            onEditingChanged: { editing in
                                if editing { model.isScrubbing = true; hideWork?.cancel() }
                                else {
                                    model.seek(to: scrubTime ?? model.currentTime)
                                    scrubTime = nil; model.isScrubbing = false; poke()
                                }
                            }
                        ).tint(.white)
                        Text("-" + clock(max(model.duration - (scrubTime ?? model.currentTime), 0)))
                            .font(.caption.monospacedDigit()).foregroundColor(.white)
                    }
                    HStack(spacing: 18) {
                        Spacer()
                        AirPlayButton().frame(width: 32, height: 32)
                        Button {
                            withAnimation { showEngines.toggle(); showPanel = false }
                            if showEngines { hideWork?.cancel() } else { poke() }
                        } label: {
                            Image(systemName: "rectangle.2.swap").font(.system(size: 22)).foregroundColor(.white)
                                .frame(width: 32, height: 32)
                        }
                        Button {
                            withAnimation { showPanel.toggle(); showEngines = false }
                            if showPanel { hideWork?.cancel() } else { poke() }
                        } label: {
                            Image(systemName: "captions.bubble").font(.system(size: 22)).foregroundColor(.white)
                                .frame(width: 32, height: 32)
                        }
                    }
                }
                .padding(.horizontal, 20).padding(.bottom, 10)
            }
        }
    }

    // MARK: Bảng chọn trình phát
    private var enginePanel: some View {
        ZStack(alignment: .bottomTrailing) {
            Color.black.opacity(0.001).ignoresSafeArea().onTapGesture { tapBackground() }
            VStack(alignment: .leading, spacing: 4) {
                header("Trình phát")
                ForEach(EngineKind.allCases, id: \.self) { e in
                    Button {
                        model.switchEngine(e)
                        withAnimation { showEngines = false }
                        poke()
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(e.title).font(.subheadline.bold())
                                Text(e.subtitle).font(.caption).foregroundColor(.white.opacity(0.6))
                            }
                            Spacer()
                            if model.engine == e { Image(systemName: "checkmark") }
                        }
                        .padding(.vertical, 6).contentShape(Rectangle())
                    }
                    .foregroundColor(.white)
                }
                if !VLCBackend.isAvailable {
                    Text("Bản build này chưa có VLC.").font(.footnote).foregroundColor(.orange)
                }
            }
            .padding(14).frame(width: 290)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .padding(.trailing, 16).padding(.bottom, 96)
        }
    }

    // MARK: Bảng tuỳ chọn phụ đề, âm thanh, tốc độ
    private var noSubtitle: Bool { model.selectedExternal == nil && model.selectedEmbeddedID == nil }

    private func header(_ t: String) -> some View {
        Text(t.uppercased()).font(.caption.bold()).foregroundColor(.white.opacity(0.6)).padding(.top, 6)
    }
    private func row(_ title: String, on: Bool = false, tint: Color = .white, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack { Text(title).lineLimit(1); Spacer(); if on { Image(systemName: "checkmark") } }
                .padding(.vertical, 5).contentShape(Rectangle())
        }.foregroundColor(tint)
    }
    private func chip(_ title: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title).font(.footnote.bold()).lineLimit(1)
                .padding(.horizontal, 10).padding(.vertical, 7)
                .background(Color.white.opacity(0.18)).clipShape(Capsule())
        }.foregroundColor(.white)
    }

    private var panel: some View {
        ZStack(alignment: .bottomTrailing) {
            Color.black.opacity(0.001).ignoresSafeArea().onTapGesture { tapBackground() }
            ScrollView {
                VStack(alignment: .leading, spacing: 4) {
                    header("Phụ đề")
                    row("Tắt", on: noSubtitle) { model.selectEmbedded(nil) }
                    ForEach(model.embeddedChoices) { c in
                        row(c.name, on: model.selectedEmbeddedID == c.id) { model.selectEmbedded(c) }
                    }
                    ForEach(model.externals) { s in
                        row(s.label, on: model.selectedExternal == s.id) { model.selectExternal(s.id) }
                    }
                    row("Thêm từ file…") {
                        showPanel = false
                        DocPicker.present { url in
                            if let d = try? Data(contentsOf: url) {
                                model.addExternalData(label: url.deletingPathExtension().lastPathComponent, data: d)
                            } else { model.message = "Không đọc được file." }
                        }
                    }
                    row("Thêm từ URL…") { showPanel = false; showURLPrompt = true }

                    header("Vị trí và kiểu chữ")
                    HStack {
                        chip("Lên ↑") { model.subtitleBottom = min(model.subtitleBottom + 20, 400) }
                        chip("Xuống ↓") { model.subtitleBottom = max(model.subtitleBottom - 20, 0) }
                        chip("A+") { model.fontSize = min(model.fontSize + 2, 40) }
                        chip("A−") { model.fontSize = max(model.fontSize - 2, 12) }
                    }
                    HStack {
                        chip("Sớm 0,5s") { model.subtitleOffset -= 0.5 }
                        chip("Muộn 0,5s") { model.subtitleOffset += 0.5 }
                        chip("Đặt lại (\(String(format: "%+.1f", model.subtitleOffset)))") { model.subtitleOffset = 0 }
                    }
                    if model.engine == .vlc {
                        Text("Với VLC, phụ đề nhúng trong video do VLC vẽ nên các nút này chỉ áp dụng cho phụ đề ngoài.")
                            .font(.caption).foregroundColor(.white.opacity(0.6))
                    }

                    header("Âm thanh")
                    if model.audioChoices.isEmpty {
                        Text("Chỉ có một luồng âm thanh").font(.footnote).foregroundColor(.white.opacity(0.6))
                    }
                    ForEach(model.audioChoices) { c in
                        row(c.name, on: model.selectedAudioID == c.id) { model.selectAudio(c) }
                    }

                    header("Tốc độ")
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 58))], alignment: .leading) {
                        ForEach([Float(0.5), 0.75, 1, 1.25, 1.5, 2], id: \.self) { r in
                            chip("\(String(format: "%g", r))×" + (model.rate == r ? " ✓" : "")) { model.setRate(r) }
                        }
                    }

                    Divider().background(Color.white.opacity(0.3)).padding(.vertical, 6)
                    row("Đóng trình phát", tint: .red) { dismiss() }
                }
                .padding(14)
            }
            .frame(width: 310)
            .frame(maxHeight: 340)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .padding(.trailing, 16).padding(.bottom, 96)
        }
    }
}
