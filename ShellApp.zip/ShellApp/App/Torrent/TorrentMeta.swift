import Foundation
import CryptoKit

struct TorrentFileEntry {
    let path: String
    let length: Int64
    let offset: Int64
}

struct TorrentMeta {
    let infoHash: Data
    let name: String
    let pieceLength: Int
    let pieces: Data
    let files: [TorrentFileEntry]
    let totalLength: Int64
    let trackers: [URL]

    var pieceCount: Int {
        guard pieces.count >= 20 else { return 0 }
        return pieces.count / 20
    }

    func pieceHash(at index: Int) -> Data? {
        let s = index * 20
        let e = s + 20
        guard s >= 0, e <= pieces.count else { return nil }
        return pieces.subdata(in: s..<e)
    }

    var primaryVideo: TorrentFileEntry? {
        let media = ["mp4", "mkv", "avi", "ts", "m2ts", "m4v", "webm", "mov", "wmv", "flv"]
        let vids = files.filter {
            media.contains(($0.path as NSString).pathExtension.lowercased()) && $0.length > 0
        }
        return vids.max(by: { $0.length < $1.length })
            ?? files.filter { $0.length > 0 }.max(by: { $0.length < $1.length })
    }

    static func fromTorrentFile(_ data: Data, extraTrackers: [URL] = []) throws -> TorrentMeta {
        let root = try Bencode.parse(data)
        guard let dict = root.dict, let info = dict["info"]?.dict else {
            throw NSError(domain: "Torrent", code: 1, userInfo: [NSLocalizedDescriptionKey: "Torrent không hợp lệ"])
        }
        let infoEncoded = Bencode.encode(.dict(info))
        let hash = Data(Insecure.SHA1.hash(data: infoEncoded))

        let name = info["name"]?.string ?? "unknown"
        let pieceLength = Int(info["piece length"]?.int ?? 0)
        guard pieceLength > 0 else {
            throw NSError(domain: "Torrent", code: 2, userInfo: [NSLocalizedDescriptionKey: "piece length không hợp lệ"])
        }
        guard let pieces = info["pieces"]?.data, pieces.count >= 20, pieces.count % 20 == 0 else {
            throw NSError(domain: "Torrent", code: 3, userInfo: [NSLocalizedDescriptionKey: "Thiếu pieces"])
        }

        var files: [TorrentFileEntry] = []
        var total: Int64 = 0
        if let length = info["length"]?.int, length > 0 {
            files.append(TorrentFileEntry(path: name, length: length, offset: 0))
            total = length
        } else if let list = info["files"]?.list {
            for f in list {
                guard let fd = f.dict, let len = fd["length"]?.int, len > 0 else { continue }
                let pathParts = fd["path"]?.list?.compactMap(\.string) ?? ["file"]
                let path = pathParts.joined(separator: "/")
                files.append(TorrentFileEntry(path: path, length: len, offset: total))
                total += len
            }
        }
        guard !files.isEmpty, total > 0 else {
            throw NSError(domain: "Torrent", code: 4, userInfo: [NSLocalizedDescriptionKey: "Torrent không có file"])
        }

        var trackers: [URL] = extraTrackers
        if let ann = dict["announce"]?.string, let u = URL(string: ann) { trackers.append(u) }
        if let list = dict["announce-list"]?.list {
            for tier in list {
                for v in tier.list ?? [] {
                    if let s = v.string, let u = URL(string: s) { trackers.append(u) }
                }
            }
        }
        var seen = Set<String>()
        trackers = trackers.filter { seen.insert($0.absoluteString).inserted }

        return TorrentMeta(
            infoHash: hash, name: name, pieceLength: pieceLength, pieces: pieces,
            files: files, totalLength: total, trackers: trackers
        )
    }
}
