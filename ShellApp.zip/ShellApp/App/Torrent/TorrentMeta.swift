import Foundation
import CryptoKit

struct TorrentFileEntry {
    let path: String
    let length: Int64
    let offset: Int64   // offset trong toàn bộ payload
}

struct TorrentMeta {
    let infoHash: Data
    let name: String
    let pieceLength: Int
    let pieces: Data          // concat SHA-1 mỗi piece (20 byte)
    let files: [TorrentFileEntry]
    let totalLength: Int64
    let trackers: [URL]

    var pieceCount: Int { pieces.count / 20 }

    func pieceHash(at index: Int) -> Data {
        let s = index * 20
        return pieces.subdata(in: s..<(s + 20))
    }

    /// File video ưu tiên (lớn nhất có đuôi media).
    var primaryVideo: TorrentFileEntry? {
        let media = ["mp4", "mkv", "avi", "ts", "m2ts", "m4v", "webm", "mov", "wmv", "flv"]
        let vids = files.filter { media.contains(($0.path as NSString).pathExtension.lowercased()) }
        return vids.max(by: { $0.length < $1.length }) ?? files.max(by: { $0.length < $1.length })
    }

    static func fromTorrentFile(_ data: Data, extraTrackers: [URL] = []) throws -> TorrentMeta {
        let root = try Bencode.parse(data)
        guard let dict = root.dict, let info = dict["info"]?.dict else {
            throw NSError(domain: "Torrent", code: 1, userInfo: [NSLocalizedDescriptionKey: "Torrent không hợp lệ"])
        }
        // infohash = SHA1(bencode(info dict))
        let infoEncoded = Bencode.encode(.dict(info))
        let hash = Data(Insecure.SHA1.hash(data: infoEncoded))

        let name = info["name"]?.string ?? "unknown"
        let pieceLength = Int(info["piece length"]?.int ?? 262144)
        guard let pieces = info["pieces"]?.data, pieces.count % 20 == 0 else {
            throw NSError(domain: "Torrent", code: 2, userInfo: [NSLocalizedDescriptionKey: "Thiếu pieces"])
        }

        var files: [TorrentFileEntry] = []
        var total: Int64 = 0
        if let length = info["length"]?.int {
            files.append(TorrentFileEntry(path: name, length: length, offset: 0))
            total = length
        } else if let list = info["files"]?.list {
            for f in list {
                guard let fd = f.dict, let len = fd["length"]?.int else { continue }
                let pathParts = fd["path"]?.list?.compactMap(\.string) ?? ["file"]
                let path = pathParts.joined(separator: "/")
                files.append(TorrentFileEntry(path: path, length: len, offset: total))
                total += len
            }
        }

        var trackers: [URL] = extraTrackers
        if let ann = dict["announce"]?.string, let u = URL(string: ann) { trackers.append(u) }
        if let list = dict["announce-list"]?.list {
            for tier in list {
                for v in tier.list ?? [] {
                    if let s = v.string, let u = URL(string: s) { trackers.append(u) }
                }
            }
        }
        // unique
        var seen = Set<String>()
        trackers = trackers.filter { seen.insert($0.absoluteString).inserted }

        return TorrentMeta(infoHash: hash, name: name, pieceLength: pieceLength, pieces: pieces,
                           files: files, totalLength: total, trackers: trackers)
    }
}
