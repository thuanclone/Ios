import Foundation
import CryptoKit

struct MagnetLink {
    let infoHash: Data          // 20 bytes SHA-1
    let infoHashHex: String
    let displayName: String?
    let trackers: [URL]
    let raw: String

    static func parse(_ string: String) -> MagnetLink? {
        guard string.lowercased().hasPrefix("magnet:") else { return nil }
        guard let comps = URLComponents(string: string) else { return nil }
        let items = comps.queryItems ?? []
        var xt: String?
        var dn: String?
        var trs: [URL] = []
        for it in items {
            switch it.name.lowercased() {
            case "xt": xt = it.value
            case "dn": dn = it.value.map { $0.removingPercentEncoding ?? $0 }
            case "tr":
                if let v = it.value?.removingPercentEncoding, let u = URL(string: v) {
                    trs.append(u)
                }
            default: break
            }
        }
        guard let xt, xt.lowercased().hasPrefix("urn:btih:") else { return nil }
        let hashPart = String(xt.dropFirst("urn:btih:".count))
        guard let hash = decodeInfoHash(hashPart) else { return nil }
        let hex = hash.map { String(format: "%02x", $0) }.joined()
        // Tracker mặc định nếu magnet không có
        if trs.isEmpty {
            ["http://nyaa.tracker.wf:7777/announce",
             "udp://open.stealth.si:80/announce",
             "udp://tracker.opentrackr.org:1337/announce",
             "udp://exodus.desync.com:6969/announce"].compactMap(URL.init).forEach { trs.append($0) }
        }
        return MagnetLink(infoHash: hash, infoHashHex: hex, displayName: dn, trackers: trs, raw: string)
    }

    private static func decodeInfoHash(_ s: String) -> Data? {
        if s.count == 40, let d = Data(hexString: s) { return d }
        // base32 (32 chars)
        if s.count == 32 {
            return base32Decode(s.uppercased())
        }
        return nil
    }
}

extension Data {
    init?(hexString: String) {
        let s = hexString.lowercased()
        guard s.count % 2 == 0 else { return nil }
        var data = Data(capacity: s.count / 2)
        var idx = s.startIndex
        while idx < s.endIndex {
            let next = s.index(idx, offsetBy: 2)
            guard let b = UInt8(s[idx..<next], radix: 16) else { return nil }
            data.append(b)
            idx = next
        }
        self = data
    }
}

private func base32Decode(_ s: String) -> Data? {
    let alphabet = Array("ABCDEFGHIJKLMNOPQRSTUVWXYZ234567")
    var bits = 0
    var value = 0
    var out = Data()
    for ch in s {
        guard let idx = alphabet.firstIndex(of: ch) else { continue }
        value = (value << 5) | idx
        bits += 5
        if bits >= 8 {
            bits -= 8
            out.append(UInt8((value >> bits) & 0xff))
        }
    }
    return out.count == 20 ? out : nil
}
