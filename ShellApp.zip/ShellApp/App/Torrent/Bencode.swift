import Foundation

/// Parser / encoder bencode tối giản cho metadata torrent.
enum Bencode {
    enum Value: Equatable {
        case int(Int64)
        case string(Data)
        case list([Value])
        case dict([String: Value])

        var int: Int64? { if case .int(let v) = self { return v }; return nil }
        var data: Data? { if case .string(let v) = self { return v }; return nil }
        var string: String? { data.flatMap { String(data: $0, encoding: .utf8) } }
        var list: [Value]? { if case .list(let v) = self { return v }; return nil }
        var dict: [String: Value]? { if case .dict(let v) = self { return v }; return nil }
    }

    static func parse(_ data: Data) throws -> Value {
        var i = data.startIndex
        return try parseValue(data, &i)
    }

    private static func parseValue(_ d: Data, _ i: inout Data.Index) throws -> Value {
        guard i < d.endIndex else { throw Err.truncated }
        switch d[i] {
        case UInt8(ascii: "i"):
            i = d.index(after: i)
            guard let e = d[i...].firstIndex(of: UInt8(ascii: "e")) else { throw Err.bad }
            let n = String(data: d[i..<e], encoding: .ascii) ?? ""
            guard let v = Int64(n) else { throw Err.bad }
            i = d.index(after: e)
            return .int(v)
        case UInt8(ascii: "l"):
            i = d.index(after: i)
            var arr: [Value] = []
            while i < d.endIndex, d[i] != UInt8(ascii: "e") {
                arr.append(try parseValue(d, &i))
            }
            guard i < d.endIndex else { throw Err.truncated }
            i = d.index(after: i)
            return .list(arr)
        case UInt8(ascii: "d"):
            i = d.index(after: i)
            var dict: [String: Value] = [:]
            while i < d.endIndex, d[i] != UInt8(ascii: "e") {
                guard case .string(let keyData) = try parseValue(d, &i),
                      let key = String(data: keyData, encoding: .utf8) else { throw Err.bad }
                dict[key] = try parseValue(d, &i)
            }
            guard i < d.endIndex else { throw Err.truncated }
            i = d.index(after: i)
            return .dict(dict)
        default:
            // length:string
            guard let colon = d[i...].firstIndex(of: UInt8(ascii: ":")) else { throw Err.bad }
            let lenStr = String(data: d[i..<colon], encoding: .ascii) ?? ""
            guard let len = Int(lenStr), len >= 0 else { throw Err.bad }
            let start = d.index(after: colon)
            let end = d.index(start, offsetBy: len, limitedBy: d.endIndex) ?? d.endIndex
            guard d.distance(from: start, to: end) == len else { throw Err.truncated }
            i = end
            return .string(d[start..<end])
        }
    }

    /// Encode dict (chỉ dùng cho tracker request body nếu cần).
    static func encode(_ value: Value) -> Data {
        switch value {
        case .int(let n):
            return Data("i\(n)e".utf8)
        case .string(let d):
            var out = Data("\(d.count):".utf8)
            out.append(d)
            return out
        case .list(let arr):
            var out = Data("l".utf8)
            arr.forEach { out.append(encode($0)) }
            out.append(Data("e".utf8))
            return out
        case .dict(let dict):
            var out = Data("d".utf8)
            for key in dict.keys.sorted() {
                out.append(encode(.string(Data(key.utf8))))
                out.append(encode(dict[key]!))
            }
            out.append(Data("e".utf8))
            return out
        }
    }

    enum Err: Error { case truncated, bad }
}
