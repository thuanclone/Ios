import Foundation

/// Parser / encoder bencode tối giản cho metadata torrent.
enum Bencode {
    enum Value: Equatable {
        case int(Int64)
        case string(Data)
        case list([Value])
        case dict([String: Value])

        var int: Int64? { if case .int(let v) = self { return v }; return nil }
        var data: Data? { if case .string(let v) = self { return v }; return nil }
        var string: String? { data.flatMap { String(data: $0, encoding: .utf8) } }
        var list: [Value]? { if case .list(let v) = self { return v }; return nil }
        var dict: [String: Value]? { if case .dict(let v) = self { return v }; return nil }
    }

    enum Err: LocalizedError {
        case truncated
        case bad
        case notTorrent

        var errorDescription: String? {
            switch self {
            case .truncated: return "File .torrent bị cắt (tải không đủ)."
            case .bad: return "Nội dung không phải bencode hợp lệ (thường là trang HTML bị chặn)."
            case .notTorrent: return "Không phải file torrent (thiếu dict gốc)."
            }
        }
    }

    static func parse(_ data: Data) throws -> Value {
        guard !data.isEmpty else { throw Err.truncated }
        // HTML / JSON nhầm
        if let c = data.first, c == UInt8(ascii: "<") || c == UInt8(ascii: "{") {
            throw Err.notTorrent
        }
        var i = data.startIndex
        let v = try parseValue(data, &i)
        return v
    }

    private static func parseValue(_ d: Data, _ i: inout Data.Index) throws -> Value {
        guard i < d.endIndex else { throw Err.truncated }
        switch d[i] {
        case UInt8(ascii: "i"):
            i = d.index(after: i)
            guard let e = d[i...].firstIndex(of: UInt8(ascii: "e")) else { throw Err.bad }
            let n = String(data: d[i..<e], encoding: .ascii) ?? ""
            guard let v = Int64(n) else { throw Err.bad }
            i = d.index(after: e)
            return .int(v)
        case UInt8(ascii: "l"):
            i = d.index(after: i)
            var arr: [Value] = []
            while i < d.endIndex, d[i] != UInt8(ascii: "e") {
                arr.append(try parseValue(d, &i))
            }
            guard i < d.endIndex else { throw Err.truncated }
            i = d.index(after: i)
            return .list(arr)
        case UInt8(ascii: "d"):
            i = d.index(after: i)
            var dict: [String: Value] = [:]
            while i < d.endIndex, d[i] != UInt8(ascii: "e") {
                let keyVal = try parseValue(d, &i)
                guard case .string(let keyData) = keyVal else { throw Err.bad }
                // Key torrent luôn ASCII; fallback lossy
                let key = String(data: keyData, encoding: .utf8)
                    ?? String(decoding: keyData, as: UTF8.self)
                dict[key] = try parseValue(d, &i)
            }
            guard i < d.endIndex else { throw Err.truncated }
            i = d.index(after: i)
            return .dict(dict)
        default:
            // length:string  (kể cả binary như "pieces")
            guard d[i] >= UInt8(ascii: "0"), d[i] <= UInt8(ascii: "9") else { throw Err.bad }
            guard let colon = d[i...].firstIndex(of: UInt8(ascii: ":")) else { throw Err.bad }
            let lenStr = String(data: d[i..<colon], encoding: .ascii) ?? ""
            guard let len = Int(lenStr), len >= 0 else { throw Err.bad }
            let start = d.index(after: colon)
            guard d.distance(from: start, to: d.endIndex) >= len else { throw Err.truncated }
            let end = d.index(start, offsetBy: len)
            i = end
            return .string(d[start..<end])
        }
    }

    static func encode(_ value: Value) -> Data {
        switch value {
        case .int(let n):
            return Data("i\(n)e".utf8)
        case .string(let d):
            var out = Data("\(d.count):".utf8)
            out.append(d)
            return out
        case .list(let arr):
            var out = Data("l".utf8)
            arr.forEach { out.append(encode($0)) }
            out.append(Data("e".utf8))
            return out
        case .dict(let dict):
            var out = Data("d".utf8)
            for key in dict.keys.sorted() {
                out.append(encode(.string(Data(key.utf8))))
                out.append(encode(dict[key]!))
            }
            out.append(Data("e".utf8))
            return out
        }
    }
}
