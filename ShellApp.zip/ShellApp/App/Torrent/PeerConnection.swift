import Foundation
import Network
import CryptoKit

/// Kết nối peer BitTorrent tối giản: handshake → bitfield → request piece tuần tự.
final class PeerConnection {
    private let addr: PeerAddr
    private let infoHash: Data
    private let peerId: Data
    private var conn: NWConnection?
    private let queue = DispatchQueue(label: "bt.peer")
    private var buffer = Data()
    private(set) var bitfield: [Bool] = []
    private var choked = true
    private var handshakeDone = false
    var onPiece: ((Int, Data) -> Void)?
    var onReady: (() -> Void)?

    init(addr: PeerAddr, infoHash: Data, peerId: Data) {
        self.addr = addr
        self.infoHash = infoHash
        self.peerId = peerId
    }

    func connect() {
        let host = NWEndpoint.Host(addr.host)
        let port = NWEndpoint.Port(rawValue: addr.port)!
        let c = NWConnection(host: host, port: port, using: .tcp)
        conn = c
        c.stateUpdateHandler = { [weak self] state in
            if case .ready = state { self?.sendHandshake() }
            if case .failed = state { self?.conn?.cancel() }
        }
        c.start(queue: queue)
        receiveLoop()
    }

    func close() {
        conn?.cancel()
        conn = nil
    }

    func hasPiece(_ index: Int) -> Bool {
        index < bitfield.count && bitfield[index]
    }

    func request(piece index: Int, begin: Int, length: Int) {
        guard !choked, handshakeDone else { return }
        var msg = Data()
        msg.append(contentsOf: u32(13)) // len
        msg.append(6) // request
        msg.append(contentsOf: u32(UInt32(index)))
        msg.append(contentsOf: u32(UInt32(begin)))
        msg.append(contentsOf: u32(UInt32(length)))
        send(msg)
    }

    func sendInterested() {
        var msg = Data()
        msg.append(contentsOf: u32(1))
        msg.append(2) // interested
        send(msg)
    }

    private func sendHandshake() {
        var hs = Data()
        hs.append(19)
        hs.append(contentsOf: "BitTorrent protocol".utf8)
        hs.append(contentsOf: [UInt8](repeating: 0, count: 8))
        hs.append(infoHash)
        hs.append(peerId)
        send(hs)
    }

    private func send(_ data: Data) {
        conn?.send(content: data, completion: .contentProcessed { _ in })
    }

    private func receiveLoop() {
        conn?.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) { [weak self] data, _, isComplete, error in
            guard let self else { return }
            if let data { self.buffer.append(data); self.processBuffer() }
            if error != nil || isComplete { self.conn?.cancel(); return }
            self.receiveLoop()
        }
    }

    private func processBuffer() {
        // Handshake 68 bytes
        if !handshakeDone {
            if buffer.count < 68 { return }
            let hs = buffer.prefix(68)
            buffer.removeFirst(68)
            // kiểm tra infohash
            let remoteHash = hs.subdata(in: 28..<48)
            guard remoteHash == infoHash else { conn?.cancel(); return }
            handshakeDone = true
            sendInterested()
            // unchoke mình? gửi bitfield trống optional
        }
        while buffer.count >= 4 {
            let len = Int(u32be(buffer, 0))
            if len == 0 { buffer.removeFirst(4); continue } // keep-alive
            if buffer.count < 4 + len { break }
            let id = buffer[4]
            let payload = buffer.subdata(in: 5..<(4 + len))
            buffer.removeFirst(4 + len)
            handleMessage(id: id, payload: payload)
        }
    }

    private func handleMessage(id: UInt8, payload: Data) {
        switch id {
        case 0: choked = true
        case 1:
            choked = false
            onReady?()
        case 5: // bitfield
            bitfield = payload.flatMap { byte in
                (0..<8).map { bit in (byte & (0x80 >> bit)) != 0 }
            }
            onReady?()
        case 4: // have
            if payload.count >= 4 {
                let idx = Int(u32be(payload, 0))
                if idx >= bitfield.count {
                    bitfield.append(contentsOf: [Bool](repeating: false, count: idx - bitfield.count + 1))
                }
                if idx < bitfield.count { bitfield[idx] = true }
            }
        case 7: // piece
            guard payload.count >= 8 else { return }
            let index = Int(u32be(payload, 0))
            // let begin = Int(u32be(payload, 4))
            let block = payload.subdata(in: 8..<payload.count)
            onPiece?(index, block)
        default: break
        }
    }
}

private func u32(_ v: UInt32) -> [UInt8] {
    [(UInt8)((v >> 24) & 0xff), (UInt8)((v >> 16) & 0xff), (UInt8)((v >> 8) & 0xff), (UInt8)(v & 0xff)]
}
private func u32be(_ d: Data, _ o: Int) -> UInt32 {
    guard o + 4 <= d.count else { return 0 }
    return UInt32(d[o]) << 24 | UInt32(d[o+1]) << 16 | UInt32(d[o+2]) << 8 | UInt32(d[o+3])
}
