import Foundation
import Network

/// Kết nối peer BitTorrent tối giản — mọi callback bắt lỗi, không crash app.
final class PeerConnection {
    private let addr: PeerAddr
    private let infoHash: Data
    private let peerId: Data
    private var conn: NWConnection?
    private let queue = DispatchQueue(label: "bt.peer", qos: .utility)
    private var buffer = Data()
    private(set) var bitfield: [Bool] = []
    private var choked = true
    private var handshakeDone = false
    private var closed = false
    var onPiece: ((Int, Data) -> Void)?
    var onReady: (() -> Void)?

    init(addr: PeerAddr, infoHash: Data, peerId: Data) {
        self.addr = addr
        self.infoHash = infoHash
        self.peerId = peerId
    }

    func connect() {
        guard let port = NWEndpoint.Port(rawValue: addr.port) else { return }
        let host = NWEndpoint.Host(addr.host)
        let c = NWConnection(host: host, port: port, using: .tcp)
        conn = c
        c.stateUpdateHandler = { [weak self] state in
            guard let self, !self.closed else { return }
            switch state {
            case .ready:
                self.sendHandshake()
            case .failed, .cancelled:
                self.close()
            default:
                break
            }
        }
        c.start(queue: queue)
        receiveLoop()
    }

    func close() {
        closed = true
        conn?.cancel()
        conn = nil
        onPiece = nil
        onReady = nil
    }

    func hasPiece(_ index: Int) -> Bool {
        index >= 0 && index < bitfield.count && bitfield[index]
    }

    func request(piece index: Int, begin: Int, length: Int) {
        guard !closed, !choked, handshakeDone, length > 0, begin >= 0 else { return }
        var msg = Data()
        msg.append(contentsOf: u32(13))
        msg.append(6)
        msg.append(contentsOf: u32(UInt32(index)))
        msg.append(contentsOf: u32(UInt32(begin)))
        msg.append(contentsOf: u32(UInt32(length)))
        send(msg)
    }

    func sendInterested() {
        guard !closed else { return }
        var msg = Data()
        msg.append(contentsOf: u32(1))
        msg.append(2)
        send(msg)
    }

    private func sendHandshake() {
        guard infoHash.count == 20, peerId.count == 20 else { close(); return }
        var hs = Data()
        hs.append(19)
        hs.append(contentsOf: "BitTorrent protocol".utf8)
        hs.append(contentsOf: [UInt8](repeating: 0, count: 8))
        hs.append(infoHash)
        hs.append(peerId)
        send(hs)
    }

    private func send(_ data: Data) {
        guard !closed, let conn else { return }
        conn.send(content: data, completion: .contentProcessed { [weak self] error in
            if error != nil { self?.close() }
        })
    }

    private func receiveLoop() {
        guard !closed, let conn else { return }
        conn.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) { [weak self] data, _, isComplete, error in
            guard let self, !self.closed else { return }
            if let data, !data.isEmpty {
                self.buffer.append(data)
                // Giới hạn buffer tránh OOM
                if self.buffer.count > 2_000_000 {
                    self.close()
                    return
                }
                self.processBuffer()
            }
            if error != nil || isComplete {
                self.close()
                return
            }
            self.receiveLoop()
        }
    }

    private func processBuffer() {
        if !handshakeDone {
            if buffer.count < 68 { return }
            let hs = buffer.prefix(68)
            buffer.removeFirst(68)
            let remoteHash = hs.subdata(in: 28..<48)
            guard remoteHash == infoHash else { close(); return }
            handshakeDone = true
            sendInterested()
        }
        while buffer.count >= 4 {
            let len = Int(u32be(buffer, 0))
            if len < 0 || len > 1_000_000 { close(); return }
            if len == 0 {
                buffer.removeFirst(4)
                continue
            }
            if buffer.count < 4 + len { break }
            let id = buffer[4]
            let payload: Data = len > 1 ? buffer.subdata(in: 5..<(4 + len)) : Data()
            buffer.removeFirst(4 + len)
            handleMessage(id: id, payload: payload)
        }
    }

    private func handleMessage(id: UInt8, payload: Data) {
        switch id {
        case 0: choked = true
        case 1:
            choked = false
            onReady?()
        case 5:
            bitfield = payload.flatMap { byte -> [Bool] in
                (0..<8).map { bit in (byte & (0x80 >> bit)) != 0 }
            }
            onReady?()
        case 4:
            if payload.count >= 4 {
                let idx = Int(u32be(payload, 0))
                if idx >= 0 {
                    if idx >= bitfield.count {
                        bitfield.append(contentsOf: Array(repeating: false, count: idx - bitfield.count + 1))
                    }
                    if idx < bitfield.count { bitfield[idx] = true }
                }
            }
        case 7:
            guard payload.count >= 9 else { return }
            let index = Int(u32be(payload, 0))
            let block = payload.subdata(in: 8..<payload.count)
            guard index >= 0, !block.isEmpty else { return }
            onPiece?(index, block)
        default:
            break
        }
    }
}

private func u32(_ v: UInt32) -> [UInt8] {
    [UInt8((v >> 24) & 0xff), UInt8((v >> 16) & 0xff), UInt8((v >> 8) & 0xff), UInt8(v & 0xff)]
}
private func u32be(_ d: Data, _ o: Int) -> UInt32 {
    guard o + 4 <= d.count else { return 0 }
    return UInt32(d[o]) << 24 | UInt32(d[o + 1]) << 16 | UInt32(d[o + 2]) << 8 | UInt32(d[o + 3])
}
