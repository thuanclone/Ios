import Foundation
import CryptoKit
import Combine

/// Trạng thái tải torrent → phục vụ HTTP local cho player.
final class TorrentEngine: ObservableObject {
    enum Phase: String {
        case idle, resolving, announcing, downloading, serving, failed
    }

    @Published private(set) var phase: Phase = .idle
    @Published private(set) var progress: Double = 0
    @Published private(set) var message: String = ""
    @Published private(set) var playURL: URL?
    @Published private(set) var peers = 0
    @Published private(set) var downloadedBytes: Int64 = 0
    @Published private(set) var totalBytes: Int64 = 0
    /// Magnet để user mở app ngoài nếu engine fail
    @Published private(set) var magnetForShare: String?

    private var meta: TorrentMeta?
    private var peerId: Data = {
        var d = Data(" -SA0001-".utf8)
        d.append(contentsOf: (0..<12).map { _ in UInt8.random(in: 0...255) })
        return d
    }()
    private var peersConn: [PeerConnection] = []
    private var pieceStatus: [Bool] = []
    private var pieceBuffers: [Int: Data] = [:]
    private var workDir: URL
    private var outputFile: URL?
    private let server = LocalHTTPServer()
    private var fileHandle: FileHandle?
    private let lock = NSLock()
    private var wantedPieces: [Int] = []
    private var nextRequestIndex = 0

    init() {
        let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("TorrentCache", isDirectory: true)
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        workDir = base
    }

    deinit { stop() }

    func stop() {
        peersConn.forEach { $0.close() }
        peersConn.removeAll()
        server.stop()
        try? fileHandle?.close()
        fileHandle = nil
        phase = .idle
        playURL = nil
    }

    /// Magnet + URL .torrent (từ Nyaa).
    func start(magnet: String, torrentFileURL: URL?) async {
        stop()
        phase = .resolving
        message = "Đang chuẩn bị torrent…"
        magnetForShare = magnet

        do {
            let data = try await loadTorrentData(magnet: magnet, preferred: torrentFileURL)
            let trackers = MagnetLink.parse(magnet)?.trackers ?? []
            let meta = try TorrentMeta.fromTorrentFile(data, extraTrackers: trackers)
            await MainActor.run {
                self.meta = meta
                self.totalBytes = meta.totalLength
                self.message = meta.name
            }
            try await beginDownload(meta: meta)
        } catch {
            await MainActor.run {
                self.phase = .failed
                self.message = error.localizedDescription
            }
        }
    }

    // MARK: - Tải .torrent (nhiều nguồn, kiểm tra bencode)

    private func loadTorrentData(magnet: String, preferred: URL?) async throws -> Data {
        var candidates: [URL] = []
        if let preferred { candidates.append(preferred) }

        // Lấy id từ header URL hoặc magnet dn
        if let preferred {
            let id = preferred.lastPathComponent
                .replacingOccurrences(of: ".torrent", with: "")
                .filter { $0.isNumber }
            if !id.isEmpty {
                if let u = URL(string: "https://nyaa.si/download/\(id).torrent") { candidates.append(u) }
                if let u = URL(string: "https://nyaa.media/download/\(id).torrent") { candidates.append(u) }
            }
        }

        // Unique
        var seen = Set<String>()
        candidates = candidates.filter { seen.insert($0.absoluteString).inserted }

        var lastError: Error = NSError(
            domain: "Torrent", code: 40,
            userInfo: [NSLocalizedDescriptionKey: "Không tải được file .torrent"]
        )

        for url in candidates {
            await MainActor.run { self.message = "Tải metadata…\n\(url.host ?? "")" }
            do {
                let data = try await download(url)
                if isBencodedTorrent(data) {
                    return data
                }
                lastError = NSError(
                    domain: "Torrent", code: 41,
                    userInfo: [NSLocalizedDescriptionKey: "Máy chủ trả về HTML thay vì .torrent (có thể bị chặn). Thử Wi‑Fi hoặc VPN."]
                )
            } catch {
                lastError = error
            }
        }

        throw lastError
    }

    private func isBencodedTorrent(_ data: Data) -> Bool {
        guard let first = data.first else { return false }
        // torrent gốc luôn là dict: 'd'...
        return first == UInt8(ascii: "d")
    }

    private func download(_ url: URL) async throws -> Data {
        var req = URLRequest(url: url, timeoutInterval: 30)
        req.setValue(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
            forHTTPHeaderField: "User-Agent"
        )
        req.setValue("https://nyaa.media/", forHTTPHeaderField: "Referer")
        req.setValue("application/x-bittorrent,*/*", forHTTPHeaderField: "Accept")
        let (data, resp) = try await URLSession.shared.data(for: req)
        if let http = resp as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            throw NSError(
                domain: "Torrent", code: http.statusCode,
                userInfo: [NSLocalizedDescriptionKey: "HTTP \(http.statusCode) khi tải .torrent từ \(url.host ?? "")"]
            )
        }
        return data
    }

    // MARK: - Download pieces

    private func beginDownload(meta: TorrentMeta) async throws {
        await MainActor.run {
            self.phase = .announcing
            self.message = "Kết nối tracker…"
            self.pieceStatus = [Bool](repeating: false, count: meta.pieceCount)
        }

        guard let video = meta.primaryVideo else {
            throw NSError(domain: "Torrent", code: 20, userInfo: [NSLocalizedDescriptionKey: "Không có file trong torrent"])
        }
        let out = workDir.appendingPathComponent(video.path.replacingOccurrences(of: "/", with: "_"))
        FileManager.default.createFile(atPath: out.path, contents: nil)
        let fh = try FileHandle(forWritingTo: out)
        try fh.truncate(atOffset: UInt64(video.length))
        fileHandle = fh
        outputFile = out

        let startPiece = Int(video.offset / Int64(meta.pieceLength))
        let endPiece = Int((video.offset + video.length - 1) / Int64(meta.pieceLength))
        wantedPieces = Array(startPiece...min(endPiece, meta.pieceCount - 1))
        nextRequestIndex = 0

        var allPeers: [PeerAddr] = []
        await withTaskGroup(of: [PeerAddr].self) { group in
            for tr in meta.trackers.prefix(10) where tr.scheme == "http" || tr.scheme == "https" {
                group.addTask {
                    await TrackerClient.announceHTTP(
                        tracker: tr,
                        infoHash: meta.infoHash,
                        peerId: self.peerId,
                        left: meta.totalLength
                    )
                }
            }
            for await list in group { allPeers.append(contentsOf: list) }
        }
        var seen = Set<PeerAddr>()
        allPeers = allPeers.filter { seen.insert($0).inserted }

        await MainActor.run {
            self.peers = allPeers.count
            self.phase = .downloading
            self.message = "Peers: \(allPeers.count) · đang tải…"
        }

        guard !allPeers.isEmpty else {
            throw NSError(
                domain: "Torrent", code: 21,
                userInfo: [NSLocalizedDescriptionKey: "Không tìm thấy peer (tracker HTTP). Mạng có thể chặn tracker — thử VPN, hoặc mở magnet bằng app torrent khác."]
            )
        }

        for addr in allPeers.prefix(16) {
            let pc = PeerConnection(addr: addr, infoHash: meta.infoHash, peerId: peerId)
            pc.onPiece = { [weak self] index, block in
                self?.handleBlock(index: index, data: block, meta: meta, video: video)
            }
            pc.onReady = { [weak self] in
                self?.pumpRequests(to: pc, meta: meta)
            }
            peersConn.append(pc)
            pc.connect()
        }

        let threshold = min(video.length, Int64(meta.pieceLength) * 4)
        for _ in 0..<240 { // ~2 phút
            try await Task.sleep(nanoseconds: 500_000_000)
            if downloadedBytes >= threshold {
                try startServing(file: out, name: video.path)
                break
            }
            if phase == .failed { break }
            let done = wantedPieces.allSatisfy { pieceStatus[safe: $0] == true }
            if done {
                try startServing(file: out, name: video.path)
                break
            }
        }
        if playURL == nil, downloadedBytes > 0 {
            try startServing(file: out, name: video.path)
        }
        if playURL == nil {
            throw NSError(
                domain: "Torrent", code: 22,
                userInfo: [NSLocalizedDescriptionKey: "Tải quá chậm / không đủ dữ liệu. Peers: \(peersConn.count). Thử torrent khác (nhiều seed hơn) hoặc mở magnet ngoài app."]
            )
        }
    }

    private func handleBlock(index: Int, data: Data, meta: TorrentMeta, video: TorrentFileEntry) {
        lock.lock()
        defer { lock.unlock() }
        var buf = pieceBuffers[index] ?? Data()
        // Ghép block theo thứ tự đơn giản (peer thường gửi tuần tự)
        if buf.count < meta.pieceLength {
            buf.append(data)
            pieceBuffers[index] = buf
        }
        let expected: Int = {
            if index == meta.pieceCount - 1 {
                let rem = Int(meta.totalLength % Int64(meta.pieceLength))
                return rem == 0 ? meta.pieceLength : rem
            }
            return meta.pieceLength
        }()
        guard buf.count >= expected else { return }
        let piece = Data(buf.prefix(expected))
        let hash = Data(Insecure.SHA1.hash(data: piece))
        guard hash == meta.pieceHash(at: index) else {
            pieceBuffers[index] = nil
            return
        }
        let pieceGlobalOffset = Int64(index) * Int64(meta.pieceLength)
        let writeOffset = pieceGlobalOffset - video.offset
        if writeOffset >= 0, writeOffset < video.length {
            let maxLen = min(Int64(piece.count), video.length - writeOffset)
            if maxLen > 0 {
                let slice = piece.prefix(Int(maxLen))
                fileHandle?.seek(toFileOffset: UInt64(writeOffset))
                fileHandle?.write(Data(slice))
                downloadedBytes += Int64(slice.count)
            }
        }
        pieceStatus[index] = true
        pieceBuffers[index] = nil
        let done = wantedPieces.filter { pieceStatus[safe: $0] == true }.count
        let prog = Double(done) / Double(max(1, wantedPieces.count))
        DispatchQueue.main.async {
            self.progress = prog
            self.message = String(format: "Đã tải %.0f%% · %d peers", prog * 100, self.peersConn.count)
        }
        for pc in peersConn { pumpRequests(to: pc, meta: meta) }
    }

    private func pumpRequests(to peer: PeerConnection, meta: TorrentMeta) {
        lock.lock()
        defer { lock.unlock() }
        var sent = 0
        var i = nextRequestIndex
        while i < wantedPieces.count && sent < 3 {
            let idx = wantedPieces[i]
            i += 1
            if pieceStatus[safe: idx] == true { continue }
            guard peer.hasPiece(idx) || peer.bitfield.isEmpty else { continue }
            let len: Int = {
                if idx == meta.pieceCount - 1 {
                    let rem = Int(meta.totalLength % Int64(meta.pieceLength))
                    return rem == 0 ? meta.pieceLength : rem
                }
                return meta.pieceLength
            }()
            var begin = 0
            while begin < len {
                let block = min(16 * 1024, len - begin)
                peer.request(piece: idx, begin: begin, length: block)
                begin += block
            }
            sent += 1
        }
        nextRequestIndex = min(i, wantedPieces.count)
        if nextRequestIndex >= wantedPieces.count { nextRequestIndex = 0 }
    }

    private func startServing(file: URL, name: String) throws {
        let path = (name as NSString).lastPathComponent
        try server.start(serving: file, path: path.isEmpty ? "video" : path)
        guard let u = server.baseURL else {
            throw NSError(domain: "Torrent", code: 30, userInfo: [NSLocalizedDescriptionKey: "HTTP local lỗi"])
        }
        DispatchQueue.main.async {
            self.phase = .serving
            self.playURL = u
            self.message = "Đang phát qua HTTP local"
        }
    }
}

private extension Array {
    subscript(safe index: Int) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
