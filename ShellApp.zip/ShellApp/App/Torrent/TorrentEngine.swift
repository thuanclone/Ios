import Foundation
import CryptoKit
import Combine

/// Tải torrent → HTTP local. Mọi lỗi chuyển thành phase=.failed, không crash.
final class TorrentEngine: ObservableObject {
    enum Phase: String {
        case idle, resolving, announcing, downloading, serving, failed
    }

    @Published private(set) var phase: Phase = .idle
    @Published private(set) var progress: Double = 0
    @Published private(set) var message: String = ""
    @Published private(set) var playURL: URL?
    @Published private(set) var peers = 0
    @Published private(set) var downloadedBytes: Int64 = 0
    @Published private(set) var totalBytes: Int64 = 0
    @Published private(set) var magnetForShare: String?

    private var meta: TorrentMeta?
    private let peerId: Data = {
        var d = Data(" -SA0001-".utf8)
        while d.count < 20 { d.append(UInt8.random(in: 0...255)) }
        return d.prefix(20) as Data
    }()
    private var peersConn: [PeerConnection] = []
    private var pieceStatus: [Bool] = []
    private var pieceBuffers: [Int: Data] = [:]
    private let workDir: URL
    private var outputFile: URL?
    private let server = LocalHTTPServer()
    private var fileHandle: FileHandle?
    private let lock = NSLock()
    private let ioQueue = DispatchQueue(label: "torrent.io", qos: .utility)
    private var wantedPieces: [Int] = []
    private var nextRequestIndex = 0
    private var stopped = false

    init() {
        let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("TorrentCache", isDirectory: true)
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        workDir = base
    }

    deinit { stop() }

    func stop() {
        stopped = true
        peersConn.forEach { $0.close() }
        peersConn.removeAll()
        server.stop()
        ioQueue.sync {
            try? fileHandle?.close()
            fileHandle = nil
        }
        phase = .idle
        playURL = nil
    }

    func start(magnet: String, torrentFileURL: URL?) async {
        stop()
        stopped = false
        await MainActor.run {
            phase = .resolving
            message = "Đang chuẩn bị torrent…"
            progress = 0
            magnetForShare = magnet
            playURL = nil
        }

        do {
            let data = try await loadTorrentData(magnet: magnet, preferred: torrentFileURL)
            guard !stopped else { return }
            let trackers = MagnetLink.parse(magnet)?.trackers ?? []
            let meta = try TorrentMeta.fromTorrentFile(data, extraTrackers: trackers)
            await MainActor.run {
                self.meta = meta
                self.totalBytes = meta.totalLength
                self.message = meta.name
            }
            try await beginDownload(meta: meta)
        } catch {
            guard !stopped else { return }
            await MainActor.run {
                self.phase = .failed
                self.message = error.localizedDescription
            }
        }
    }

    private func loadTorrentData(magnet: String, preferred: URL?) async throws -> Data {
        var candidates: [URL] = []
        if let preferred { candidates.append(preferred) }
        if let preferred {
            let id = preferred.lastPathComponent
                .replacingOccurrences(of: ".torrent", with: "")
                .filter { $0.isNumber }
            if !id.isEmpty {
                if let u = URL(string: "https://nyaa.si/download/\(id).torrent") { candidates.append(u) }
                if let u = URL(string: "https://nyaa.media/download/\(id).torrent") { candidates.append(u) }
            }
        }
        var seen = Set<String>()
        candidates = candidates.filter { seen.insert($0.absoluteString).inserted }

        var lastError: Error = NSError(
            domain: "Torrent", code: 40,
            userInfo: [NSLocalizedDescriptionKey: "Không tải được file .torrent"]
        )
        for url in candidates {
            await MainActor.run { self.message = "Tải metadata…\n\(url.host ?? "")" }
            do {
                let data = try await download(url)
                if let first = data.first, first == UInt8(ascii: "d") {
                    return data
                }
                lastError = NSError(
                    domain: "Torrent", code: 41,
                    userInfo: [NSLocalizedDescriptionKey: "Máy chủ trả HTML thay vì .torrent (có thể bị chặn). Thử Wi‑Fi/VPN."]
                )
            } catch {
                lastError = error
            }
        }
        throw lastError
    }

    private func download(_ url: URL) async throws -> Data {
        var req = URLRequest(url: url, timeoutInterval: 30)
        req.setValue(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
            forHTTPHeaderField: "User-Agent"
        )
        req.setValue("https://nyaa.media/", forHTTPHeaderField: "Referer")
        req.setValue("application/x-bittorrent,*/*", forHTTPHeaderField: "Accept")
        let (data, resp) = try await URLSession.shared.data(for: req)
        if let http = resp as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            throw NSError(
                domain: "Torrent", code: http.statusCode,
                userInfo: [NSLocalizedDescriptionKey: "HTTP \(http.statusCode) từ \(url.host ?? "")"]
            )
        }
        return data
    }

    private func beginDownload(meta: TorrentMeta) async throws {
        guard meta.pieceCount > 0, meta.pieceLength > 0 else {
            throw NSError(domain: "Torrent", code: 19, userInfo: [NSLocalizedDescriptionKey: "Metadata torrent không hợp lệ"])
        }
        guard let video = meta.primaryVideo else {
            throw NSError(domain: "Torrent", code: 20, userInfo: [NSLocalizedDescriptionKey: "Không có file video trong torrent"])
        }

        // Không pre-allocate file quá lớn trên máy (tránh crash/OOM) — chỉ tạo file rỗng, ghi theo piece
        let safeName = video.path
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "..", with: "_")
        let out = workDir.appendingPathComponent(safeName)
        try? FileManager.default.removeItem(at: out)
        FileManager.default.createFile(atPath: out.path, contents: nil)
        let fh = try FileHandle(forWritingTo: out)
        // Chỉ truncate nếu file < 2GB để tránh đầy ổ / chậm
        if video.length > 0, video.length < 2_000_000_000 {
            try fh.truncate(atOffset: UInt64(video.length))
        }
        fileHandle = fh
        outputFile = out

        let startPiece = Int(video.offset / Int64(meta.pieceLength))
        let endPiece = Int((video.offset + video.length - 1) / Int64(meta.pieceLength))
        let last = max(0, meta.pieceCount - 1)
        let lo = max(0, min(startPiece, last))
        let hi = max(lo, min(endPiece, last))
        wantedPieces = Array(lo...hi)
        nextRequestIndex = 0
        pieceStatus = Array(repeating: false, count: meta.pieceCount)
        pieceBuffers = [:]

        await MainActor.run {
            self.phase = .announcing
            self.message = "Kết nối tracker…"
        }

        var allPeers: [PeerAddr] = []
        await withTaskGroup(of: [PeerAddr].self) { group in
            for tr in meta.trackers.prefix(8) where tr.scheme == "http" || tr.scheme == "https" {
                group.addTask {
                    await TrackerClient.announceHTTP(
                        tracker: tr,
                        infoHash: meta.infoHash,
                        peerId: self.peerId,
                        left: meta.totalLength
                    )
                }
            }
            for await list in group {
                allPeers.append(contentsOf: list)
            }
        }
        var seen = Set<PeerAddr>()
        allPeers = allPeers.filter { seen.insert($0).inserted }

        await MainActor.run {
            self.peers = allPeers.count
            self.phase = .downloading
            self.message = "Peers: \(allPeers.count) · đang tải…"
        }

        guard !allPeers.isEmpty else {
            throw NSError(
                domain: "Torrent", code: 21,
                userInfo: [NSLocalizedDescriptionKey: "Không có peer. Thử VPN hoặc mở magnet bằng app torrent khác."]
            )
        }
        guard !stopped else { return }

        for addr in allPeers.prefix(12) {
            let pc = PeerConnection(addr: addr, infoHash: meta.infoHash, peerId: peerId)
            pc.onPiece = { [weak self] index, block in
                self?.handleBlock(index: index, data: block, meta: meta, video: video)
            }
            pc.onReady = { [weak self] in
                self?.pumpRequests(to: pc, meta: meta)
            }
            peersConn.append(pc)
            pc.connect()
        }

        let threshold = min(video.length, Int64(meta.pieceLength) * 2)
        for _ in 0..<180 {
            if stopped { return }
            try await Task.sleep(nanoseconds: 500_000_000)
            if downloadedBytes >= max(threshold, 64 * 1024) {
                try startServing(file: out, name: video.path)
                return
            }
            let done = wantedPieces.allSatisfy { idx in
                idx >= 0 && idx < pieceStatus.count && pieceStatus[idx]
            }
            if done {
                try startServing(file: out, name: video.path)
                return
            }
        }
        if downloadedBytes > 0 {
            try startServing(file: out, name: video.path)
            return
        }
        throw NSError(
            domain: "Torrent", code: 22,
            userInfo: [NSLocalizedDescriptionKey: "Tải quá chậm. Peers: \(peersConn.count). Thử torrent nhiều seed hơn hoặc mở magnet ngoài app."]
        )
    }

    private func handleBlock(index: Int, data: Data, meta: TorrentMeta, video: TorrentFileEntry) {
        guard !stopped, index >= 0, index < meta.pieceCount, !data.isEmpty else { return }
        lock.lock()
        defer { lock.unlock() }

        if index < pieceStatus.count, pieceStatus[index] { return }

        var buf = pieceBuffers[index] ?? Data()
        // Giới hạn kích thước buffer piece
        if buf.count + data.count > meta.pieceLength + 32 * 1024 {
            pieceBuffers[index] = nil
            return
        }
        buf.append(data)
        pieceBuffers[index] = buf

        let expected: Int = {
            if index == meta.pieceCount - 1 {
                let rem = Int(meta.totalLength % Int64(meta.pieceLength))
                return rem == 0 ? meta.pieceLength : rem
            }
            return meta.pieceLength
        }()
        guard buf.count >= expected else { return }

        let piece = Data(buf.prefix(expected))
        guard let wantHash = meta.pieceHash(at: index) else {
            pieceBuffers[index] = nil
            return
        }
        let hash = Data(Insecure.SHA1.hash(data: piece))
        guard hash == wantHash else {
            pieceBuffers[index] = nil
            return
        }

        let pieceGlobalOffset = Int64(index) * Int64(meta.pieceLength)
        let writeOffset = pieceGlobalOffset - video.offset
        if writeOffset >= 0, writeOffset < video.length {
            let maxLen = min(Int64(piece.count), video.length - writeOffset)
            if maxLen > 0 {
                let slice = Data(piece.prefix(Int(maxLen)))
                let offset = UInt64(writeOffset)
                ioQueue.async { [weak self] in
                    guard let self, let fh = self.fileHandle else { return }
                    do {
                        try fh.seek(toOffset: offset)
                        fh.write(slice)
                    } catch {
                        // bỏ qua lỗi ghi từng piece
                    }
                }
                downloadedBytes += Int64(slice.count)
            }
        }
        if index < pieceStatus.count { pieceStatus[index] = true }
        pieceBuffers[index] = nil

        let done = wantedPieces.filter { idx in
            idx >= 0 && idx < pieceStatus.count && pieceStatus[idx]
        }.count
        let prog = Double(done) / Double(max(1, wantedPieces.count))
        DispatchQueue.main.async {
            self.progress = min(1, prog)
            self.message = String(format: "Đã tải %.0f%% · %d peers", prog * 100, self.peersConn.count)
        }
        for pc in peersConn { pumpRequests(to: pc, meta: meta) }
    }

    private func pumpRequests(to peer: PeerConnection, meta: TorrentMeta) {
        lock.lock()
        defer { lock.unlock() }
        guard !wantedPieces.isEmpty else { return }
        var sent = 0
        var i = nextRequestIndex
        var scanned = 0
        while sent < 3, scanned < wantedPieces.count {
            if i >= wantedPieces.count { i = 0 }
            let idx = wantedPieces[i]
            i += 1
            scanned += 1
            guard idx >= 0, idx < pieceStatus.count, !pieceStatus[idx] else { continue }
            guard peer.hasPiece(idx) || peer.bitfield.isEmpty else { continue }
            let len: Int = {
                if idx == meta.pieceCount - 1 {
                    let rem = Int(meta.totalLength % Int64(meta.pieceLength))
                    return rem == 0 ? meta.pieceLength : rem
                }
                return meta.pieceLength
            }()
            var begin = 0
            while begin < len {
                let block = min(16 * 1024, len - begin)
                peer.request(piece: idx, begin: begin, length: block)
                begin += block
            }
            sent += 1
        }
        nextRequestIndex = i % max(1, wantedPieces.count)
    }

    private func startServing(file: URL, name: String) throws {
        guard !stopped else { return }
        let path = (name as NSString).lastPathComponent
        try server.start(serving: file, path: path.isEmpty ? "video" : path)
        guard let u = server.baseURL else {
            throw NSError(domain: "Torrent", code: 30, userInfo: [NSLocalizedDescriptionKey: "HTTP local lỗi"])
        }
        DispatchQueue.main.async {
            guard !self.stopped else { return }
            self.phase = .serving
            self.playURL = u
            self.message = "Đang phát qua HTTP local"
        }
    }
}
