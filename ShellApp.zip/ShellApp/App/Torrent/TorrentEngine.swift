import Foundation
import Combine

/// Phiên bản ổn định: chỉ tải metadata .torrent + giữ magnet để share.
/// Không kết nối peer / không ghi file / không HTTP server → tránh crash.
final class TorrentEngine: ObservableObject {
    enum Phase: String {
        case idle, resolving, ready, failed
    }

    @Published private(set) var phase: Phase = .idle
    @Published private(set) var progress: Double = 0
    @Published private(set) var message: String = ""
    @Published private(set) var playURL: URL? = nil
    @Published private(set) var peers: Int = 0
    @Published private(set) var downloadedBytes: Int64 = 0
    @Published private(set) var totalBytes: Int64 = 0
    @Published private(set) var magnetForShare: String?
    @Published private(set) var torrentName: String = ""
    @Published private(set) var fileList: [String] = []

    private var stopped = false

    func stop() {
        stopped = true
        phase = .idle
        playURL = nil
    }

    func start(magnet: String, torrentFileURL: URL?) async {
        stopped = false
        await MainActor.run {
            phase = .resolving
            message = "Đang tải thông tin torrent…"
            progress = 0
            magnetForShare = magnet
            playURL = nil
            torrentName = ""
            fileList = []
            totalBytes = 0
        }

        do {
            let data = try await loadTorrentData(preferred: torrentFileURL)
            guard !stopped else { return }
            let meta = try TorrentMeta.fromTorrentFile(data, extraTrackers: MagnetLink.parse(magnet)?.trackers ?? [])
            guard !stopped else { return }
            await MainActor.run {
                self.torrentName = meta.name
                self.totalBytes = meta.totalLength
                self.fileList = meta.files.prefix(20).map { f in
                    let mb = Double(f.length) / 1_048_576
                    return String(format: "%@ (%.1f MB)", f.path, mb)
                }
                self.message = "Torrent sẵn sàng.\nPhát trong app chưa ổn định trên iOS — hãy mở magnet bằng app torrent khác."
                self.phase = .ready
                self.progress = 1
            }
        } catch {
            guard !stopped else { return }
            await MainActor.run {
                self.phase = .failed
                // Vẫn cho share magnet
                self.magnetForShare = magnet
                self.message = error.localizedDescription
            }
        }
    }

    private func loadTorrentData(preferred: URL?) async throws -> Data {
        var candidates: [URL] = []
        if let preferred { candidates.append(preferred) }
        if let preferred {
            let id = preferred.lastPathComponent
                .replacingOccurrences(of: ".torrent", with: "")
                .filter { $0.isNumber }
            if !id.isEmpty {
                if let u = URL(string: "https://nyaa.si/download/\(id).torrent") { candidates.append(u) }
                if let u = URL(string: "https://nyaa.media/download/\(id).torrent") { candidates.append(u) }
            }
        }
        var seen = Set<String>()
        candidates = candidates.filter { seen.insert($0.absoluteString).inserted }

        var last: Error = NSError(
            domain: "Torrent", code: 40,
            userInfo: [NSLocalizedDescriptionKey: "Không tải được .torrent (mạng có thể chặn nyaa.si). Vẫn có thể mở magnet."]
        )
        for url in candidates {
            await MainActor.run { self.message = "Tải metadata…\n\(url.host ?? "")" }
            do {
                var req = URLRequest(url: url, timeoutInterval: 25)
                req.setValue(
                    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
                    forHTTPHeaderField: "User-Agent"
                )
                req.setValue("https://nyaa.media/", forHTTPHeaderField: "Referer")
                let (data, resp) = try await URLSession.shared.data(for: req)
                if let http = resp as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                    last = NSError(domain: "Torrent", code: http.statusCode,
                                   userInfo: [NSLocalizedDescriptionKey: "HTTP \(http.statusCode) từ \(url.host ?? "")"])
                    continue
                }
                if data.first == UInt8(ascii: "d") {
                    return data
                }
                last = NSError(domain: "Torrent", code: 41,
                               userInfo: [NSLocalizedDescriptionKey: "Server trả HTML (có thể bị chặn). Dùng nút mở magnet."])
            } catch {
                last = error
            }
        }
        throw last
    }
}
