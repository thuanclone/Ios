import Foundation
import Network

/// HTTP server local phục vụ file torrent đang tải (hỗ trợ Range cho seek).
final class LocalHTTPServer {
    private var listener: NWListener?
    private let queue = DispatchQueue(label: "local.http.server")
    private(set) var port: UInt16 = 0
    private var fileURL: URL?
    private var pathName: String = "video"

    var baseURL: URL? {
        guard port > 0 else { return nil }
        return URL(string: "http://127.0.0.1:\(port)/\(pathName)")
    }

    func start(serving file: URL, path: String = "video") throws {
        stop()
        fileURL = file
        pathName = path
        let params = NWParameters.tcp
        let listener = try NWListener(using: params, on: .any)
        self.listener = listener
        listener.stateUpdateHandler = { [weak self] state in
            if case .ready = state, let p = self?.listener?.port?.rawValue {
                self?.port = p
            }
        }
        listener.newConnectionHandler = { [weak self] conn in
            self?.handle(conn)
        }
        listener.start(queue: queue)
        // đợi port sẵn sàng ngắn
        for _ in 0..<50 {
            if port > 0 { break }
            Thread.sleep(forTimeInterval: 0.02)
        }
        guard port > 0 else { throw NSError(domain: "LocalHTTP", code: 1, userInfo: [NSLocalizedDescriptionKey: "Không mở được cổng HTTP local"]) }
    }

    func stop() {
        listener?.cancel()
        listener = nil
        port = 0
    }

    private func handle(_ conn: NWConnection) {
        conn.start(queue: queue)
        conn.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) { [weak self] data, _, _, _ in
            guard let self, let data, let req = String(data: data, encoding: .utf8) else {
                conn.cancel(); return
            }
            self.respond(conn: conn, request: req)
        }
    }

    private func respond(conn: NWConnection, request: String) {
        guard let fileURL else {
            send(conn, status: 500, headers: [:], body: Data("no file".utf8)); return
        }
        let attrs = try? FileManager.default.attributesOfItem(atPath: fileURL.path)
        let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
        var rangeStart: Int64 = 0
        var rangeEnd: Int64 = max(0, size - 1)
        var status = 200

        if let rangeLine = request.split(separator: "\r\n").first(where: { $0.lowercased().hasPrefix("range:") }) {
            // bytes=start-end
            let part = rangeLine.dropFirst(6).trimmingCharacters(in: .whitespaces)
            if part.hasPrefix("bytes=") {
                let r = part.dropFirst(6)
                let sides = r.split(separator: "-", maxSplits: 1)
                if let s = sides.first, let v = Int64(s) { rangeStart = v }
                if sides.count > 1, let e = Int64(sides[1]) { rangeEnd = e }
                else { rangeEnd = size - 1 }
                rangeStart = max(0, min(rangeStart, size - 1))
                rangeEnd = max(rangeStart, min(rangeEnd, size - 1))
                status = 206
            }
        }

        let length = rangeEnd - rangeStart + 1
        guard let handle = try? FileHandle(forReadingFrom: fileURL) else {
            send(conn, status: 404, headers: [:], body: Data()); return
        }
        defer { try? handle.close() }
        do {
            try handle.seek(toOffset: UInt64(rangeStart))
            let body = handle.readData(ofLength: Int(length))
            var headers: [String: String] = [
                "Content-Type": mime(for: fileURL),
                "Accept-Ranges": "bytes",
                "Content-Length": "\(body.count)",
                "Connection": "close",
            ]
            if status == 206 {
                headers["Content-Range"] = "bytes \(rangeStart)-\(rangeEnd)/\(size)"
            }
            send(conn, status: status, headers: headers, body: body)
        } catch {
            send(conn, status: 500, headers: [:], body: Data())
        }
    }

    private func send(_ conn: NWConnection, status: Int, headers: [String: String], body: Data) {
        let reason = status == 206 ? "Partial Content" : (status == 200 ? "OK" : "Error")
        var head = "HTTP/1.1 \(status) \(reason)\r\n"
        for (k, v) in headers { head += "\(k): \(v)\r\n" }
        head += "\r\n"
        var data = Data(head.utf8)
        data.append(body)
        conn.send(content: data, completion: .contentProcessed { _ in
            conn.cancel()
        })
    }

    private func mime(for url: URL) -> String {
        switch url.pathExtension.lowercased() {
        case "mp4", "m4v": return "video/mp4"
        case "mkv": return "video/x-matroska"
        case "webm": return "video/webm"
        case "avi": return "video/x-msvideo"
        case "ts", "m2ts": return "video/mp2t"
        case "m3u8": return "application/vnd.apple.mpegurl"
        default: return "application/octet-stream"
        }
    }
}
