import Foundation
import Network

struct PeerAddr: Hashable {
    let host: String
    let port: UInt16
}

enum TrackerClient {
    /// Announce HTTP tracker, trả danh sách peer.
    static func announceHTTP(tracker: URL, infoHash: Data, peerId: Data, port: UInt16 = 6881, left: Int64) async -> [PeerAddr] {
        guard var comps = URLComponents(url: tracker, resolvingAgainstBaseURL: false) else { return [] }
        // info_hash và peer_id phải raw-urlencoded (byte)
        var query: [URLQueryItem] = []
        // Dùng thủ công vì URLQueryItem encode sai binary
        let ih = percentEncodeBytes(infoHash)
        let pid = percentEncodeBytes(peerId)
        var q = "info_hash=\(ih)&peer_id=\(pid)&port=\(port)&uploaded=0&downloaded=0&left=\(left)&compact=1&event=started&numwant=50"
        if let existing = comps.percentEncodedQuery, !existing.isEmpty {
            q = existing + "&" + q
        }
        comps.percentEncodedQuery = q
        guard let url = comps.url else { return [] }

        var req = URLRequest(url: url, timeoutInterval: 12)
        req.setValue("ShellApp/0.1", forHTTPHeaderField: "User-Agent")
        do {
            let (data, _) = try await URLSession.shared.data(for: req)
            return parseCompactPeers(from: data)
        } catch {
            return []
        }
    }

    private static func percentEncodeBytes(_ d: Data) -> String {
        d.map { b in
            let c = Character(UnicodeScalar(b))
            if c.isLetter || c.isNumber || "-_.~".contains(c) { return String(c) }
            return String(format: "%%%02X", b)
        }.joined()
    }

    private static func parseCompactPeers(from data: Data) -> [PeerAddr] {
        // Thử bencode
        if let root = try? Bencode.parse(data), let dict = root.dict {
            if let peersData = dict["peers"]?.data {
                return decodeCompact(peersData)
            }
            if let list = dict["peers"]?.list {
                var out: [PeerAddr] = []
                for p in list {
                    guard let d = p.dict,
                          let ip = d["ip"]?.string,
                          let port = d["port"]?.int else { continue }
                    out.append(PeerAddr(host: ip, port: UInt16(clamping: port)))
                }
                return out
            }
        }
        return []
    }

    private static func decodeCompact(_ data: Data) -> [PeerAddr] {
        var out: [PeerAddr] = []
        var i = 0
        while i + 6 <= data.count {
            let ip = "\(data[i]).\(data[i+1]).\(data[i+2]).\(data[i+3])"
            let port = UInt16(data[i+4]) << 8 | UInt16(data[i+5])
            out.append(PeerAddr(host: ip, port: port))
            i += 6
        }
        return out
    }
}
