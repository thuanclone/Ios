import Foundation
import PluginKit

struct ProgressEntry: Codable, Identifiable, Hashable {
    var id: String { "\(sourceID)|\(itemID)" }
    let sourceID: String
    let itemID: String
    var title: String
    var cover: String?
    var kind: MediaKind
    var lastChapterID: String?
    var lastChapterTitle: String?
    var page: Int = 0
    var seconds: Double = 0
    var favorite = false
    var updated = Date()
}

/// Lưu tiến độ và mục yêu thích vào UserDefaults (không cần SwiftData nên chạy được iOS 16).
final class ProgressStore: ObservableObject {
    @Published private(set) var entries: [ProgressEntry] = []
    private let key = "progress.v1"

    init() {
        if let d = UserDefaults.standard.data(forKey: key),
           let e = try? JSONDecoder().decode([ProgressEntry].self, from: d) { entries = e }
    }

    func entry(source: String, item: String) -> ProgressEntry? {
        entries.first { $0.sourceID == source && $0.itemID == item }
    }

    func update(source: ContentSource, item: MediaItem, _ change: (inout ProgressEntry) -> Void) {
        let sid = source.manifest.id
        var e = entry(source: sid, item: item.id)
            ?? ProgressEntry(sourceID: sid, itemID: item.id, title: item.title, cover: item.coverURL, kind: source.manifest.kind)
        change(&e); e.updated = Date()
        entries.removeAll { $0.id == e.id }
        entries.insert(e, at: 0)
        save()
    }

    func toggleFavorite(source: ContentSource, item: MediaItem) {
        update(source: source, item: item) { $0.favorite.toggle() }
    }

    private func save() {
        if let d = try? JSONEncoder().encode(entries) { UserDefaults.standard.set(d, forKey: key) }
    }
}
