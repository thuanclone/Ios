import Foundation

/// Metadata anime (poster, điểm, thể loại) lấy từ AniList, không liên quan tới nguồn phát.
struct AnimeCard: Identifiable, Hashable {
    let id: Int
    let title: String
    let cover: URL?
    let coverXL: URL?
    let banner: URL?
    let score: Double?
    let episodes: Int?
    let genres: [String]
}

enum AniList {
    static func seasonal(date: Date = Date()) async throws -> [AnimeCard] {
        let month = Calendar.current.component(.month, from: date)
        let year = Calendar.current.component(.year, from: date)
        let seasons = ["WINTER", "WINTER", "WINTER", "SPRING", "SPRING", "SPRING",
                       "SUMMER", "SUMMER", "SUMMER", "FALL", "FALL", "FALL"]
        let query = """
        query ($season: MediaSeason, $year: Int) {
          Page(perPage: 20) {
            media(season: $season, seasonYear: $year, type: ANIME, sort: POPULARITY_DESC) {
              id title { romaji english } coverImage { large extraLarge } bannerImage
              averageScore episodes genres
            }
          }
        }
        """
        var req = URLRequest(url: URL(string: "https://graphql.anilist.co")!)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: [
            "query": query, "variables": ["season": seasons[month - 1], "year": year]
        ])
        let (data, _) = try await URLSession.shared.data(for: req)
        let res = try JSONDecoder().decode(Response.self, from: data)
        return res.data.Page.media.map {
            AnimeCard(id: $0.id, title: $0.title.english ?? $0.title.romaji ?? "?",
                      cover: $0.coverImage?.large.flatMap(URL.init), coverXL: $0.coverImage?.extraLarge.flatMap(URL.init), banner: $0.bannerImage.flatMap(URL.init),
                      score: $0.averageScore.map { Double($0) / 10 }, episodes: $0.episodes, genres: $0.genres ?? [])
        }
    }

    private struct Response: Decodable {
        let data: D
        struct D: Decodable { let Page: P }
        struct P: Decodable { let media: [M] }
        struct M: Decodable {
            let id: Int; let title: T; let coverImage: C?; let bannerImage: String?
            let averageScore: Int?; let episodes: Int?; let genres: [String]?
        }
        struct T: Decodable { let romaji: String?; let english: String? }
        struct C: Decodable { let large: String?; let extraLarge: String? }
    }
}
