import UIKit
import UniformTypeIdentifiers

/// Bộ chọn file bằng UIKit. Bản fileImporter của SwiftUI trên iOS 16 hay kẹt khi nằm trong sheet.
/// asCopy = true: file được sao chép sẵn vào thư mục tạm nên đọc thẳng được, không cần quyền security-scoped.
final class DocPicker: NSObject, UIDocumentPickerDelegate {
    private static var current: DocPicker?
    private let onPick: (URL) -> Void

    private init(onPick: @escaping (URL) -> Void) { self.onPick = onPick }

    static func present(types: [UTType] = [.item], onPick: @escaping (URL) -> Void) {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
        let delegate = DocPicker(onPick: onPick)
        picker.delegate = delegate
        picker.allowsMultipleSelection = false
        current = delegate                      // giữ delegate sống tới khi chọn xong
        topViewController()?.present(picker, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        if let url = urls.first { onPick(url) }
        DocPicker.current = nil
    }
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { DocPicker.current = nil }

    private static func topViewController() -> UIViewController? {
        let window = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow }
        var top = window?.rootViewController
        while let next = top?.presentedViewController { top = next }
        return top
    }
}
