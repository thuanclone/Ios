import Foundation

struct Cue: Hashable {
    let start: Double
    let end: Double
    let text: String
}

/// Đọc phụ đề SRT, WebVTT và ASS/SSA (chỉ lấy phần chữ).
enum SubtitleParser {
    /// Windows-1258 (tiếng Việt đời cũ) không có sẵn trong String.Encoding nên lấy qua CoreFoundation.
    private static let cp1258 = String.Encoding(rawValue: CFStringConvertEncodingToNSStringEncoding(
        CFStringEncoding(CFStringEncodings.windowsVietnamese.rawValue)))

    static func decode(_ data: Data) -> String {
        if data.starts(with: [0xFF, 0xFE]) || data.starts(with: [0xFE, 0xFF]),
           let s = String(data: data, encoding: .utf16) { return s }
        var s = String(data: data, encoding: .utf8)
            ?? String(data: data, encoding: cp1258)
            ?? String(data: data, encoding: .isoLatin1) ?? ""
        if s.hasPrefix("\u{FEFF}") { s.removeFirst() }
        return s
    }

    static func parse(_ raw: String) -> [Cue] {
        let text = raw.replacingOccurrences(of: "\r\n", with: "\n").replacingOccurrences(of: "\r", with: "\n")
        if text.contains("[Script Info]") || text.contains("Dialogue:") { return parseASS(text) }
        return parseSRTorVTT(text)
    }

    private static func parseSRTorVTT(_ text: String) -> [Cue] {
        var cues: [Cue] = []
        for block in text.components(separatedBy: "\n\n") {
            let lines = block.components(separatedBy: "\n")
            guard let i = lines.firstIndex(where: { $0.contains("-->") }) else { continue }
            let parts = lines[i].components(separatedBy: "-->")
            guard parts.count == 2,
                  let s = time(parts[0]),
                  let endStr = parts[1].split(separator: " ").first(where: { !$0.isEmpty }),
                  let e = time(String(endStr)) else { continue }
            let body = strip(lines[(i + 1)...].joined(separator: "\n"))
            if !body.isEmpty { cues.append(Cue(start: s, end: e, text: body)) }
        }
        return cues.sorted { $0.start < $1.start }
    }

    private static func parseASS(_ text: String) -> [Cue] {
        var cues: [Cue] = []
        var si = 1, ei = 2, ti = 9, count = 10
        for line in text.components(separatedBy: "\n") {
            if line.hasPrefix("Format:"), line.contains("Start") {
                let f = line.dropFirst(7).split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }
                if let s = f.firstIndex(of: "Start"), let e = f.firstIndex(of: "End"), let t = f.firstIndex(of: "Text") {
                    si = s; ei = e; ti = t; count = f.count
                }
            } else if line.hasPrefix("Dialogue:") {
                let f = line.dropFirst(9).split(separator: ",", maxSplits: count - 1, omittingEmptySubsequences: false).map(String.init)
                guard f.count == count, let s = time(f[si]), let e = time(f[ei]) else { continue }
                let body = strip(f[ti])
                if !body.isEmpty { cues.append(Cue(start: s, end: e, text: body)) }
            }
        }
        return cues.sorted { $0.start < $1.start }
    }

    /// "00:01:02,500", "00:01:02.500", "01:02.500", "0:01:02.50"
    private static func time(_ s: String) -> Double? {
        let t = s.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: ",", with: ".")
        let p = t.split(separator: ":").map(String.init)
        guard (2...3).contains(p.count) else { return nil }
        var secs = 0.0
        for c in p { guard let v = Double(c) else { return nil }; secs = secs * 60 + v }
        return secs
    }

    private static func strip(_ s: String) -> String {
        s.replacingOccurrences(of: "\\{[^}]*\\}", with: "", options: .regularExpression)
            .replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
            .replacingOccurrences(of: "\\N", with: "\n")
            .replacingOccurrences(of: "\\n", with: "\n")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
