import Foundation
import Network

/// Proxy HLS kiểu Lotus: segment trên TikTok CDN = PNG header + MPEG-TS.
/// - Tải m3u8, rewrite URI segment → http://127.0.0.1:port/seg?u=...
/// - Khi client xin segment: tải CDN, bỏ header PNG, trả video/mp2t.
final class LotusHLSProxy {
    private var listener: NWListener?
    private let queue = DispatchQueue(label: "lotus.hls.proxy")
    private(set) var port: UInt16 = 0
    private var playlistData = Data()
    private let session: URLSession = {
        let c = URLSessionConfiguration.ephemeral
        c.timeoutIntervalForRequest = 30
        c.httpAdditionalHeaders = [
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
            "Referer": "https://www.tiktok.com/",
            "Accept": "*/*",
        ]
        return URLSession(configuration: c)
    }()

    /// Số byte PNG Lotus mặc định (phapsu.png).
    static let lotusPNGHeaderBytes = 188

    deinit { stop() }

    func stop() {
        listener?.cancel()
        listener = nil
        port = 0
    }

    /// Chuẩn bị playlist local. Trả URL m3u8 trên localhost, hoặc URL gốc nếu không cần proxy.
    func prepare(remotePlaylist url: URL) async throws -> URL {
        stop()
        let (data, resp) = try await session.data(from: url)
        if let http = resp as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            throw NSError(domain: "LotusHLS", code: http.statusCode,
                          userInfo: [NSLocalizedDescriptionKey: "Không tải được m3u8 (HTTP \(http.statusCode))"])
        }
        guard var text = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1) else {
            throw NSError(domain: "LotusHLS", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "m3u8 không đọc được"])
        }

        // Chỉ proxy khi có segment CDN kiểu Lotus / TikTok image CDN
        let needsStrip = text.contains("ibyteimg.com")
            || text.contains("tiktokcdn.com")
            || text.contains("akamaized.net/origin")
            || text.contains("tos-alisg-i-")

        if !needsStrip {
            return url
        }

        try startListener()
        guard port > 0 else {
            throw NSError(domain: "LotusHLS", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "Không mở proxy local"])
        }

        // Rewrite absolute segment URLs
        text = Self.rewritePlaylist(text, proxyPort: port)
        playlistData = Data(text.utf8)

        return URL(string: "http://127.0.0.1:\(port)/playlist.m3u8")!
    }

    private static func rewritePlaylist(_ src: String, proxyPort: UInt16) -> String {
        let lines = src.components(separatedBy: .newlines)
        var out: [String] = []
        for line in lines {
            let t = line.trimmingCharacters(in: .whitespaces)
            if t.isEmpty || t.hasPrefix("#") {
                out.append(line)
                continue
            }
            // URI segment (absolute or relative — Lotus dùng absolute)
            if let remote = URL(string: t), remote.scheme == "http" || remote.scheme == "https" {
                let encoded = t.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? t
                out.append("http://127.0.0.1:\(proxyPort)/seg?u=\(encoded)")
            } else {
                out.append(line)
            }
        }
        return out.joined(separator: "\n")
    }

    private func startListener() throws {
        let params = NWParameters.tcp
        let listener = try NWListener(using: params, on: .any)
        self.listener = listener
        listener.stateUpdateHandler = { [weak self] state in
            if case .ready = state, let p = self?.listener?.port?.rawValue {
                self?.port = p
            }
        }
        listener.newConnectionHandler = { [weak self] conn in
            self?.handle(conn)
        }
        listener.start(queue: queue)
        for _ in 0..<100 {
            if port > 0 { break }
            Thread.sleep(forTimeInterval: 0.02)
        }
    }

    private func handle(_ conn: NWConnection) {
        conn.start(queue: queue)
        conn.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) { [weak self] data, _, _, _ in
            guard let self, let data, let req = String(data: data, encoding: .utf8) else {
                conn.cancel(); return
            }
            let first = req.split(separator: "\r\n", maxSplits: 1).first.map(String.init) ?? ""
            if first.contains("/playlist.m3u8") {
                self.respond(conn, status: 200, contentType: "application/vnd.apple.mpegurl", body: self.playlistData)
                return
            }
            if first.contains("/seg?") {
                // Parse u=
                if let range = first.range(of: "u="),
                   let urlPart = first[range.upperBound...].split(separator: " ").first {
                    let decoded = String(urlPart).removingPercentEncoding ?? String(urlPart)
                    if let segURL = URL(string: decoded) {
                        self.serveSegment(conn, remote: segURL)
                        return
                    }
                }
                self.respond(conn, status: 400, contentType: "text/plain", body: Data("bad seg".utf8))
                return
            }
            self.respond(conn, status: 404, contentType: "text/plain", body: Data("not found".utf8))
        }
    }

    private func serveSegment(_ conn: NWConnection, remote: URL) {
        session.dataTask(with: remote) { [weak self] data, _, error in
            guard let self else { conn.cancel(); return }
            guard let data, error == nil, !data.isEmpty else {
                self.respond(conn, status: 502, contentType: "text/plain", body: Data("seg fail".utf8))
                return
            }
            let stripped = Self.stripDisguise(data)
            self.respond(conn, status: 200, contentType: "video/mp2t", body: stripped)
        }.resume()
    }

    /// Bỏ lớp PNG ngụy trang Lotus / ImageX.
    static func stripDisguise(_ data: Data) -> Data {
        guard data.count > 8 else { return data }
        // PNG signature
        let png: [UInt8] = [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]
        let isPNG = data.prefix(8).elementsEqual(png)
        if isPNG {
            // Tìm IEND chunk → payload sau CRC (8 byte từ "IEND")
            if let r = data.range(of: Data("IEND".utf8)) {
                let after = r.upperBound + 4 // CRC
                if after < data.count {
                    return Data(data[after...])
                }
            }
            // Fallback Lotus cố định 188 byte
            if data.count > Self.lotusPNGHeaderBytes {
                return Data(data[Self.lotusPNGHeaderBytes...])
            }
        }
        // Đã là TS (sync 0x47) hoặc fMP4
        return data
    }

    private func respond(_ conn: NWConnection, status: Int, contentType: String, body: Data) {
        let reason: String
        switch status {
        case 200: reason = "OK"
        case 400: reason = "Bad Request"
        case 404: reason = "Not Found"
        case 502: reason = "Bad Gateway"
        default: reason = "Error"
        }
        var head = "HTTP/1.1 \(status) \(reason)\r\n"
        head += "Content-Type: \(contentType)\r\n"
        head += "Content-Length: \(body.count)\r\n"
        head += "Access-Control-Allow-Origin: *\r\n"
        head += "Connection: close\r\n\r\n"
        var out = Data(head.utf8)
        out.append(body)
        conn.send(content: out, completion: .contentProcessed { _ in
            conn.cancel()
        })
    }
}
