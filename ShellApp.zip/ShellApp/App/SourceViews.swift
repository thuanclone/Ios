import SwiftUI
import AVKit
import PluginKit

/// Tìm trong các plugin đã cài theo loại (anime/manga).
struct SourceSearchView: View {
    let kind: MediaKind
    var initialQuery: String = ""
    @EnvironmentObject var plugins: PluginManager
    @State private var selected: String = ""
    @State private var query = ""
    @State private var results: [MediaItem] = []
    @State private var loading = false
    @State private var error: String?

    private var sources: [ContentSource] { plugins.sources(of: kind) }
    private var current: ContentSource? { sources.first { $0.manifest.id == selected } ?? sources.first }

    var body: some View {
        Group {
            if sources.isEmpty {
                Text("Chưa có plugin nào cho mục này.\nThêm plugin trong Cài đặt.")
                    .multilineTextAlignment(.center).foregroundColor(.secondary).padding()
            } else {
                ScrollView {
                    if sources.count > 1 {
                        Picker("Nguồn", selection: $selected) {
                            ForEach(sources, id: \.manifest.id) { Text($0.manifest.name).tag($0.manifest.id) }
                        }.pickerStyle(.segmented).padding(.horizontal)
                    }
                    if loading { ProgressView().padding() }
                    if let error { Text(error).foregroundColor(.secondary).padding() }
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 110), spacing: 12)], spacing: 16) {
                        ForEach(results) { item in
                            if let src = current {
                                NavigationLink { MediaDetailView(source: src, item: item) } label: { ResultCard(item: item) }
                                    .buttonStyle(.plain)
                            }
                        }
                    }.padding(.horizontal)
                }
            }
        }
        .navigationTitle(kind == .anime ? "Tìm anime" : "Tìm manga")
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, prompt: "Tên")
        .onSubmit(of: .search) { Task { await run() } }
        .onChange(of: selected) { _ in Task { await run() } }
        .task {
            if selected.isEmpty { selected = sources.first?.manifest.id ?? "" }
            if query.isEmpty { query = initialQuery }
            await run()
        }
    }

    private func run() async {
        guard let src = current else { return }
        loading = true; error = nil
        defer { loading = false }
        do { results = try await src.search(query: query, page: 1) }
        catch { results = []; self.error = "Nguồn \(src.manifest.name) lỗi: \(error)" }
    }
}

struct ResultCard: View {
    let item: MediaItem
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            AsyncImage(url: item.coverURL.flatMap(URL.init)) { $0.resizable().scaledToFill() } placeholder: {
                ZStack { Color.gray.opacity(0.2); Image(systemName: "photo").foregroundColor(.secondary) }
            }
            .frame(height: 155).clipShape(RoundedRectangle(cornerRadius: 12))
            Text(item.title).font(.subheadline).lineLimit(2)
            if let s = item.subtitle { Text(s).font(.caption).foregroundColor(.secondary) }
        }
    }
}

private struct ReaderRoute: Identifiable { let id = UUID(); let chapter: Chapter }
private struct PlayerRoute: Identifiable { let id = UUID(); let chapter: Chapter; let info: StreamInfo }

struct MediaDetailView: View {
    let source: ContentSource
    let item: MediaItem
    @EnvironmentObject var progress: ProgressStore
    @State private var detail: MediaDetail?
    @State private var error: String?
    @State private var reader: ReaderRoute?
    @State private var player: PlayerRoute?

    private var entry: ProgressEntry? { progress.entry(source: source.manifest.id, item: item.id) }

    var body: some View {
        List {
            if let d = detail {
                Section {
                    HStack(alignment: .top, spacing: 12) {
                        AsyncImage(url: (d.coverURL ?? item.coverURL).flatMap(URL.init)) { $0.resizable().scaledToFill() } placeholder: { Color.gray.opacity(0.2) }
                            .frame(width: 100, height: 145).clipShape(RoundedRectangle(cornerRadius: 10))
                        VStack(alignment: .leading, spacing: 6) {
                            Text(d.title).font(.headline)
                            Text(d.genres.joined(separator: " · ")).font(.caption).foregroundColor(.secondary)
                            if let t = d.description { Text(t).font(.footnote).lineLimit(5) }
                        }
                    }
                }
                Section(source.manifest.kind == .anime ? "Tập" : "Chương") {
                    ForEach(d.chapters) { ch in
                        Button { open(ch) } label: {
                            HStack {
                                Text(ch.title).foregroundColor(.primary)
                                Spacer()
                                if entry?.lastChapterID == ch.id { Image(systemName: "clock.arrow.circlepath").foregroundColor(.indigo) }
                            }
                        }
                    }
                }
            } else if let error {
                Text(error).foregroundColor(.secondary)
            } else {
                ProgressView()
            }
        }
        .navigationTitle(item.title).navigationBarTitleDisplayMode(.inline)
        .toolbar {
            Button { progress.toggleFavorite(source: source, item: item) } label: {
                Image(systemName: entry?.favorite == true ? "heart.fill" : "heart")
            }
        }
        .task {
            do { detail = try await source.detail(id: item.id) } catch { self.error = "Không tải được chi tiết: \(error)" }
        }
        .fullScreenCover(item: $reader) { r in
            ReaderView(source: source, item: item, chapter: r.chapter, startPage: entry?.lastChapterID == r.chapter.id ? (entry?.page ?? 0) : 0)
        }
        .fullScreenCover(item: $player) { p in
            PlayerView(source: source, item: item, chapter: p.chapter, info: p.info,
                       startAt: entry?.lastChapterID == p.chapter.id ? (entry?.seconds ?? 0) : 0)
        }
    }

    private func open(_ ch: Chapter) {
        if source.manifest.kind == .manga { reader = ReaderRoute(chapter: ch); return }
        Task {
            do { player = PlayerRoute(chapter: ch, info: try await source.stream(episodeID: ch.id)) }
            catch { self.error = "Không lấy được luồng phát: \(error)" }
        }
    }
}

struct ReaderView: View {
    let source: ContentSource
    let item: MediaItem
    let chapter: Chapter
    let startPage: Int
    @EnvironmentObject var progress: ProgressStore
    @Environment(\.dismiss) private var dismiss
    @State private var pages: [String] = []
    @State private var index = 0
    @State private var error: String?

    var body: some View {
        ZStack(alignment: .bottom) {
            Color.black.ignoresSafeArea()
            if pages.isEmpty {
                if let error { Text(error).foregroundColor(.secondary) } else { ProgressView() }
            } else {
                TabView(selection: $index) {
                    ForEach(pages.indices, id: \.self) { i in
                        AsyncImage(url: URL(string: pages[i])) { $0.resizable().scaledToFit() } placeholder: { ProgressView() }
                            .tag(i)
                    }
                }
                .tabViewStyle(.page(indexDisplayMode: .never)).ignoresSafeArea()

                VStack(spacing: 4) {
                    Slider(value: Binding(get: { Double(index) }, set: { index = Int($0.rounded()) }),
                           in: 0...Double(max(pages.count - 1, 1)), step: 1)
                    Text("\(index + 1) / \(pages.count)").font(.caption).foregroundColor(.secondary)
                }
                .padding().background(.ultraThinMaterial).clipShape(RoundedRectangle(cornerRadius: 20)).padding()
            }
        }
        .overlay(alignment: .topLeading) {
            Button { dismiss() } label: {
                Image(systemName: "xmark").padding(12).background(.ultraThinMaterial).clipShape(Circle())
            }.padding()
        }
        .task {
            do {
                pages = try await source.pages(chapterID: chapter.id).pages
                index = min(startPage, max(pages.count - 1, 0))
            } catch { self.error = "Không tải được trang: \(error)" }
        }
        .onChange(of: index) { _ in save() }
        .onDisappear { save() }
    }

    private func save() {
        guard !pages.isEmpty else { return }
        progress.update(source: source, item: item) {
            $0.lastChapterID = chapter.id; $0.lastChapterTitle = chapter.title; $0.page = index
        }
    }
}
