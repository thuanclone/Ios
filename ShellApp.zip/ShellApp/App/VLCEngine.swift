import UIKit
#if canImport(VLCKitSPM)
import VLCKitSPM
#elseif canImport(MobileVLCKit)
import MobileVLCKit
#endif

struct VLCTrack { let index: Int32; let name: String }
enum VLCPlayState { case opening, buffering, playing, paused, stopped, ended, error }

#if canImport(VLCKitSPM) || canImport(MobileVLCKit)

/// Bọc toàn bộ API VLCKit ở một chỗ; phần còn lại của app không đụng tới kiểu của VLC.
final class VLCBackend: NSObject, VLCMediaPlayerDelegate {
    static let isAvailable = true
    private let player = VLCMediaPlayer()
    var onState: ((VLCPlayState) -> Void)?

    init(view: UIView, url: URL, headers: [String: String]?, start: Double, rate: Float) {
        super.init()
        player.drawable = view
        player.delegate = self
        let media = VLCMedia(url: url)
        media.addOption(":network-caching=1500")
        media.addOption(":http-reconnect")
        // Mặc định dùng cùng User-Agent với trình phát Apple để máy chủ đối xử giống nhau.
        var ua = "AppleCoreMedia/1.0.0.20G75 (iPhone; U; CPU OS 16_6 like Mac OS X; en_us)"
        for (k, v) in headers ?? [:] {
            switch k.lowercased() {
            case "user-agent": ua = v
            case "referer", "referrer": media.addOption(":http-referrer=\(v)")
            default: break
            }
        }
        media.addOption(":http-user-agent=\(ua)")
        if start > 5 { media.addOption(":start-time=\(Int(start))") }
        player.media = media
        player.rate = rate
        player.play()
    }

    func play() { player.play() }
    func pause() { player.pause() }
    func stop() { player.delegate = nil; player.stop(); player.drawable = nil }

    var isPlaying: Bool { player.isPlaying }
    var currentSeconds: Double { Double(player.time.intValue) / 1000 }
    var durationSeconds: Double { Double(player.media?.length.intValue ?? 0) / 1000 }
    func seek(to s: Double) { player.time = VLCTime(int: Int32(max(0, s) * 1000)) }
    var rate: Float { get { player.rate } set { player.rate = newValue } }

    /// Thông tin để chẩn đoán khi VLC không chạy.
    var debugInfo: String {
        "state=\(player.state.rawValue) media=\(player.media?.state.rawValue ?? -1) videoOut=\(player.hasVideoOut) seekable=\(player.isSeekable)"
    }

    var audioTracks: [VLCTrack] { tracks(player.audioTrackNames, player.audioTrackIndexes) }
    var subtitleTracks: [VLCTrack] { tracks(player.videoSubTitlesNames, player.videoSubTitlesIndexes) }
    var currentAudio: Int32 {
        get { player.currentAudioTrackIndex }
        set { player.currentAudioTrackIndex = newValue }
    }
    var currentSubtitle: Int32 {
        get { player.currentVideoSubTitleIndex }
        set { player.currentVideoSubTitleIndex = newValue }
    }

    private func tracks(_ names: [Any]?, _ indexes: [Any]?) -> [VLCTrack] {
        let n = (names as? [String]) ?? []
        let i = (indexes as? [NSNumber]) ?? []
        return zip(n, i).map { VLCTrack(index: $1.int32Value, name: $0) }
    }

    func mediaPlayerStateChanged(_ aNotification: Notification!) {
        let s: VLCPlayState
        switch player.state {
        case .opening: s = .opening
        case .buffering: s = .buffering
        case .playing: s = .playing
        case .paused: s = .paused
        case .stopped: s = .stopped
        case .ended: s = .ended
        case .error: s = .error
        default: s = .buffering
        }
        DispatchQueue.main.async { [weak self] in self?.onState?(s) }
    }
}

#else

/// Bản dự phòng khi build không có VLCKit: giữ nguyên giao diện, không làm gì.
final class VLCBackend: NSObject {
    static let isAvailable = false
    var onState: ((VLCPlayState) -> Void)?
    init(view: UIView, url: URL, headers: [String: String]?, start: Double, rate: Float) { super.init() }
    func play() {}
    func pause() {}
    func stop() {}
    var isPlaying: Bool { false }
    var currentSeconds: Double { 0 }
    var durationSeconds: Double { 0 }
    func seek(to s: Double) {}
    var rate: Float { get { 1 } set {} }
    var debugInfo: String { "VLC không có trong bản build" }
    var audioTracks: [VLCTrack] { [] }
    var subtitleTracks: [VLCTrack] { [] }
    var currentAudio: Int32 { get { -1 } set {} }
    var currentSubtitle: Int32 { get { -1 } set {} }
}

#endif
