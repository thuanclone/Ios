import UIKit
#if canImport(VLCKitSPM)
import VLCKitSPM
#elseif canImport(MobileVLCKit)
import MobileVLCKit
#endif

struct VLCTrack { let index: Int32; let name: String }
enum VLCPlayState { case opening, buffering, playing, paused, stopped, ended, error }

#if canImport(VLCKitSPM) || canImport(MobileVLCKit)

/// Gom nhật ký nội bộ của libvlc để hiện ra khi phát lỗi.
final class VLCLogCatcher: NSObject, VLCLibraryLogReceiverProtocol {
    static let shared = VLCLogCatcher()
    private let lock = NSLock()
    private var lines: [String] = []

    func reset() { lock.lock(); lines.removeAll(); lock.unlock() }

    func handleMessage(_ message: String, debugLevel level: Int32) {
        lock.lock()
        lines.append("[\(level)] \(message)")
        if lines.count > 400 { lines.removeFirst(150) }
        lock.unlock()
    }

    /// Chỉ giữ các dòng liên quan tới mạng, mở file, lỗi.
    func summary(maxLines: Int = 12) -> String {
        lock.lock(); let all = lines; lock.unlock()
        let keys = ["http", "error", "warn", "cannot", "fail", "refused", "timeout", "403", "404", "503",
                    "tls", "ssl", "gnutls", "open", "access", "demux", "mkv", "hls", "decoder", "buffer"]
        let picked = all.filter { l in let s = l.lowercased(); return keys.contains { s.contains($0) } }
        // Không dòng nào khớp bộ lọc thì in thẳng các dòng cuối để vẫn thấy được gì đó.
        let source = picked.isEmpty ? all : picked
        let body = source.suffix(maxLines).map { String($0.prefix(140)) }.joined(separator: "\n")
        return "(đã nhận \(all.count) dòng nhật ký)\n" + body
    }
}

/// Bọc toàn bộ API VLCKit ở một chỗ; phần còn lại của app không đụng tới kiểu của VLC.
final class VLCBackend: NSObject, VLCMediaPlayerDelegate {
    static let isAvailable = true
    private static var loggingEnabled = false

    private static func enableLogging() {
        guard !loggingEnabled else { return }
        loggingEnabled = true
        let lib = VLCLibrary.shared()
        lib.debugLoggingTarget = VLCLogCatcher.shared
        lib.debugLoggingLevel = 3
        lib.debugLogging = true
    }
    var logSummary: String { VLCLogCatcher.shared.summary() }
    private let player = VLCMediaPlayer()
    var onState: ((VLCPlayState) -> Void)?

    init(view: UIView, url: URL, headers: [String: String]?, start: Double, rate: Float) {
        super.init()
        Self.enableLogging()
        VLCLogCatcher.shared.reset()
        player.drawable = view
        player.delegate = self
        let media = VLCMedia(url: url)
        media.addOption(":network-caching=1500")
        // Mặc định dùng cùng User-Agent với trình phát Apple để máy chủ đối xử giống nhau.
        var ua = "AppleCoreMedia/1.0.0.20G75 (iPhone; U; CPU OS 16_6 like Mac OS X; en_us)"
        for (k, v) in headers ?? [:] {
            switch k.lowercased() {
            case "user-agent": ua = v
            case "referer", "referrer": media.addOption(":http-referrer=\(v)")
            default: break
            }
        }
        media.addOption(":http-user-agent=\(ua)")
        if start > 5 { media.addOption(":start-time=\(Int(start))") }
        player.media = media
        player.rate = rate
        player.play()
    }

    func play() { player.play() }
    func pause() { player.pause() }
    func stop() { player.delegate = nil; player.stop(); player.drawable = nil }

    var isPlaying: Bool { player.isPlaying }
    var currentSeconds: Double { Double(player.time.intValue) / 1000 }
    var durationSeconds: Double { Double(player.media?.length.intValue ?? 0) / 1000 }
    func seek(to s: Double) { player.time = VLCTime(int: Int32(max(0, s) * 1000)) }
    var rate: Float { get { player.rate } set { player.rate = newValue } }

    /// Thông tin để chẩn đoán khi VLC không chạy.
    var debugInfo: String {
        "state=\(player.state.rawValue) media=\(player.media?.state.rawValue ?? -1) videoOut=\(player.hasVideoOut) seekable=\(player.isSeekable)"
    }

    var audioTracks: [VLCTrack] { tracks(player.audioTrackNames, player.audioTrackIndexes) }
    var subtitleTracks: [VLCTrack] { tracks(player.videoSubTitlesNames, player.videoSubTitlesIndexes) }
    var currentAudio: Int32 {
        get { player.currentAudioTrackIndex }
        set { player.currentAudioTrackIndex = newValue }
    }
    var currentSubtitle: Int32 {
        get { player.currentVideoSubTitleIndex }
        set { player.currentVideoSubTitleIndex = newValue }
    }
    /// Độ trễ tính bằng micro giây; dương nghĩa là hiện muộn hơn.
    var subtitleDelay: Int {
        get { player.currentVideoSubTitleDelay }
        set { player.currentVideoSubTitleDelay = newValue }
    }
    var audioDelay: Int {
        get { player.currentAudioPlaybackDelay }
        set { player.currentAudioPlaybackDelay = newValue }
    }

    private func tracks(_ names: [Any]?, _ indexes: [Any]?) -> [VLCTrack] {
        let n = (names as? [String]) ?? []
        let i = (indexes as? [NSNumber]) ?? []
        return zip(n, i).map { VLCTrack(index: $1.int32Value, name: $0) }
    }

    func mediaPlayerStateChanged(_ aNotification: Notification!) {
        let s: VLCPlayState
        switch player.state {
        case .opening: s = .opening
        case .buffering: s = .buffering
        case .playing: s = .playing
        case .paused: s = .paused
        case .stopped: s = .stopped
        case .ended: s = .ended
        case .error: s = .error
        default: s = .buffering
        }
        DispatchQueue.main.async { [weak self] in self?.onState?(s) }
    }
}

#else

/// Bản dự phòng khi build không có VLCKit: giữ nguyên giao diện, không làm gì.
final class VLCBackend: NSObject {
    static let isAvailable = false
    var onState: ((VLCPlayState) -> Void)?
    init(view: UIView, url: URL, headers: [String: String]?, start: Double, rate: Float) { super.init() }
    func play() {}
    func pause() {}
    func stop() {}
    var isPlaying: Bool { false }
    var currentSeconds: Double { 0 }
    var durationSeconds: Double { 0 }
    func seek(to s: Double) {}
    var rate: Float { get { 1 } set {} }
    var debugInfo: String { "VLC không có trong bản build" }
    var logSummary: String { "" }
    var audioTracks: [VLCTrack] { [] }
    var subtitleTracks: [VLCTrack] { [] }
    var currentAudio: Int32 { get { -1 } set {} }
    var currentSubtitle: Int32 { get { -1 } set {} }
    var subtitleDelay: Int { get { 0 } set {} }
    var audioDelay: Int { get { 0 } set {} }
}

#endif
