import SwiftUI
import UniformTypeIdentifiers
import PluginKit

struct MangaView: View {
    var body: some View { NavigationStack { SourceSearchView(kind: .manga) } }
}

/// Mở một mục đã lưu: tìm plugin tương ứng rồi vào trang chi tiết.
struct EntryLink: View {
    let entry: ProgressEntry
    @EnvironmentObject var plugins: PluginManager

    var body: some View {
        if let src = plugins.source(id: entry.sourceID) {
            NavigationLink {
                MediaDetailView(source: src, item: MediaItem(id: entry.itemID, title: entry.title, coverURL: entry.cover, subtitle: nil))
            } label: { card }.buttonStyle(.plain)
        } else {
            card.opacity(0.4)   // plugin đã bị gỡ
        }
    }

    private var card: some View {
        VStack(alignment: .leading, spacing: 6) {
            AsyncImage(url: entry.cover.flatMap(URL.init)) { $0.resizable().scaledToFill() } placeholder: { Color.gray.opacity(0.2) }
                .frame(width: 125, height: 178).clipShape(RoundedRectangle(cornerRadius: 14))
            Text(entry.title).font(.subheadline).lineLimit(1).frame(width: 125, alignment: .leading)
            if let t = entry.lastChapterTitle { Text(t).font(.caption).foregroundColor(.secondary).lineLimit(1) }
        }
    }
}

struct LibraryView: View {
    @EnvironmentObject var progress: ProgressStore
    @State private var tab = 0

    var body: some View {
        NavigationStack {
            ScrollView {
                Picker("", selection: $tab) { Text("Yêu thích").tag(0); Text("Lịch sử").tag(1) }
                    .pickerStyle(.segmented).padding()
                let list = tab == 0 ? progress.entries.filter(\.favorite) : progress.entries.filter { $0.lastChapterID != nil }
                if list.isEmpty {
                    Text(tab == 0 ? "Chưa có mục yêu thích." : "Chưa có lịch sử.").foregroundColor(.secondary).padding(.top, 40)
                }
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 125), spacing: 12)], spacing: 16) {
                    ForEach(list) { EntryLink(entry: $0) }
                }.padding(.horizontal)
            }
            .navigationTitle("Thư viện")
        }
    }
}

struct SettingsView: View {
    @EnvironmentObject var plugins: PluginManager
    @Environment(\.dismiss) private var dismiss
    @State private var message: String?

    private let pluginTypes: [UTType] = [
        UTType(filenameExtension: "plugin.json") ?? .json,
        .json,
        .data
    ]

    var body: some View {
        NavigationStack {
            List {
                Section("Plugin đã cài") {
                    ForEach(plugins.sources, id: \.manifest.id) { s in
                        VStack(alignment: .leading, spacing: 3) {
                            Text(s.manifest.name).font(.headline)
                            Text("\(s.manifest.kind.rawValue) · v\(s.manifest.version) · \(s.manifest.language)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    .onDelete { idx in
                        idx.map { plugins.sources[$0].manifest.id }
                            .forEach { plugins.uninstall(id: $0) }
                    }
                }

                Section {
                    Button {
                        DocPicker.present(types: pluginTypes, allowsMultiple: false) { url in
                            do {
                                try plugins.installBundle(data: Data(contentsOf: url))
                                message = "Đã cài xong \(url.lastPathComponent)."
                            } catch {
                                message = "Cài thất bại: \(error.localizedDescription)"
                            }
                        }
                    } label: {
                        Label("Chọn plugin từ Tệp…", systemImage: "folder")
                    }

                    if let message {
                        Text(message)
                            .font(.footnote)
                            .foregroundColor(.secondary)
                    }
                } footer: {
                    Text("Chọn trực tiếp .plugin.json trong ứng dụng Tệp. Plugin dạng JSON phải chứa manifest và WASM base64.")
                }
            }
            .navigationTitle("Cài đặt")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                Button("Xong") { dismiss() }
            }
        }
    }
}
