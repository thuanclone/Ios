import UIKit
import UniformTypeIdentifiers

/// Bộ chọn file bằng UIKit. asCopy=true để file đã chọn có thể đọc ngay,
/// kể cả khi nguồn là iCloud Drive / Files.
final class DocPicker: NSObject, UIDocumentPickerDelegate {
    private static var current: DocPicker?
    private let onPick: (URL) -> Void

    private init(onPick: @escaping (URL) -> Void) {
        self.onPick = onPick
        super.init()
    }

    static func present(types: [UTType] = [.item],
                        allowsMultiple: Bool = false,
                        onPick: @escaping (URL) -> Void) {
        let picker = UIDocumentPickerViewController(
            forOpeningContentTypes: types,
            asCopy: true
        )
        let delegate = DocPicker(onPick: onPick)
        picker.delegate = delegate
        picker.allowsMultipleSelection = allowsMultiple
        current = delegate

        guard let vc = topViewController() else {
            current = nil
            return
        }
        vc.present(picker, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController,
                        didPickDocumentsAt urls: [URL]) {
        if let url = urls.first { onPick(url) }
        DocPicker.current = nil
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        DocPicker.current = nil
    }

    private static func topViewController() -> UIViewController? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let window = scenes.flatMap(\.windows).first(where: \.isKeyWindow)
        var top = window?.rootViewController
        while let next = top?.presentedViewController {
            top = next
        }
        return top
    }
}
