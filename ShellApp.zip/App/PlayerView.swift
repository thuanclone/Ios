import SwiftUI
import AVKit
import UniformTypeIdentifiers
import PluginKit

struct ExternalSub: Identifiable, Hashable {
    let id = UUID()
    let label: String
    let cues: [Cue]
}

/// Player kiểu Infuse ở mức AVFoundation:
/// - HLS/MP4 và các container/codecs mà iOS hỗ trợ
/// - chọn audio/sub nhúng
/// - SRT/VTT/ASS ngoài từ file hoặc URL
/// - resume, tốc độ, PiP, AirPlay
final class PlayerModel: ObservableObject {
    let player: AVPlayer
    private let info: StreamInfo

    @Published var subtitleText = ""
    @Published var externals: [ExternalSub] = []
    @Published var selectedExternal: UUID?
    @Published var subtitleOffset = 0.0
    @Published var fontSize: CGFloat = 20
    @Published var rate: Float = 1
    @Published var embeddedSubs: [AVMediaSelectionOption] = []
    @Published var selectedEmbedded: AVMediaSelectionOption?
    @Published var audioOptions: [AVMediaSelectionOption] = []
    @Published var selectedAudio: AVMediaSelectionOption?
    @Published var message: String?

    private var legible: AVMediaSelectionGroup?
    private var audible: AVMediaSelectionGroup?
    private var observer: Any?

    init(info: StreamInfo) {
        self.info = info
        let url = URL(string: info.url) ?? URL(string: "about:blank")!
        let options: [String: Any]? = info.headers.map {
            ["AVURLAssetHTTPHeaderFieldsKey": $0]
        }
        player = AVPlayer(
            playerItem: AVPlayerItem(
                asset: AVURLAsset(url: url, options: options)
            )
        )
    }

    var currentSeconds: Double {
        let t = player.currentTime().seconds
        return t.isFinite ? t : 0
    }

    func start(at seconds: Double) {
        guard observer == nil else { return }

        if seconds > 5 {
            player.seek(
                to: CMTime(seconds: seconds, preferredTimescale: 600),
                toleranceBefore: .zero,
                toleranceAfter: .zero
            )
        }

        observer = player.addPeriodicTimeObserver(
            forInterval: CMTime(seconds: 0.15, preferredTimescale: 600),
            queue: .main
        ) { [weak self] time in
            self?.tick(time.seconds)
        }

        player.defaultRate = rate
        player.play()
    }

    func stop() {
        if let observer {
            player.removeTimeObserver(observer)
            self.observer = nil
        }
        player.pause()
    }

    private func tick(_ time: Double) {
        guard let id = selectedExternal,
              let sub = externals.first(where: { $0.id == id }) else {
            if !subtitleText.isEmpty { subtitleText = "" }
            return
        }

        let shifted = time - subtitleOffset
        let text = sub.cues
            .filter { $0.start <= shifted && shifted < $0.end }
            .map(\.text)
            .joined(separator: "\n")

        if text != subtitleText { subtitleText = text }
    }

    func loadOptions() async {
        guard let item = player.currentItem else { return }

        let leg = try? await item.asset.loadMediaSelectionGroup(for: .legible)
        let aud = try? await item.asset.loadMediaSelectionGroup(for: .audible)

        await MainActor.run {
            legible = leg
            audible = aud
            embeddedSubs = leg?.options ?? []
            audioOptions = aud?.options ?? []
            selectedEmbedded = leg.flatMap {
                item.currentMediaSelection.selectedMediaOption(in: $0)
            }
            selectedAudio = aud.flatMap {
                item.currentMediaSelection.selectedMediaOption(in: $0)
            }
        }
    }

    func selectAudio(_ option: AVMediaSelectionOption) {
        guard let group = audible else { return }
        player.currentItem?.select(option, in: group)
        selectedAudio = option
    }

    func selectEmbedded(_ option: AVMediaSelectionOption?) {
        if let group = legible {
            player.currentItem?.select(option, in: group)
        }
        selectedEmbedded = option
        selectedExternal = nil
        subtitleText = ""
    }

    func selectExternal(_ id: UUID?) {
        selectedExternal = id
        if id != nil, let group = legible {
            player.currentItem?.select(nil, in: group)
            selectedEmbedded = nil
        }
        if id == nil { subtitleText = "" }
    }

    func addExternalData(label: String, data: Data, select: Bool = true) {
        let decoded = SubtitleParser.decode(data)
        let cues = SubtitleParser.parse(decoded)

        guard !cues.isEmpty else {
            message = "Không đọc được phụ đề \"\(label)\"."
            return
        }

        let sub = ExternalSub(label: label, cues: cues)
        externals.append(sub)

        if select { selectExternal(sub.id) }
    }

    func addExternal(url: URL,
                     label: String,
                     headers: [String: String]? = nil,
                     select: Bool = true) async {
        var request = URLRequest(url: url)
        headers?.forEach {
            request.setValue($1, forHTTPHeaderField: $0)
        }

        do {
            let (data, _) = try await URLSession.shared.data(for: request)
            await MainActor.run {
                addExternalData(label: label, data: data, select: select)
            }
        } catch {
            await MainActor.run {
                message = "Không tải được phụ đề: \(error.localizedDescription)"
            }
        }
    }

    func loadPluginSubs() async {
        for sub in info.subtitles ?? [] {
            guard let url = URL(string: sub.url) else { continue }
            let shouldSelect =
                (sub.language ?? "").lowercased().hasPrefix("vi")
                && selectedExternal == nil

            await addExternal(
                url: url,
                label: sub.label,
                headers: info.headers,
                select: shouldSelect
            )
        }
    }

    func setRate(_ value: Float) {
        rate = value
        player.defaultRate = value
        if player.timeControlStatus == .playing {
            player.rate = value
        }
    }
}

/// AVPlayerViewController cung cấp seek, fullscreen, PiP, AirPlay và controls
/// chuẩn iOS. Không thêm nút X riêng lên trên player.
struct NativePlayer: UIViewControllerRepresentable {
    let player: AVPlayer

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.allowsPictureInPicturePlayback = true
        controller.showsPlaybackControls = true
        controller.updatesNowPlayingInfoCenter = true
        return controller
    }

    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        if controller.player !== player {
            controller.player = player
        }
    }
}

struct PlayerView: View {
    let source: ContentSource
    let item: MediaItem
    let chapter: Chapter
    let startAt: Double

    @EnvironmentObject var progress: ProgressStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var model: PlayerModel

    @State private var showURLPrompt = false
    @State private var urlText = ""

    init(source: ContentSource,
         item: MediaItem,
         chapter: Chapter,
         info: StreamInfo,
         startAt: Double) {
        self.source = source
        self.item = item
        self.chapter = chapter
        self.startAt = startAt
        _model = StateObject(wrappedValue: PlayerModel(info: info))
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            NativePlayer(player: model.player)
                .ignoresSafeArea()

            // Chỉ hiện phụ đề ngoài; phụ đề nhúng được iOS vẽ bởi AVPlayer.
            VStack {
                Spacer()

                if !model.subtitleText.isEmpty {
                    Text(model.subtitleText)
                        .font(.system(size: model.fontSize, weight: .semibold))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                        .shadow(color: .black, radius: 2)
                        .shadow(color: .black, radius: 2)
                        .padding(.horizontal, 24)
                        .padding(.bottom, 90)
                }
            }
            .allowsHitTesting(false)

            // Không còn nút X. Dùng nút menu ở góc phải để không che controls.
            VStack {
                HStack {
                    Spacer()
                    menu
                }
                Spacer()
            }
            .padding(.top, 8)
            .padding(.horizontal, 12)
        }
        .statusBarHidden(true)
        .task {
            model.start(at: startAt)
            await model.loadOptions()
            await model.loadPluginSubs()
        }
        .onDisappear {
            let seconds = model.currentSeconds
            model.stop()

            progress.update(source: source, item: item) {
                $0.lastChapterID = chapter.id
                $0.lastChapterTitle = chapter.title
                $0.seconds = seconds
            }
        }
        .alert(
            "Phụ đề từ URL",
            isPresented: $showURLPrompt
        ) {
            TextField("https://…/phude.srt", text: $urlText)

            Button("Tải") {
                let value = urlText.trimmingCharacters(in: .whitespacesAndNewlines)
                urlText = ""

                guard let url = URL(string: value),
                      ["http", "https"].contains(url.scheme?.lowercased() ?? "")
                else {
                    model.message = "URL phụ đề không hợp lệ."
                    return
                }

                Task {
                    await model.addExternal(
                        url: url,
                        label: url.lastPathComponent.isEmpty
                            ? "Phụ đề online"
                            : url.lastPathComponent
                    )
                }
            }

            Button("Huỷ", role: .cancel) {
                urlText = ""
            }
        }
        .alert(
            "Thông báo",
            isPresented: Binding(
                get: { model.message != nil },
                set: { if !$0 { model.message = nil } }
            )
        ) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(model.message ?? "")
        }
    }

    @ViewBuilder
    private func check(_ title: String, _ selected: Bool) -> some View {
        if selected {
            Label(title, systemImage: "checkmark")
        } else {
            Text(title)
        }
    }

    private var noSubtitle: Bool {
        model.selectedExternal == nil && model.selectedEmbedded == nil
    }

    private var menu: some View {
        Menu {
            Menu("Phụ đề") {
                Button {
                    model.selectEmbedded(nil)
                } label: {
                    check("Tắt", noSubtitle)
                }

                if !model.embeddedSubs.isEmpty {
                    Section("Phụ đề nhúng") {
                        ForEach(
                            Array(model.embeddedSubs.enumerated()),
                            id: \.offset
                        ) { _, option in
                            Button {
                                model.selectEmbedded(option)
                            } label: {
                                check(
                                    option.displayName,
                                    model.selectedEmbedded == option
                                )
                            }
                        }
                    }
                }

                if !model.externals.isEmpty {
                    Section("Phụ đề ngoài") {
                        ForEach(model.externals) { sub in
                            Button {
                                model.selectExternal(sub.id)
                            } label: {
                                check(
                                    sub.label,
                                    model.selectedExternal == sub.id
                                )
                            }
                        }
                    }
                }

                Divider()

                Button("Chọn phụ đề từ Tệp…") {
                    let types: [UTType] = [
                        .srt,
                        .vtt,
                        .text,
                        .data
                    ]

                    DocPicker.present(types: types) { url in
                        guard let data = try? Data(contentsOf: url) else {
                            model.message = "Không đọc được file phụ đề."
                            return
                        }

                        model.addExternalData(
                            label: url.deletingPathExtension().lastPathComponent,
                            data: data
                        )
                    }
                }

                Button("Thêm phụ đề online…") {
                    showURLPrompt = true
                }

                Divider()

                Button("Sớm hơn 0,5 giây") {
                    model.subtitleOffset -= 0.5
                }
                Button("Muộn hơn 0,5 giây") {
                    model.subtitleOffset += 0.5
                }
                Button(
                    "Đặt lại độ lệch (\(String(format: "%+.1f", model.subtitleOffset))s)"
                ) {
                    model.subtitleOffset = 0
                }

                Button("Chữ to hơn") {
                    model.fontSize = min(model.fontSize + 2, 40)
                }
                Button("Chữ nhỏ hơn") {
                    model.fontSize = max(model.fontSize - 2, 12)
                }
            }

            Menu("Âm thanh") {
                if model.audioOptions.isEmpty {
                    Button("Không có nhiều luồng âm thanh") {}
                        .disabled(true)
                } else {
                    ForEach(
                        Array(model.audioOptions.enumerated()),
                        id: \.offset
                    ) { _, option in
                        Button {
                            model.selectAudio(option)
                        } label: {
                            check(
                                option.displayName,
                                model.selectedAudio == option
                            )
                        }
                    }
                }
            }

            Menu("Tốc độ") {
                ForEach(
                    [Float(0.5), 0.75, 1, 1.25, 1.5, 2],
                    id: \.self
                ) { value in
                    Button {
                        model.setRate(value)
                    } label: {
                        check(
                            "\(String(format: "%g", value))×",
                            model.rate == value
                        )
                    }
                }
            }

            Divider()

            Button("Đóng trình phát") {
                dismiss()
            }
        } label: {
            Image(systemName: "slider.horizontal.3")
                .font(.title3)
                .foregroundColor(.white)
                .padding(10)
                .background(.ultraThinMaterial)
                .clipShape(Circle())
        }
    }
}
