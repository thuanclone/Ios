import UniformTypeIdentifiers

extension UTType {
    static let srt = UTType(filenameExtension: "srt") ?? .text
    static let vtt = UTType(filenameExtension: "vtt") ?? .text
}
