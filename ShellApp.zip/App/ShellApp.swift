import SwiftUI
import PluginKit

@main
struct ShellApp: App {
    @StateObject private var plugins = PluginManager()
    @StateObject private var progress = ProgressStore()
    @State private var importMessage: String?

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(plugins)
                .environmentObject(progress)
                .preferredColorScheme(.dark)
                .onOpenURL { url in
                    let ok = url.startAccessingSecurityScopedResource()
                    defer { if ok { url.stopAccessingSecurityScopedResource() } }
                    do {
                        try plugins.installBundle(data: Data(contentsOf: url))
                        importMessage = "Đã cài xong \(url.lastPathComponent)."
                    } catch {
                        importMessage = "Cài thất bại: \(error)"
                    }
                }
                .alert("Plugin", isPresented: Binding(get: { importMessage != nil },
                                                      set: { if !$0 { importMessage = nil } })) {
                    Button("OK", role: .cancel) {}
                } message: { Text(importMessage ?? "") }
        }
    }
}

struct RootView: View {
    var body: some View {
        TabView {
            AnimeHomeView().tabItem { Label("Anime", systemImage: "play.rectangle.fill") }
            MangaView().tabItem { Label("Manga", systemImage: "book.fill") }
            LibraryView().tabItem { Label("Thư viện", systemImage: "square.stack.3d.up.fill") }
        }
    }
}

extension PluginManager {
    func source(id: String) -> ContentSource? { sources.first { $0.manifest.id == id } }
    func sources(of kind: MediaKind) -> [ContentSource] { sources.filter { $0.manifest.kind == kind } }
}
