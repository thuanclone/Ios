import Foundation

/// Nguồn giả để test UI khi chưa có plugin WASM nào. Không gọi mạng.
public struct SampleSource: ContentSource {
    public let manifest = PluginManifest(id: "sample", name: "Sample", version: "0.1",
        kind: .manga, language: "vi", allowedHosts: [], wasm: "")
    public init() {}

    public func search(query: String, page: Int) async throws -> [MediaItem] {
        (1...6).map { MediaItem(id: "s\($0)", title: "Truyện mẫu \($0)", coverURL: nil, subtitle: "12 chương") }
    }
    public func detail(id: String) async throws -> MediaDetail {
        MediaDetail(id: id, title: "Truyện mẫu", description: "Dữ liệu giả để test giao diện.",
                    coverURL: nil, genres: ["Demo"],
                    chapters: (1...12).map { Chapter(id: "c\($0)", title: "Chương \($0)", number: Double($0)) })
    }
    public func pages(chapterID: String) async throws -> PageList { PageList(pages: []) }
    public func stream(episodeID: String) async throws -> StreamInfo { StreamInfo(url: "", headers: nil, subtitles: nil) }
}
