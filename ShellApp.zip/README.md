# ShellApp (iOS 16+)

Vỏ ứng dụng anime/manga: giao diện SwiftUI + hệ thống plugin WASM. Không có nguồn nội dung nào cài sẵn.

## Dựng project
1. Xcode: File > New > Project > iOS App (SwiftUI), Minimum Deployments = iOS 16.0.
2. File > Add Package Dependencies > Add Local… chọn thư mục `ShellApp` (chứa Package.swift), thêm library `PluginKit` vào target.
3. Xoá ContentView/App mặc định, kéo các file trong `App/` vào target.
4. Chạy. Tab Anime lấy anime mùa này từ AniList; tab Manga/Thư viện chạy với plugin mẫu cho tới khi bạn cài plugin thật.

## Ghi chú iOS 16
Không dùng SwiftData, @Observable, ContentUnavailableView. Thanh tab là TabView chuẩn (hiệu ứng liquid glass tự có trên iOS 26).
Plugin: xem docs/PLUGIN_ABI.md.


## Bản ghép Player / Plugin Picker
- `App/PlayerView.swift` là player duy nhất. Không giữ `PlayerView` cũ trong `SourceViews.swift`.
- Nút X tùy biến trên player đã bỏ; AVPlayerViewController vẫn giữ controls/PiP/AirPlay chuẩn iOS.
- Player hỗ trợ phụ đề nhúng, SRT/VTT/ASS ngoài từ Tệp và phụ đề online do source trả về.
- Plugin picker dùng `UIDocumentPickerViewController` với `asCopy=true`, nhận `.plugin.json`/JSON và không phụ thuộc SwiftUI `.fileImporter`.
- `StreamInfo` đã có trường `subtitles` tùy chọn cho source.
- Phần catalog Nyaa không được nối vào luồng tải torrent trong bản này; nếu tích hợp nguồn ngoài, nên chỉ dùng nguồn có quyền/được phép phân phối nội dung.
