import Foundation
import WasmKit

/// Nạp một plugin .wasm và gọi các hàm export theo ABI trong docs/PLUGIN_ABI.md.
/// LƯU Ý: API của WasmKit đổi theo phiên bản. Nếu build lỗi, chỉ cần chỉnh
/// readBytes/writeBytes và chỗ khai báo Function bên dưới.
public final class WasmSource: ContentSource, @unchecked Sendable {
    public let manifest: PluginManifest
    private let store: Store
    private let instance: Instance
    private let lock = NSLock()   // instance WASM không thread-safe

    public init(manifest: PluginManifest, wasm: Data) throws {
        self.manifest = manifest
        let module = try parseWasm(bytes: Array(wasm))
        let store = Store(engine: Engine())
        self.store = store

        let hosts = manifest.allowedHosts
        var imports = Imports()

        // env.http_get(urlPtr, urlLen) -> i64 (ptr<<32 | len) trỏ tới body trả về
        imports.define(module: "env", name: "http_get",
            Function(store: store, parameters: [.i32, .i32], results: [.i64]) { caller, args in
                guard let mem = caller.instance?.exports[memory: "memory"],
                      let alloc = caller.instance?.exports[function: "alloc"] else { return [.i64(0)] }
                let urlBytes = Self.readBytes(mem, ptr: Int(args[0].i32), len: Int(args[1].i32))
                guard let url = URL(string: String(decoding: urlBytes, as: UTF8.self)),
                      let host = url.host, hosts.contains(where: { host == $0 || host.hasSuffix("." + $0) })
                else { return [.i64(0)] }                       // ngoài allowlist -> từ chối
                let body = Self.syncGet(url)
                let ptr = try alloc([.i32(UInt32(body.count))])[0].i32
                Self.writeBytes(mem, ptr: Int(ptr), bytes: [UInt8](body))
                return [.i64(UInt64(ptr) << 32 | UInt64(body.count))]
            })

        self.instance = try module.instantiate(store: store, imports: imports)
    }

    // MARK: ContentSource
    public func search(query: String, page: Int) async throws -> [MediaItem] {
        try call("search", ["query": query, "page": page])
    }
    public func detail(id: String) async throws -> MediaDetail { try call("detail", ["id": id]) }
    public func pages(chapterID: String) async throws -> PageList { try call("pages", ["id": chapterID]) }
    public func stream(episodeID: String) async throws -> StreamInfo { try call("stream", ["id": episodeID]) }

    // MARK: Gọi hàm plugin: JSON vào, JSON ra
    private func call<T: Decodable>(_ fn: String, _ input: [String: Any]) throws -> T {
        lock.lock(); defer { lock.unlock() }
        guard let mem = instance.exports[memory: "memory"] else { throw PluginError.missingExport("memory") }
        guard let alloc = instance.exports[function: "alloc"] else { throw PluginError.missingExport("alloc") }
        guard let dealloc = instance.exports[function: "dealloc"] else { throw PluginError.missingExport("dealloc") }
        guard let f = instance.exports[function: fn] else { throw PluginError.missingExport(fn) }

        let json = [UInt8](try JSONSerialization.data(withJSONObject: input))
        let inPtr = try alloc([.i32(UInt32(json.count))])[0].i32
        Self.writeBytes(mem, ptr: Int(inPtr), bytes: json)

        let packed = try f([.i32(inPtr), .i32(UInt32(json.count))])[0].i64
        let outPtr = Int(packed >> 32), outLen = Int(packed & 0xFFFF_FFFF)
        guard outLen > 0 else { throw PluginError.badResult }
        let out = Self.readBytes(mem, ptr: outPtr, len: outLen)

        _ = try? dealloc([.i32(inPtr), .i32(UInt32(json.count))])
        _ = try? dealloc([.i32(UInt32(outPtr)), .i32(UInt32(outLen))])
        return try JSONDecoder().decode(T.self, from: Data(out))
    }

    // MARK: Bộ nhớ và mạng (chỉnh theo phiên bản WasmKit)
    private static func readBytes(_ mem: Memory, ptr: Int, len: Int) -> [UInt8] {
        Array(mem.data[ptr ..< ptr + len])
    }
    private static func writeBytes(_ mem: Memory, ptr: Int, bytes: [UInt8]) {
        guard !bytes.isEmpty else { return }
        mem.withUnsafeMutableBufferPointer(offset: UInt(ptr), count: bytes.count) { buf in
            bytes.withUnsafeBytes { src in buf.copyMemory(from: src) }
        }
    }
    private static func syncGet(_ url: URL) -> Data {
        let sem = DispatchSemaphore(value: 0)
        var result = Data()
        var req = URLRequest(url: url, timeoutInterval: 25)
        // UA giống trình duyệt — một số site (Cloudflare) từ chối UA rỗng / CFNetwork thuần.
        req.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148", forHTTPHeaderField: "User-Agent")
        req.setValue("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", forHTTPHeaderField: "Accept")
        req.setValue("https://nyaa.media/", forHTTPHeaderField: "Referer")
        URLSession.shared.dataTask(with: req) { d, _, _ in
            result = d ?? Data()
            sem.signal()
        }.resume()
        _ = sem.wait(timeout: .now() + 30)
        return result
    }
}
