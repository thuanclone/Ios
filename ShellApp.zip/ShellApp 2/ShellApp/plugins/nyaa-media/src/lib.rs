//! Plugin nguồn torrent nyaa.media.
//! search: RSS (+ fallback HTML)  |  detail: view page  |  stream: magnet + X-Torrent-File
use serde::Serialize;
use serde_json::Value;

#[link(wasm_import_module = "env")]
extern "C" {
    fn http_get(url_ptr: i32, url_len: i32) -> i64;
}

#[derive(Serialize)]
struct MediaItem {
    id: String,
    title: String,
    #[serde(rename = "coverURL")]
    cover_url: Option<String>,
    subtitle: Option<String>,
}

#[derive(Serialize)]
struct Chapter {
    id: String,
    title: String,
    number: Option<f64>,
}

#[derive(Serialize)]
struct MediaDetail {
    id: String,
    title: String,
    description: Option<String>,
    #[serde(rename = "coverURL")]
    cover_url: Option<String>,
    genres: Vec<String>,
    chapters: Vec<Chapter>,
}

#[derive(Serialize)]
struct StreamInfo {
    url: String,
    headers: Option<std::collections::HashMap<String, String>>,
}

#[no_mangle]
pub extern "C" fn alloc(len: i32) -> i32 {
    let b = vec![0u8; len as usize].into_boxed_slice();
    Box::into_raw(b) as *mut u8 as usize as i32
}

#[no_mangle]
pub extern "C" fn dealloc(ptr: i32, len: i32) {
    unsafe {
        drop(Box::from_raw(std::slice::from_raw_parts_mut(
            ptr as usize as *mut u8,
            len as usize,
        )));
    }
}

fn input(ptr: i32, len: i32) -> Value {
    let s = unsafe { std::slice::from_raw_parts(ptr as usize as *const u8, len as usize) };
    serde_json::from_slice(s).unwrap_or(Value::Null)
}

fn out<T: Serialize>(v: &T) -> i64 {
    let bytes = serde_json::to_vec(v).unwrap_or_default().into_boxed_slice();
    let len = bytes.len();
    if len == 0 {
        return 0;
    }
    let ptr = Box::into_raw(bytes) as *mut u8 as usize;
    ((ptr as i64) << 32) | len as i64
}

fn fetch(url: &str) -> Option<String> {
    let bytes = url.as_bytes();
    let p = alloc(bytes.len() as i32);
    unsafe {
        std::ptr::copy_nonoverlapping(bytes.as_ptr(), p as usize as *mut u8, bytes.len());
    }
    let packed = unsafe { http_get(p, bytes.len() as i32) };
    dealloc(p, bytes.len() as i32);
    let out_ptr = (packed >> 32) as i32;
    let out_len = (packed & 0xFFFF_FFFF) as i32;
    if out_len <= 0 {
        return None;
    }
    let slice =
        unsafe { std::slice::from_raw_parts(out_ptr as usize as *const u8, out_len as usize) };
    let s = String::from_utf8_lossy(slice).into_owned();
    dealloc(out_ptr, out_len);
    Some(s)
}

fn urlencode(s: &str) -> String {
    s.bytes()
        .map(|b| match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                (b as char).to_string()
            }
            b' ' => "+".into(),
            _ => format!("%{b:02X}"),
        })
        .collect()
}

fn decode_entities(s: &str) -> String {
    s.replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace("&apos;", "'")
}

fn xml_tag<'a>(hay: &'a str, tag: &str) -> Option<&'a str> {
    let open = format!("<{tag}>");
    let close = format!("</{tag}>");
    let a = hay.find(&open)? + open.len();
    let b = hay[a..].find(&close)? + a;
    Some(hay[a..b].trim())
}

fn xml_tag_nyaa<'a>(hay: &'a str, tag: &str) -> Option<&'a str> {
    let open = format!("<nyaa:{tag}>");
    let close = format!("</nyaa:{tag}>");
    let a = hay.find(&open)? + open.len();
    let b = hay[a..].find(&close)? + a;
    Some(hay[a..b].trim())
}

fn extract_between<'a>(hay: &'a str, start: &str, end: &str) -> Option<&'a str> {
    let a = hay.find(start)? + start.len();
    let b = hay[a..].find(end)? + a;
    Some(&hay[a..b])
}

fn parse_rss(body: &str) -> Vec<MediaItem> {
    let mut items = Vec::new();
    for chunk in body.split("<item>").skip(1) {
        let title = xml_tag(chunk, "title").unwrap_or("").trim();
        let guid = xml_tag(chunk, "guid").unwrap_or("").trim();
        let id = guid
            .rsplit('/')
            .next()
            .unwrap_or("")
            .chars()
            .filter(|c| c.is_ascii_digit())
            .collect::<String>();
        if id.is_empty() {
            continue;
        }
        let size = xml_tag_nyaa(chunk, "size")
            .or_else(|| xml_tag(chunk, "description"))
            .unwrap_or("?");
        let seeders = xml_tag_nyaa(chunk, "seeders").unwrap_or("?");
        let leechers = xml_tag_nyaa(chunk, "leechers").unwrap_or("?");
        let cat = xml_tag_nyaa(chunk, "categoryName").unwrap_or("Torrent");
        items.push(MediaItem {
            id,
            title: decode_entities(title),
            cover_url: None,
            subtitle: Some(format!("{cat} · {size} · ↑{seeders} ↓{leechers}")),
        });
        if items.len() >= 75 {
            break;
        }
    }
    items
}

/// Parse HTML bảng kết quả khi RSS trống / bị chặn.
fn parse_html(body: &str) -> Vec<MediaItem> {
    let mut items = Vec::new();
    // Mỗi dòng: href="/view/1234567" ... title text
    let mut rest = body;
    while let Some(idx) = rest.find("/view/") {
        rest = &rest[idx + 6..];
        let id: String = rest
            .chars()
            .take_while(|c| c.is_ascii_digit())
            .collect();
        if id.is_empty() {
            continue;
        }
        // tìm title gần đó: >text</a>
        let title = extract_between(rest, ">", "</a>")
            .map(|t| decode_entities(t.trim()))
            .filter(|t| t.len() > 3 && !t.contains('<'))
            .unwrap_or_else(|| format!("Torrent #{id}"));
        // tránh trùng
        if items.iter().any(|m: &MediaItem| m.id == id) {
            continue;
        }
        items.push(MediaItem {
            id,
            title,
            cover_url: None,
            subtitle: Some("Nyaa torrent".into()),
        });
        if items.len() >= 50 {
            break;
        }
    }
    items
}

#[no_mangle]
pub extern "C" fn search(ptr: i32, len: i32) -> i64 {
    let v = input(ptr, len);
    let q = v["query"].as_str().unwrap_or("").trim();
    let page = v["page"].as_i64().unwrap_or(1).max(1);
    let enc = urlencode(q);

    // 1) RSS
    let rss_url = if q.is_empty() {
        format!("https://nyaa.media/?page=rss&p={page}")
    } else {
        format!("https://nyaa.media/?page=rss&q={enc}&c=0_0&f=0&p={page}")
    };

    if let Some(body) = fetch(&rss_url) {
        let items = parse_rss(&body);
        if !items.is_empty() {
            return out(&items);
        }
        // body nhận được nhưng không parse được → thử HTML
    }

    // 2) HTML fallback
    let html_url = if q.is_empty() {
        format!("https://nyaa.media/?p={page}")
    } else {
        format!("https://nyaa.media/?f=0&c=0_0&q={enc}&p={page}")
    };
    if let Some(body) = fetch(&html_url) {
        let items = parse_html(&body);
        if !items.is_empty() {
            return out(&items);
        }
    }

    // Cả hai fail → lỗi (len=0) để UI hiện thông báo, không im lặng trống
    0
}

#[no_mangle]
pub extern "C" fn detail(ptr: i32, len: i32) -> i64 {
    let id = input(ptr, len)["id"]
        .as_str()
        .unwrap_or("")
        .chars()
        .filter(|c| c.is_ascii_digit())
        .collect::<String>();
    if id.is_empty() {
        return 0;
    }
    let url = format!("https://nyaa.media/view/{id}");
    let body = match fetch(&url) {
        Some(b) => b,
        None => return 0,
    };

    let title = extract_between(&body, "<title>", " | Nyaa")
        .or_else(|| extract_between(&body, "<title>", "</title>"))
        .map(decode_entities)
        .unwrap_or_else(|| format!("Torrent #{id}"));

    let magnet = body
        .find("magnet:?xt=")
        .and_then(|i| {
            let rest = &body[i..];
            let end = rest.find('"').or_else(|| rest.find('\''))?;
            Some(decode_entities(&rest[..end]))
        })
        .unwrap_or_default();

    let torrent_file = format!("https://nyaa.si/download/{id}.torrent");
    let desc = format!(
        "Torrent từ nyaa.media\nID: {id}\nFile: {torrent_file}\nMagnet:\n{magnet}"
    );

    out(&MediaDetail {
        id: id.clone(),
        title,
        description: Some(desc),
        cover_url: None,
        genres: vec!["Torrent".into(), "Nyaa".into()],
        chapters: vec![Chapter {
            id: id.clone(),
            title: "Phát / tải torrent".into(),
            number: Some(1.0),
        }],
    })
}

#[no_mangle]
pub extern "C" fn stream(ptr: i32, len: i32) -> i64 {
    let id = input(ptr, len)["id"]
        .as_str()
        .unwrap_or("")
        .chars()
        .filter(|c| c.is_ascii_digit())
        .collect::<String>();
    if id.is_empty() {
        return 0;
    }
    let url = format!("https://nyaa.media/view/{id}");
    let body = match fetch(&url) {
        Some(b) => b,
        None => return 0,
    };
    let magnet = body
        .find("magnet:?xt=")
        .and_then(|i| {
            let rest = &body[i..];
            let end = rest.find('"').or_else(|| rest.find('\''))?;
            Some(decode_entities(&rest[..end]))
        })
        .unwrap_or_default();
    if magnet.is_empty() {
        return 0;
    }
    let mut headers = std::collections::HashMap::new();
    headers.insert(
        "X-Torrent-File".into(),
        format!("https://nyaa.si/download/{id}.torrent"),
    );
    headers.insert("X-Torrent-Id".into(), id);
    out(&StreamInfo {
        url: magnet,
        headers: Some(headers),
    })
}
